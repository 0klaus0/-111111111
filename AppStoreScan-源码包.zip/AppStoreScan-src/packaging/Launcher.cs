using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Threading;

public static class Launcher
{
    const string InnerDirName = "app-1.9.1";
    const string InnerExe = "AppStoreScan.exe";

    static string TargetDir()
    {
        string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AppStoreScan");
        return Path.Combine(root, InnerDirName);
    }

    static byte[] PayloadBytes()
    {
        using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
        {
            if (s == null) throw new Exception("内置数据缺失（payload.zip 未找到）");
            using (MemoryStream ms = new MemoryStream())
            {
                s.CopyTo(ms);
                return ms.ToArray();
            }
        }
    }

    static string Sha(byte[] data)
    {
        using (SHA256 sha = SHA256.Create())
        {
            byte[] h = sha.ComputeHash(data);
            StringBuilder sb = new StringBuilder();
            foreach (byte b in h) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }

    // 手写解压：兼容 Windows 构建工具写入的反斜杠条目
    static void Extract(byte[] zipData, string dest)
    {
        Directory.CreateDirectory(dest);
        using (MemoryStream ms = new MemoryStream(zipData))
        using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Read))
        {
            foreach (var e in zip.Entries)
            {
                string rel = e.FullName.Replace('\\', '/').TrimStart('/');
                if (rel.Length == 0 || rel.EndsWith("/")) continue;
                // 用户数据（data/ 下）已存在时不覆盖，升级版本不丢库
                if (rel.StartsWith("data/", StringComparison.OrdinalIgnoreCase) &&
                    File.Exists(Path.Combine(dest, rel.Replace('/', Path.DirectorySeparatorChar))))
                    continue;
                string full = Path.Combine(dest, rel.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(full));
                using (Stream src = e.Open())
                using (FileStream dst = File.Create(full))
                {
                    src.CopyTo(dst);
                }
            }
        }
    }

    static void Log(string msg)
    {
        try
        {
            string p = Path.Combine(Path.GetTempPath(), "AppStoreScan-launcher.log");
            if (File.Exists(p) && new FileInfo(p).Length > 512 * 1024) File.Delete(p);
            File.AppendAllText(p, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ") + msg + "\r\n", Encoding.UTF8);
        }
        catch { }
    }

    static string Explain(Exception e)
    {
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        while (e != null && depth < 6)
        {
            sb.Append(depth == 0 ? "" : " <- ");
            sb.Append(e.GetType().Name).Append(": ").Append(e.Message);
            e = e.InnerException;
            depth++;
        }
        return sb.ToString();
    }

    static string EnsurePayload(byte[] data, string sha, bool forceTemp)
    {
        string dir = TargetDir();
        string marker = Path.Combine(dir, ".payload.sha256");

        if (!forceTemp && File.Exists(marker))
        {
            try
            {
                string old = File.ReadAllText(marker).Trim();
                if (old == sha && File.Exists(Path.Combine(dir, InnerExe))) return dir;
            }
            catch { }
        }

        if (forceTemp)
        {
            dir = Path.Combine(Path.GetTempPath(), "AppStoreScan-" + DateTime.Now.Ticks);
        }

        try
        {
            if (Directory.Exists(dir))
            {
                // 只清理数据文件目录内容，避免占用文件导致失败时整体放弃
                foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                {
                    // data 目录是用户数据，重解压时保留
                    if (f.Replace('\\', '/').Contains("/data/")) continue;
                    try { File.Delete(f); } catch { }
                }
            }
            Extract(data, dir);
            File.WriteAllText(marker, sha);
            Log("payload unpacked OK -> " + dir);
            return dir;
        }
        catch (Exception ex)
        {
            Log("unpack FAILED -> " + dir + " :: " + Explain(ex));
            if (!forceTemp) return EnsurePayload(data, sha, true);
            throw;
        }
    }

    static string ErrorText(string dir)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("程序启动失败。");
        string log = Path.Combine(dir, "error.log");
        if (File.Exists(log))
        {
            try
            {
                string txt = File.ReadAllText(log);
                if (txt.Length > 2000) txt = txt.Substring(txt.Length - 2000);
                sb.AppendLine();
                sb.AppendLine("error.log（末尾）：");
                sb.AppendLine(txt);
            }
            catch { }
        }
        else
        {
            sb.AppendLine();
            sb.AppendLine("没有找到 error.log，可能被安全软件拦下了。");
            sb.AppendLine("可以试试：右键 → 以管理员身份运行，或把整个 exe 目录加入杀软白名单。");
        }
        return sb.ToString();
    }

    static bool IsPrepared(byte[] data, string sha)
    {
        string dir = TargetDir();
        string marker = Path.Combine(dir, ".payload.sha256");
        try
        {
            return File.Exists(marker) &&
                   File.ReadAllText(marker).Trim() == sha &&
                   File.Exists(Path.Combine(dir, InnerExe));
        }
        catch { return false; }
    }

    static Form BuildSplash()
    {
        Form f = new Form();
        f.Text = "AppStoreScan";
        f.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        f.StartPosition = FormStartPosition.CenterScreen;
        f.ClientSize = new System.Drawing.Size(380, 96);
        f.ShowInTaskbar = false;
        f.TopMost = true;
        Label l = new Label();
        l.Text = "正在准备运行环境，请稍候…";
        l.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        l.Dock = DockStyle.Fill;
        l.Font = new System.Drawing.Font("Microsoft YaHei", 10f);
        f.Controls.Add(l);
        return f;
    }

    [STAThread]
    static void Main(string[] args)
    {
        string dir = null;
        try
        {
            byte[] data = PayloadBytes();
            string sha = Sha(data);

            if (args.Length == 0 && !IsPrepared(data, sha))
            {
                // 首次运行：先给用户一个明确的"正在准备"窗口，避免看起来没反应
                Exception fail = null;
                Form splash = BuildSplash();
                splash.Shown += delegate
                {
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        try { dir = EnsurePayload(data, sha, false); }
                        catch (Exception ex) { fail = ex; }
                        try { splash.Invoke((Action)splash.Close); } catch { }
                    });
                };
                Application.Run(splash);
                if (fail != null) throw fail;
            }
            else
            {
                dir = EnsurePayload(data, sha, false);
            }

            string exe = Path.Combine(dir, InnerExe);
            if (!File.Exists(exe)) throw new Exception("解压后未找到 " + InnerExe);

            ProcessStartInfo psi = new ProcessStartInfo(exe);
            psi.WorkingDirectory = dir;

            if (args.Length > 0)
            {
                // 命令行用法：给内层独立控制台窗口，输出与原程序完全一致
                psi.UseShellExecute = true;
                psi.WindowStyle = ProcessWindowStyle.Normal;
                psi.Arguments = string.Join(" ", Array.ConvertAll(args, Quote));
            }
            else
            {
                // 双击用法：隐藏内部控制台，只显示图形界面
                psi.UseShellExecute = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
            }

            Process p = Process.Start(psi);
            if (p == null) throw new Exception("进程未能创建");

            if (args.Length == 0)
            {
                // 3 秒内异常退出 → 说明启动失败，弹窗说明而不是无声闪退
                Thread.Sleep(3000);
                if (p.HasExited && p.ExitCode != 0)
                {
                    MessageBox.Show(ErrorText(dir), "AppStoreScan 启动失败",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        catch (Exception ex)
        {
            string msg = "启动器异常：" + ex.Message;
            if (dir != null && Directory.Exists(dir)) msg += "\r\n\r\n" + ErrorText(dir);
            MessageBox.Show(msg, "AppStoreScan 启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    static string Quote(string s)
    {
        if (s.Length == 0) return "\"\"";
        if (s.IndexOfAny(new char[] { ' ', '\t', '"' }) < 0) return s;
        return "\"" + s.Replace("\"", "\\\"") + "\"";
    }
}