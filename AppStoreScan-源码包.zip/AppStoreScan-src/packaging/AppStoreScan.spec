# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['../src/entry.py'],
    pathex=[],
    binaries=[],
    datas=[('C:/Users/Administrator/AppData/Local/AppStoreScan/app-1.8.0/_internal/_tcl_data', '_tcl_data'), ('C:/Users/Administrator/AppData/Local/AppStoreScan/app-1.8.0/_internal/_tk_data', '_tk_data')],
    hiddenimports=['appstorescan.storecrypto', 'appstorescan.session_panel', 'appstorescan.sessionio', 'cryptography.hazmat.decrepit.ciphers.algorithms', 'cryptography.hazmat.primitives.ciphers.algorithms'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='AppStoreScan',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='AppStoreScan',
)

