﻿param(
    [string]$Mode = "",       # 1 = 常见商店域名，2 = 全部域名
    [string]$AppExe = "",     # 广播程序路径
    [string]$ApkDir = "",     # APK 目录
    [string]$LogFile = "",    # 广播程序 stdout 日志
    [string]$Hijack = "1",    # 1 = 把主机 DNS 指到本机（DNS 劫持）；0 = 不动 DNS，靠 WinDivert
    [string]$DnsPort = "53",  # 广播程序的 DNS 端口（Hijack=0 时给个空闲端口避开 ICS）
    [string]$OnlyList = "",   # 只劫持这些域名（逗号分隔，支持 *.xxx.com）；留空则按 Mode 决定
    [switch]$Detach
)

$ErrorActionPreference = "Continue"
$BaseDir = Join-Path $env:LOCALAPPDATA "AppStoreScan"
if (-not (Test-Path $BaseDir)) { New-Item -ItemType Directory $BaseDir -Force | Out-Null }
$StateFile = Join-Path $BaseDir "hotspot_state.txt"
$IfAlias = "以太网"
$Upstream = "223.5.5.5"
$HotspotIp = "192.168.137.1"

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[错误] 需要管理员权限" -ForegroundColor Red
    exit 2
}
if ($Mode -eq "") { $Mode = "1" }
if ($ApkDir -eq "") { $ApkDir = Join-Path (Split-Path -Parent $PSScriptRoot) "apk" }
if (-not (Test-Path $ApkDir)) { New-Item -ItemType Directory $ApkDir -Force | Out-Null }
if ($LogFile -eq "") { $LogFile = Join-Path $BaseDir "hotspot_app.log" }

if ($Mode -eq "2") {
    $only = ""
    Write-Host "[范围] 全部域名"
} else {
    $only = "*.mi.com,*.xiaomi.com,*.huawei.com,*.hicloud.com,*.qq.com,*.myapp.com,*.autonavi.com,*.amap.com,*.amapauto.com,*.oppo.com,*.heytap.com,*.vivo.com,*.apple.com,*.mzstatic.com,*.google.com,*.googleapis.com,*.gvt1.com"
    Write-Host "[范围] 常见商店域名"
}
if ($OnlyList -ne "") {
    $only = $OnlyList
    Write-Host "[范围] 指定域名 $OnlyList"
}

# 1) 记录原 DNS，供退出/异常时还原
$old = (Get-DnsClientServerAddress -InterfaceAlias $IfAlias -AddressFamily IPv4).ServerAddresses
if (-not $old -or $old.Count -eq 0) { $old = @("223.5.5.5", "114.114.114.114") }
if ($Hijack -eq "0") {
    # WinDivert 模式：不动主机 DNS，只在状态文件里留标记
    Set-Content -Path $StateFile -Value ("NONE|" + $IfAlias) -Encoding UTF8
    Write-Host ("[DNS] 不接管（保留 " + ($old -join ",") + "），由 WinDivert 在 IP 层拦截")
} else {
    Set-Content -Path $StateFile -Value (($old -join ",") + "|" + $IfAlias) -Encoding UTF8
    Write-Host ("[DNS] 原值 " + ($old -join ","))
}

# 2) 清掉残留
Get-Process -Name "AppStoreScan" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

# 3) 开热点
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null
    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
    function Await($op, $type) {
        $task = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result
    }
    [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime] | Out-Null
    [Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType = WindowsRuntime] | Out-Null
    $prof = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
    if (-not $prof) { throw "本机没有可用的上网连接" }
    $mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($prof)
    if ($mgr.TetheringOperationalState -ne "On") {
        $r = Await ($mgr.StartTetheringAsync()) ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
        if ($r.Status -ne "Success") { Write-Host ("[热点] 启动返回 " + $r.Status) }
    }
    $cfg = $mgr.GetCurrentAccessPointConfiguration()
    Write-Host ("[热点] 已开启  SSID=" + $cfg.Ssid + "  PASS=" + $cfg.Passphrase) -ForegroundColor Green
} catch {
    Write-Host ("[热点] 开启失败：" + $_.Exception.Message) -ForegroundColor Yellow
}

Start-Sleep -Seconds 3
$hsIp = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like "192.168.137.*" } | Select-Object -First 1).IPAddress
if ($hsIp) { $HotspotIp = $hsIp }
Write-Host ("[热点] 网关 " + $HotspotIp)

# 4) 防火墙放行
$need = @()
foreach ($p in @(53, 80, 443, 8898)) { $need += "AppStoreScan Hotspot TCP $p"; $need += "AppStoreScan Hotspot UDP $p" }
$have = @(Get-NetFirewallRule -DisplayName "AppStoreScan Hotspot*" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName)
foreach ($name in $need) {
    if ($have -contains $name) { continue }
    try {
        $proto = if ($name -like "* UDP *") { "UDP" } else { "TCP" }
        $port = [int]($name -split ' ')[-1]
        New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol $proto -LocalPort $port -Profile Any | Out-Null
        Write-Host ("[防火墙] 放行 " + $proto + " " + $port)
    } catch { }
}

# 5) 主机 DNS 指向本机
if ($Hijack -eq "0") {
    Write-Host "[DNS] WinDivert 模式：主机 DNS 保持原样"
} else {
    Set-DnsClientServerAddress -InterfaceAlias $IfAlias -ServerAddresses ("127.0.0.1")
    Write-Host "[DNS] 已指向 127.0.0.1"
}

# 6) 启动广播
$argLine = 'dns --apps-dir "{0}" --ip {1} --dns-port {2} --http-port 80 --https-port 443 --cert-port 8898 --upstream {3} --passthrough' -f $ApkDir, $HotspotIp, $DnsPort, $Upstream
if ($only -ne "") { $argLine += ' --only "' + $only + '"' }
Write-Host ("[启动] " + $AppExe)
Start-Process -FilePath $AppExe -ArgumentList $argLine -WindowStyle Hidden -RedirectStandardOutput $LogFile -RedirectStandardError ($LogFile + ".err") | Out-Null

$started = $false
for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Seconds 1
    if (Get-Process -Name "AppStoreScan" -ErrorAction SilentlyContinue) { $started = $true; break }
}
if ($started) { Write-Host "[状态] 广播服务已就绪" -ForegroundColor Green }
else { Write-Host "[状态] 广播服务未起来，请检查日志" -ForegroundColor Red }
Write-Host ("[地址] http://" + $HotspotIp + "/dl/<包名>.apk   证书页 http://" + $HotspotIp + ":8898")

if ($Detach) { Write-Host "[状态] 后台运行中"; exit 0 }

while (Get-Process -Name "AppStoreScan" -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 3 }
Write-Host "[状态] 广播程序已退出"
