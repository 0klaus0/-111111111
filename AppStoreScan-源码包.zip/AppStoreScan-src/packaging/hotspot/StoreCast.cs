using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace StoreCast
{
    static class Program
    {
        public const string Ver = "1.7.2";

        public static string BaseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AppStoreScan");
        public static string AppDir = Path.Combine(BaseDir, "app-" + Ver);
        public static string AppExe = Path.Combine(AppDir, "AppStoreScan.exe");
        public static string Ps1Path = Path.Combine(BaseDir, "hotspot_mode.ps1");
        public static string AppLog = Path.Combine(BaseDir, "hotspot_app.log");
        public static string StateFile = Path.Combine(BaseDir, "hotspot_state.txt");
        public static string DivertDir = Path.Combine(BaseDir, "windivert");
        public static string SessionState = Path.Combine(AppDir, "data", "session_state.json");
        public static string SessionManual = Path.Combine(AppDir, "data", "manual_session.json");
        public static string EncCacheDir = Path.Combine(AppDir, "data", "enc_cache");

        // 只接管这些主域：车机商店（application-store.autoai.com）就在 *.autoai.com 下
        public const string DefaultStoreHosts = "*.autoai.com,*.desaysv-iov.com,*.autonavi.com,*.amap.com,*.amapauto.com";
        public static string StoreHostsFile = Path.Combine(BaseDir, "store_hosts.txt");

        // 劫持名单：优先读 store_hosts.txt（一行，逗号分隔），没有就用默认
        public static string StoreHosts
        {
            get
            {
                try
                {
                    if (File.Exists(StoreHostsFile))
                    {
                        foreach (var raw in File.ReadAllLines(StoreHostsFile, Encoding.UTF8))
                        {
                            string line = raw.Trim();
                            if (line == "" || line.StartsWith("#")) continue;
                            return line;
                        }
                    }
                }
                catch { }
                return DefaultStoreHosts;
            }
        }

        public static string HostIp()
        {
            try
            {
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Ethernet
                        || ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Wireless80211)
                    {
                        foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        {
                            string ip = ua.Address.ToString();
                            if (!ip.StartsWith("192.168.137.") && !ip.StartsWith("127.")) return ip;
                        }
                    }
                }
            }
            catch { }
            return "127.0.0.1";
        }

        // 把内嵌的 WinDivert 驱动释放到本地
        // 找持有 192.168.137.1 的热点网卡索引
        public static int HotspotIndex()
        {
            try
            {
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.ToString() == "192.168.137.1")
                        {
                            try { return ni.GetIPProperties().GetIPv4Properties().Index; } catch { }
                        }
                    }
                }
            }
            catch { }
            return 0;
        }

        public static bool ExtractDriver(Action<string> log)
        {
            try
            {
                Directory.CreateDirectory(DivertDir);
                foreach (var name in new[] { "WinDivert.dll", "WinDivert64.sys" })
                {
                    string dest = Path.Combine(DivertDir, name);
                    using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
                    {
                        if (s == null) { log("内嵌驱动缺失：" + name); return false; }
                        if (File.Exists(dest) && new FileInfo(dest).Length == s.Length) continue;
                        using (var f = File.Create(dest)) s.CopyTo(f);
                    }
                }
                return true;
            }
            catch (Exception e) { log("释放驱动失败：" + e.Message); return false; }
        }

        [STAThread]
        static void Main(string[] args)
        {
            if (!IsAdmin())
            {
                try
                {
                    var psi = new ProcessStartInfo(Application.ExecutablePath, string.Join(" ", args));
                    psi.UseShellExecute = true;
                    psi.Verb = "runas";
                    Process.Start(psi);
                }
                catch { MessageBox.Show("需要管理员权限才能开热点和改 DNS。", "应用商店广播", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 无界面自测：从广播服务把某个 APK 下到本地，结果写进 storecast.log
            if (args.Length >= 3 && args[0] == "--dl-test")
            {
                string msg = "";
                long got = DownloadDialog.Fetch(args[1], args[2], null, out msg);
                string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] [自测下载] " + args[1] + " -> " + args[2]
                    + " 字节=" + got + " " + msg + Environment.NewLine;
                try { File.AppendAllText(Path.Combine(BaseDir, "storecast.log"), line, Encoding.UTF8); } catch { }
                try { File.WriteAllText(Path.Combine(BaseDir, "dl_test.txt"), line, Encoding.UTF8); } catch { }
                return;
            }

            var f = new MainForm(args);
            Application.Run(f);
        }

        public static bool IsAdmin()
        {
            try
            {
                return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        public static string ResourceText(string name)
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            {
                if (s == null) return null;
                using (var r = new StreamReader(s, Encoding.UTF8))
                    return r.ReadToEnd();
            }
        }

        public static string PayloadHash()
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                if (s == null) return "";
                return BitConverter.ToString(md5.ComputeHash(s)).Replace("-", "").ToLowerInvariant();
            }
        }

        // 解压广播程序（已有同版本则跳过；data 目录不覆盖）
        public static bool ExtractPayload(Action<string> log)
        {
            string marker = Path.Combine(AppDir, ".payload.sha");
            string hash = PayloadHash();
            if (File.Exists(AppExe) && File.Exists(marker) && File.ReadAllText(marker).Trim() == hash)
            {
                log("运行环境已就绪（无需重复解压）");
                return true;
            }
            log("首次运行：正在解压运行环境（约 40MB，稍等）…");
            Directory.CreateDirectory(AppDir);
            try
            {
                using (var zs = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
                using (var zip = new ZipArchive(zs, ZipArchiveMode.Read))
                {
                    int n = 0;
                    foreach (var e in zip.Entries)
                    {
                        string rel = e.FullName.Replace('\\', '/');
                        if (rel.EndsWith("/")) continue;
                        string dest = Path.Combine(AppDir, rel.Replace('/', '\\'));
                        if (rel.StartsWith("data/") && File.Exists(dest)) continue;
                        Directory.CreateDirectory(Path.GetDirectoryName(dest));
                        if (e.Length == 0) { using (File.Create(dest)) { } continue; }
                        using (var src = e.Open())
                        using (var dst = File.Create(dest))
                            src.CopyTo(dst);
                        n++;
                    }
                    log("解压完成，共 " + n + " 个文件");
                }
                File.WriteAllText(marker, hash);
                return File.Exists(AppExe);
            }
            catch (Exception ex)
            {
                log("解压失败：" + ex.Message);
                return false;
            }
        }
    }

    // 热点共享服务(ICS)会独占网关的 53 端口，广播程序绑不到；
    // 这里在网关和 127.0.0.1 上监听 53，把查询转给广播程序自己的端口。
    public class DnsRelay
    {
        public const int ListenPort = 15353;

        List<Socket> socks = new List<Socket>();
        volatile bool stopped = false;
        int targetPort;
        Action<string> log;
        long forwarded = 0;

        public void Start(string[] bindIps, int bindPort, string targetHost, int targetPort, Action<string> log)
        {
            this.targetPort = targetPort;
            this.log = log;
            foreach (string ip in bindIps)
            {
                string theIp = ip;
                int thePort = bindPort;
                Thread th = new Thread(delegate() { BindWithRetry(theIp, thePort); });
                th.IsBackground = true;
                th.Start();
            }
        }

        // 热点网关地址通常要过几秒才出现，所以带重试地绑定
        void BindWithRetry(string ip, int bindPort)
        {
            for (int i = 0; i < 40; i++)
            {
                if (stopped) return;
                try
                {
                    Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                    s.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                    s.Bind(new IPEndPoint(IPAddress.Parse(ip), bindPort));
                    socks.Add(s);
                    Thread th = new Thread(delegate() { Loop(s); });
                    th.IsBackground = true;
                    th.Start();
                    log("[DNS 转发] " + ip + ":" + bindPort + " → 127.0.0.1:" + targetPort);
                    return;
                }
                catch (Exception ex)
                {
                    if (i == 0) log("[DNS 转发] 等待 " + ip + ":" + bindPort + " 就绪…");
                    Thread.Sleep(2000);
                }
            }
            log("[DNS 转发] " + ip + ":" + bindPort + " 绑定失败，跳过");
        }

        void Loop(Socket s)
        {
            while (!stopped)
            {
                byte[] buf = new byte[4096];
                EndPoint from = new IPEndPoint(IPAddress.Any, 0);
                int n;
                try { n = s.ReceiveFrom(buf, ref from); }
                catch { if (stopped) break; else continue; }
                if (n <= 0) continue;
                byte[] data = new byte[n];
                Buffer.BlockCopy(buf, 0, data, 0, n);
                Socket outer = s;
                EndPoint client = from;
                ThreadPool.QueueUserWorkItem(delegate
                {
                    try
                    {
                        using (UdpClient u = new UdpClient())
                        {
                            u.Client.ReceiveTimeout = 3000;
                            u.Send(data, data.Length, new IPEndPoint(IPAddress.Loopback, targetPort));
                            IPEndPoint reply = new IPEndPoint(IPAddress.Any, 0);
                            byte[] resp = u.Receive(ref reply);
                            outer.SendTo(resp, client);
                            forwarded++;
                        }
                    }
                    catch { }
                });
            }
        }

        public long Forwarded { get { return forwarded; } }

        public void Stop()
        {
            stopped = true;
            foreach (Socket s in socks) { try { s.Close(); } catch { } }
            socks.Clear();
        }
    }

    public class ApkInfo
    {
        public string Package = "";
        public string Version = "";
        public string Size = "";
        public override string ToString() { return Package; }
    }

    public class MainForm : Form
    {
        TextBox logBox;
        Label statusLabel, ssidLabel, ipLabel, divertLabel, flowLabel, sessLabel, encLabel;
        ProgressBar encBar;
        Button btnStart, btnStop, btnApk, btnCert, btnAdvanced, btnLinks, btnSession;
        ComboBox cboMode, cboHook;
        CheckBox chkFollow;
        Process ps;
        DivertEngine divert;
        DnsRelay relay;
        System.Windows.Forms.Timer tailTimer;
        long logPos = 0;
        string apkDir;
        bool running = false;
        string autoMode = null;
        string autoHook = null;
        int quitAfter = 0;
        bool testDivert = false;
        DateTime startedAt;
        public List<ApkInfo> apkList = new List<ApkInfo>();

        [DllImport("user32.dll")]
        static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        const int EM_GETFIRSTVISIBLELINE = 0xCE;
        const int EM_LINESCROLL = 0xB6;

        public MainForm(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--auto" && i + 1 < args.Length) autoMode = args[i + 1];
                if (args[i] == "--quit-after" && i + 1 < args.Length) int.TryParse(args[i + 1], out quitAfter);
                if (args[i] == "--divert-test") testDivert = true;
                if (args[i] == "--hook" && i + 1 < args.Length) autoHook = args[i + 1];
            }

            Text = "应用商店广播 · 热点一体版 " + Program.Ver + "（WinDivert）";
            ClientSize = new Size(1100, 660);
            MinimumSize = new Size(1040, 600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.White;
            Font = new Font("Microsoft YaHei UI", 9F);

            var head = new Panel { Dock = DockStyle.Top, Height = 118, BackColor = Color.FromArgb(24, 30, 38), Padding = new Padding(16, 10, 16, 8) };
            var title = new Label { Text = "车机/老手机 应用商店广播", ForeColor = Color.White, Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold), AutoSize = true, Location = new Point(14, 12) };
            var sub = new Label { Text = "自动开热点 · 自动接管 DNS · 车机连上就能看到你的 APK", ForeColor = Color.FromArgb(150, 200, 230), AutoSize = true, Location = new Point(16, 44) };
            ssidLabel = new Label { Text = "热点：等待开启…", ForeColor = Color.FromArgb(180, 220, 250), AutoSize = true, Location = new Point(16, 64) };
            flowLabel = new Label { Text = FlowText(false, false, false), ForeColor = Color.FromArgb(140, 170, 200), AutoSize = true, Location = new Point(16, 88), Font = new Font("Microsoft YaHei UI", 9F) };
            head.Controls.Add(title); head.Controls.Add(sub); head.Controls.Add(ssidLabel); head.Controls.Add(flowLabel);

            var bar = new Panel { Dock = DockStyle.Top, Height = 56, Padding = new Padding(12, 10, 12, 8) };
            cboMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 172, Location = new Point(10, 14) };
            cboMode.Items.Add("常见商店域名（推荐）");
            cboMode.Items.Add("全部域名（万能模式）");
            cboMode.SelectedIndex = 0;
            cboHook = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200, Location = new Point(188, 14) };
            cboHook.Items.Add("标准（DNS 接管）");
            cboHook.Items.Add("加强（DNS + WinDivert 内核拦截）");
            cboHook.SelectedIndex = 1;
            btnStart = MakeBtn("开始广播", 392, 12, Color.FromArgb(0, 122, 204), Color.White, 92);
            btnStop = MakeBtn("停止", 490, 12, Color.FromArgb(230, 230, 230), Color.Black, 60);
            btnStop.Enabled = false;
            btnApk = MakeBtn("APK 文件夹", 556, 12, Color.FromArgb(240, 240, 240), Color.Black, 100);
            btnCert = MakeBtn("装证书页", 662, 12, Color.FromArgb(240, 240, 240), Color.Black, 84);
            btnAdvanced = MakeBtn("原界面", 752, 12, Color.FromArgb(240, 240, 240), Color.Black, 72);
            btnLinks = MakeBtn("下载链接", 830, 12, Color.FromArgb(0, 150, 110), Color.White, 96);
            btnSession = MakeBtn("会话状态", 932, 12, Color.FromArgb(255, 244, 214), Color.Black, 96);
            bar.Controls.Add(cboMode); bar.Controls.Add(cboHook); bar.Controls.Add(btnStart); bar.Controls.Add(btnStop);
            bar.Controls.Add(btnApk); bar.Controls.Add(btnCert); bar.Controls.Add(btnAdvanced); bar.Controls.Add(btnLinks);
            bar.Controls.Add(btnSession);

            // 会话状态条：设备号 / cipher / 加密进度（读内层写的 session_state.json）
            var strip = new Panel { Dock = DockStyle.Top, Height = 34, Width = 1100, BackColor = Color.FromArgb(250, 250, 252), Padding = new Padding(12, 6, 12, 4) };
            sessLabel = new Label { Text = "会话：引擎未启动（点「开始广播」后自动获取设备号）", AutoSize = true, Location = new Point(12, 9), ForeColor = Color.FromArgb(120, 90, 20) };
            encBar = new ProgressBar { Location = new Point(770, 7), Size = new Size(150, 18), Anchor = AnchorStyles.Top | AnchorStyles.Right, Minimum = 0, Maximum = 100, Visible = false };
            encLabel = new Label { Text = "", AutoSize = true, Location = new Point(928, 9), Anchor = AnchorStyles.Top | AnchorStyles.Right, ForeColor = Color.FromArgb(60, 60, 60) };
            strip.Controls.Add(sessLabel); strip.Controls.Add(encBar); strip.Controls.Add(encLabel);

            logBox = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, BackColor = Color.FromArgb(30, 30, 30), ForeColor = Color.FromArgb(210, 210, 210), Font = new Font("Consolas", 9F), BorderStyle = BorderStyle.None };

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 34, BackColor = Color.FromArgb(245, 245, 245) };
            statusLabel = new Label { Text = "就绪", AutoSize = true, Location = new Point(12, 9), ForeColor = Color.FromArgb(60, 60, 60) };
            divertLabel = new Label { Text = "", AutoSize = true, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(420, 9), ForeColor = Color.FromArgb(90, 90, 90) };
            ipLabel = new Label { Text = "", AutoSize = true, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(640, 9), ForeColor = Color.FromArgb(90, 90, 90) };
            chkFollow = new CheckBox { Text = "日志跟随最新", AutoSize = true, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(880, 7), Checked = false, ForeColor = Color.FromArgb(90, 90, 90) };
            bottom.Controls.Add(statusLabel); bottom.Controls.Add(divertLabel); bottom.Controls.Add(ipLabel); bottom.Controls.Add(chkFollow);

            Controls.Add(logBox);
            Controls.Add(bottom);
            Controls.Add(strip);
            Controls.Add(bar);
            Controls.Add(head);

            btnStart.Click += (s, e) => StartCast();
            btnStop.Click += (s, e) => StopCast(true);
            btnSession.Click += (s, e) =>
            {
                using (var dlg = new SessionForm()) dlg.ShowDialog(this);
            };
            btnApk.Click += (s, e) =>
            {
                Directory.CreateDirectory(apkDir);
                Process.Start("explorer.exe", "\"" + apkDir + "\"");
            };
            btnCert.Click += (s, e) =>
            {
                string ip = CurrentIp();
                try { Process.Start("http://" + ip + ":8898"); } catch { }
            };
            btnLinks.Click += (s, e) =>
            {
                try
                {
                    Log("打开下载链接面板…（已识别 " + apkList.Count + " 个 APK）");
                    var dlg = new DownloadDialog(apkList, CurrentIp(), running);
                    dlg.ShowDialog(this);
                    Log("下载链接面板已关闭");
                }
                catch (Exception ex)
                {
                    Log("下载面板出错：" + ex.Message);
                    MessageBox.Show(ex.Message, "下载链接");
                }
            };
            btnAdvanced.Click += (s, e) =>
            {
                if (running) { MessageBox.Show("先点「停止」，再打开原界面。"); return; }
                if (!Program.ExtractPayload(Log)) return;
                var psi = new ProcessStartInfo(Program.AppExe);
                psi.WorkingDirectory = Program.AppDir;
                psi.UseShellExecute = true;
                Process.Start(psi);
            };

            // 打开窗口时不回放上次的日志：从文件当前末尾开始读
            try
            {
                if (File.Exists(Program.AppLog)) logPos = new FileInfo(Program.AppLog).Length;
                else logPos = 0;
            }
            catch { logPos = 0; }

            tailTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            tailTimer.Tick += (s, e) => { Tail(); UpdateStats(); UpdateSession(); };
            tailTimer.Start();

            apkDir = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "apk");
            try { Directory.CreateDirectory(apkDir); }
            catch { apkDir = Path.Combine(Program.BaseDir, "apk"); Directory.CreateDirectory(apkDir); }

            Log("APK 目录：" + apkDir);
            Log("把 .apk 丢进这个文件夹，点「开始广播」即可上架（可放多个包）");
            Log("———————————————————————————————");

            if (autoMode != null || quitAfter > 0 || testDivert)
            {
                var boot = new System.Windows.Forms.Timer { Interval = 2000 };
                boot.Tick += (s, e) =>
                {
                    boot.Stop(); boot.Dispose();
                    try
                    {
                        if (autoMode != null || testDivert) StartCast();
                        if (quitAfter > 0)
                        {
                            var quit = new System.Windows.Forms.Timer { Interval = Math.Max(5, quitAfter) * 1000 };
                            quit.Tick += (s2, e2) => { quit.Stop(); Close(); };
                            quit.Start();
                        }
                    }
                    catch (Exception ex) { Log("自动启动异常：" + ex.Message); }
                };
                boot.Start();
            }
        }

        void StartCoroutine(Action a) { var t = new Thread(() => { Thread.Sleep(2500); try { BeginInvoke(a); } catch { } }); t.IsBackground = true; t.Start(); }

        Button MakeBtn(string text, int x, int y, Color bg, Color fg, int w)
        {
            var b = new Button { Text = text, Location = new Point(x, y), Size = new Size(w, 32), BackColor = bg, ForeColor = fg, FlatStyle = FlatStyle.Flat };
            b.FlatAppearance.BorderColor = Color.FromArgb(200, 200, 200);
            return b;
        }

        void Log(string s)
        {
            string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + s + Environment.NewLine;
            int firstLine = 0;
            try { firstLine = SendMessage(logBox.Handle, EM_GETFIRSTVISIBLELINE, 0, 0); } catch { }
            logBox.AppendText(line);
            if (!chkFollow.Checked)
            {
                try
                {
                    int nowLine = SendMessage(logBox.Handle, EM_GETFIRSTVISIBLELINE, 0, 0);
                    if (nowLine != firstLine) SendMessage(logBox.Handle, EM_LINESCROLL, 0, firstLine - nowLine);
                }
                catch { }
            }
            try { File.AppendAllText(Path.Combine(Program.BaseDir, "storecast.log"), line, Encoding.UTF8); } catch { }
        }

        // 从广播程序输出里识别「包名 版本 大小」
        void ScanApk(string raw)
        {
            try
            {
                string s = raw.Trim();
                Match m = Regex.Match(s, @"^([a-zA-Z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+)\s+([0-9][0-9A-Za-z\.\-_]*)?\s*([0-9\.]+MB)?");
                if (!m.Success) return;
                string pkg = m.Groups[1].Value;
                string ver = m.Groups[3].Value;
                string size = m.Groups[4].Value;
                for (int i = 0; i < apkList.Count; i++)
                {
                    if (string.Equals(apkList[i].Package, pkg, StringComparison.OrdinalIgnoreCase))
                    {
                        if (ver.Length > 0) apkList[i].Version = ver;
                        if (size.Length > 0) apkList[i].Size = size;
                        return;
                    }
                }
                var info = new ApkInfo();
                info.Package = pkg; info.Version = ver; info.Size = size;
                apkList.Add(info);
            }
            catch { }
        }

        string CurrentIp()
        {
            try
            {
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        if (ua.Address.ToString().StartsWith("192.168.137.")) return ua.Address.ToString();
                }
            }
            catch { }
            return "192.168.137.1";
        }

        // ---------------- 会话状态（设备号 / cipher / 加密进度） ----------------
        static string FlowText(bool castOn, bool hasSession, bool encDone)
        {
            Func<bool, string> m = ok => ok ? "✔" : "·";
            return "流程：" + m(castOn) + "①开热点  " + m(castOn) + "②车机连网  ·③装CA证书  "
                 + m(castOn) + "④开始广播  ·⑤刷商店  " + m(hasSession) + "⑥核对会话  " + m(encDone) + "⑦下载安装";
        }

        public static Dictionary<string, object> ReadSession()
        {
            try
            {
                if (!File.Exists(Program.SessionState)) return null;
                string txt = File.ReadAllText(Program.SessionState, Encoding.UTF8);
                var js = new JavaScriptSerializer();
                return js.Deserialize<Dictionary<string, object>>(txt);
            }
            catch { return null; }
        }

        public static string S(Dictionary<string, object> d, string key)
        {
            object v;
            if (d != null && d.TryGetValue(key, out v) && v != null) return v.ToString();
            return "";
        }

        void UpdateSession()
        {
            var d = ReadSession();
            bool fresh = false;
            if (d != null)
            {
                try
                {
                    double ts = Convert.ToDouble(d["ts"]);
                    double now = (DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
                    fresh = now - ts < 6;
                }
                catch { }
            }
            string effPlain = S(d, "eff_plain"), effCipher = S(d, "eff_cipher");
            bool manual = S(d, "manual_plain").Length > 0 || S(d, "manual_cipher").Length > 0;
            bool hasSession = fresh && effPlain.Length > 0 && effCipher.Length > 0;

            if (!fresh)
            {
                sessLabel.Text = running ? "会话：等待引擎就绪…" : "会话：引擎未启动（点「开始广播」后自动获取设备号）";
                sessLabel.ForeColor = Color.FromArgb(120, 90, 20);
                encBar.Visible = false; encLabel.Text = "";
            }
            else if (hasSession)
            {
                sessLabel.Text = "设备号：" + effPlain + (manual ? "（手动）" : "（自动捕获）")
                    + "  ·  cipher 已就绪 " + effCipher.Length + " 字符";
                sessLabel.ForeColor = Color.FromArgb(20, 120, 50);
            }
            else
            {
                sessLabel.Text = "会话：未捕获设备号/cipher —— 车机刷一次商店首页，或点「会话状态」手动填写";
                sessLabel.ForeColor = Color.FromArgb(180, 90, 10);
            }

            bool encDone = false;
            var enc = d != null && d.ContainsKey("enc") ? d["enc"] as Dictionary<string, object> : null;
            if (fresh && enc != null && enc.Count > 0)
            {
                try
                {
                    long done = Convert.ToInt64(enc["done"]), total = Convert.ToInt64(enc["total"]);
                    string err = S(enc, "error"), pkg = S(enc, "package");
                    if (total > 0)
                    {
                        int pct = (int)Math.Min(100, done * 100 / total);
                        encBar.Visible = true;
                        encBar.Value = pct;
                        if (err.Length > 0) { encLabel.Text = "加密失败：" + err; encLabel.ForeColor = Color.FromArgb(190, 30, 30); }
                        else if (done >= total) { encLabel.Text = "密文已就绪"; encLabel.ForeColor = Color.FromArgb(20, 120, 50); encDone = true; }
                        else { encLabel.Text = "加密 " + pct + "%  " + (done / 1048576.0).ToString("0.0") + "/" + (total / 1048576.0).ToString("0.0") + " MB"; encLabel.ForeColor = Color.FromArgb(60, 60, 60); }
                    }
                    else { encBar.Visible = false; encLabel.Text = ""; }
                }
                catch { encBar.Visible = false; encLabel.Text = ""; }
            }
            else { encBar.Visible = false; encLabel.Text = ""; }

            flowLabel.Text = FlowText(running, hasSession, encDone);
        }

        public static void SendManual(Dictionary<string, object> req)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Program.SessionManual));
            var js = new JavaScriptSerializer();
            string tmp = Program.SessionManual + ".tmp";
            File.WriteAllText(tmp, js.Serialize(req), new UTF8Encoding(false));
            File.Copy(tmp, Program.SessionManual, true);
            File.Delete(tmp);
        }

        void StartCast()
        {
            if (running) return;
            Log("开始被触发");

            if (testDivert)
            {
                if (!Program.ExtractDriver(Log)) return;
                DivertEngine de = new DivertEngine(Log);
                if (!de.LoadDriver(Program.DivertDir, Log)) return;
                divert = de;
                running = true; btnStart.Enabled = false; cboMode.Enabled = false; cboHook.Enabled = false; btnStop.Enabled = true;
                statusLabel.Text = "WinDivert 自检：解析商店 IP…";
                var tt = new Thread(() =>
                {
                    try { de.RefreshIps(l => { try { BeginInvoke(new Action(() => Log(l))); } catch { } }); } catch { }
                    try
                    {
                        BeginInvoke(new Action(() =>
                        {
                            if (!de.Start(true, Log)) return;
                            statusLabel.Text = "WinDivert 自检运行中";
                            var t2 = new Thread(() =>
                            {
                                Thread.Sleep(1500);
                                de.SelfTest(l => { try { BeginInvoke(new Action(() => Log(l))); } catch { } });
                                Thread.Sleep(4000);
                                try { BeginInvoke(new Action(() => Log("自检统计：拦截 " + de.PktsIn + " 包 / 重定向 " + de.Redirected + " / 回程 " + de.Returned))); } catch { }
                            });
                            t2.IsBackground = true; t2.Start();
                        }));
                    }
                    catch { }
                });
                tt.IsBackground = true;
                tt.Start();
                return;
            }

            int hook = cboHook.SelectedIndex;
            if (autoHook != null) int.TryParse(autoHook, out hook);

            if (!Program.ExtractPayload(Log)) { statusLabel.Text = "环境解压失败"; return; }
            string ps1 = Program.ResourceText("hotspot_mode.ps1");
            if (ps1 == null) { Log("内置脚本缺失"); return; }
            File.WriteAllText(Program.Ps1Path, ps1, new UTF8Encoding(true));

            string mode = cboMode.SelectedIndex == 1 ? "2" : "1";
            if (autoMode != null) mode = autoMode;
            try { File.Delete(Program.AppLog); } catch { }
            // 打开时不回放上次的日志：文件删不掉（被旧引擎占用）就从当前长度开始读
            try { logBox.Clear(); } catch { }
            try
            {
                if (File.Exists(Program.AppLog)) logPos = new FileInfo(Program.AppLog).Length;
                else logPos = 0;
            }
            catch { logPos = 0; }

            var psi = new ProcessStartInfo("powershell.exe");
            psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + Program.Ps1Path + "\" -Mode " + mode +
                            " -AppExe \"" + Program.AppExe + "\" -ApkDir \"" + apkDir + "\" -LogFile \"" + Program.AppLog + "\"" +
                            " -Hijack 1 -DnsPort " + DnsRelay.ListenPort +
                            " -OnlyList \"" + Program.StoreHosts + "\"";
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.GetEncoding(936);

            statusLabel.Text = "正在开热点、配 DNS…（约 10 秒）";
            Log("开始：" + (mode == "2" ? "全部域名模式" : "常见商店域名模式"));

            ps = new Process { StartInfo = psi };
            ps.OutputDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) OnEngineLine(e.Data); };
            ps.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) BeginInvoke(new Action(() => Log("! " + e.Data))); };
            ps.Start();
            Log("引擎进程已启动 PID=" + ps.Id + "  参数：" + psi.Arguments);
            ps.BeginOutputReadLine();
            ps.BeginErrorReadLine();

            running = true;
            startedAt = DateTime.Now;
            Log("[提醒] 车机首次使用需装 CA 证书：车机浏览器打开 http://" + CurrentIp() + ":8898/ 下载 ca.crt 并安装（换电脑要重装）");
            Log("[提醒] 设备号会自动捕获；捕获不到可点「会话状态」手动填写或从历史日志导入");
            btnStart.Enabled = false;
            cboMode.Enabled = false;
            cboHook.Enabled = false;
            btnStop.Enabled = true;

            // 热点共享服务(ICS)会占住网关的 53 端口，这里起一个转发器，
            // 把发给网关 192.168.137.1:53 的查询转到广播程序自己的端口上。
            try
            {
                relay = new DnsRelay();
                relay.Start(new string[] { CurrentIp(), "127.0.0.1" }, 53, "127.0.0.1", DnsRelay.ListenPort, Log);
            }
            catch (Exception ex) { Log("DNS 转发器启动失败：" + ex.Message); }

            if (hook >= 1) StartDivert();
        }

        void StartDivert()
        {
            if (!Program.ExtractDriver(Log)) return;
            DivertEngine de = new DivertEngine(Log);
            if (!de.LoadDriver(Program.DivertDir, Log)) return;
            divert = de;
            statusLabel.Text = "WinDivert 正在解析商店 IP…";
            var t = new Thread(() =>
            {
                try { de.RefreshIps(l => { try { BeginInvoke(new Action(() => Log(l))); } catch { } }); } catch { }
                try
                {
                    BeginInvoke(new Action(() =>
                    {
                        if (!running) return;
                        if (de.Start(false, Log))
                            statusLabel.Text = "运行中 — DNS 劫持 + WinDivert 内核拦截";
                    }));
                }
                catch { }
            });
            t.IsBackground = true;
            t.Start();
        }

        void OnEngineLine(string line)
        {
            BeginInvoke(new Action(() =>
            {
                Log(line);
                if (line.StartsWith("[热点] 已开启"))
                {
                    ssidLabel.Text = line.Replace("[热点] 已开启  ", "热点：");
                    statusLabel.Text = "热点已开，正在接管…";
                }
                else if (line.StartsWith("[热点] 网关"))
                {
                    ipLabel.Text = line.Replace("[热点] 网关 ", "网关 ") + "   证书页 :8898";
                }
                else if (line.Contains("广播服务已就绪"))
                {
                    statusLabel.Text = "运行中 — 车机连热点打开商店即可";
                }
                else if (line.Contains("未起来"))
                {
                    statusLabel.Text = "服务未启动，请看日志";
                }
            }));
        }

        void Tail()
        {
            if (!File.Exists(Program.AppLog)) return;
            try
            {
                using (var fs = new FileStream(Program.AppLog, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (fs.Length <= logPos) return;
                    fs.Position = logPos;
                    var enc = Encoding.GetEncoding(936);
                    using (var sr = new StreamReader(fs, enc))
                    {
                        string all = sr.ReadToEnd();
                        logPos = fs.Position;
                        foreach (var l in all.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                        {
                            ScanApk(l);
                            Log("  " + l.Trim());
                        }
                    }
                }
            }
            catch { }
        }

        void StopCast(bool fromButton)
        {
            if (!running && !fromButton) return;
            try { if (ps != null && !ps.HasExited) ps.Kill(); } catch { }
            if (!testDivert)
            {
                try
                {
                    foreach (var p in Process.GetProcessesByName("AppStoreScan")) { try { p.Kill(); } catch { } }
                }
                catch { }
            }
            try { if (divert != null) { divert.Stop(); Log("WinDivert 已卸载（驱动仍在，下次可直接用）"); } } catch { }
            divert = null;
            try { if (relay != null) { relay.Stop(); Log("DNS 转发器已停止"); } } catch { }
            relay = null;
            RestoreDns();
            running = false;
            btnStart.Enabled = true;
            cboMode.Enabled = true;
            cboHook.Enabled = true;
            btnStop.Enabled = false;
            divertLabel.Text = "";
            statusLabel.Text = "已停止";
            Log("已停止广播（热点仍在，可手动关闭）");
        }

        void RestoreDns()
        {
            try
            {
                if (!File.Exists(Program.StateFile)) return;
                string[] parts = File.ReadAllText(Program.StateFile).Trim().Split('|');
                if (parts.Length < 2) return;
                string servers = parts[0];
                string alias = parts[1];
                if (servers.Trim().ToUpperInvariant() == "NONE") { Log("本次未改主机 DNS，无需还原"); return; }
                string[] arr = servers.Split(',');
                var sb = new StringBuilder();
                sb.Append("Set-DnsClientServerAddress -InterfaceAlias '").Append(alias).Append("' -ServerAddresses (");
                for (int i = 0; i < arr.Length; i++) { if (i > 0) sb.Append(", "); sb.Append("'").Append(arr[i].Trim()).Append("'"); }
                sb.Append(")");
                var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -Command \"" + sb + "\"");
                psi.UseShellExecute = false; psi.CreateNoWindow = true;
                var p = Process.Start(psi);
                p.WaitForExit(5000);
                Log("主机 DNS 已还原为 " + servers);
            }
            catch { }
        }

        void UpdateStats()
        {
            if (divert == null) return;
            divertLabel.Text = "WinDivert 拦截 " + divert.PktsIn + " 包 / 重定向 " + divert.Redirected + " 连接";
            if (!string.IsNullOrEmpty(divert.LastError) && divert.LastError.Contains("失败"))
                divertLabel.Text += "  ⚠ " + divert.LastError;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (running) StopCast(false);
            base.OnFormClosing(e);
        }
    }

    // 会话状态窗口：自动捕获展示 + 手动填写设备号/cipher + 历史导入 + 加密进度
    public class SessionForm : Form
    {
        Label lblAuto, lblEff, lblNote, lblProg;
        TextBox txtPlain, txtCipher;
        ProgressBar prog;
        System.Windows.Forms.Timer timer;
        bool typed;

        public SessionForm()
        {
            Text = "会话状态 · 设备号 / cipher / 加密进度";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(680, 470);
            Font = new Font("Microsoft YaHei UI", 9F);

            var gbAuto = new GroupBox { Text = "自动捕获（车机刷商店首页后自动出现）", Location = new Point(12, 10), Size = new Size(656, 78) };
            lblAuto = new Label { Text = "设备号：—\ncipher：—", Location = new Point(12, 22), Size = new Size(632, 48), ForeColor = Color.FromArgb(60, 60, 60) };
            gbAuto.Controls.Add(lblAuto);

            var gbManual = new GroupBox { Text = "手动填写（自动捕获失败 / 换车机时用；填好后点「应用」）", Location = new Point(12, 96), Size = new Size(656, 130) };
            var lp = new Label { Text = "设备号 plainText：", Location = new Point(12, 26), AutoSize = true };
            txtPlain = new TextBox { Location = new Point(140, 22), Size = new Size(500, 26) };
            var lc = new Label { Text = "会话 cipher：", Location = new Point(12, 60), AutoSize = true };
            txtCipher = new TextBox { Location = new Point(140, 56), Size = new Size(500, 26) };
            var hint = new Label { Text = "设备号：车机 sdkInit 上报的 plainText（P 开头一串，留空=用自动捕获）；cipher 约172字符", Location = new Point(140, 88), AutoSize = true, ForeColor = Color.Gray };
            txtPlain.TextChanged += (s, e) => typed = true;
            txtCipher.TextChanged += (s, e) => typed = true;
            gbManual.Controls.Add(lp); gbManual.Controls.Add(txtPlain);
            gbManual.Controls.Add(lc); gbManual.Controls.Add(txtCipher); gbManual.Controls.Add(hint);

            var btnApply = new Button { Text = "应用手动值", Location = new Point(12, 236), Size = new Size(110, 32), BackColor = Color.FromArgb(0, 120, 215), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var btnImport = new Button { Text = "从历史日志导入", Location = new Point(130, 236), Size = new Size(130, 32) };
            var btnClear = new Button { Text = "清除手动值", Location = new Point(268, 236), Size = new Size(100, 32) };
            var btnCache = new Button { Text = "清空密文缓存", Location = new Point(376, 236), Size = new Size(110, 32) };
            var btnClose = new Button { Text = "关闭", Location = new Point(568, 236), Size = new Size(100, 32) };

            lblEff = new Label { Text = "生效中：—", Location = new Point(12, 280), Size = new Size(656, 22), ForeColor = Color.FromArgb(20, 100, 50) };
            lblNote = new Label { Text = "", Location = new Point(12, 304), Size = new Size(656, 40), ForeColor = Color.FromArgb(120, 90, 20) };
            lblProg = new Label { Text = "加密进度：—", Location = new Point(12, 350), AutoSize = true };
            prog = new ProgressBar { Location = new Point(12, 374), Size = new Size(656, 20), Minimum = 0, Maximum = 100 };
            var tip = new Label { Text = "提示：换车机/换设备号后建议「清空密文缓存」；应用手动值后会自动重新预加密。", Location = new Point(12, 404), Size = new Size(656, 40), ForeColor = Color.Gray };

            btnApply.Click += (s, e) =>
            {
                string p = txtPlain.Text.Trim(), c = txtCipher.Text.Trim();
                if (p.Length == 0 && c.Length == 0) { MessageBox.Show(this, "请至少填写设备号或 cipher", "提示"); return; }
                if (c.Length > 0 && c.Length < 32) { MessageBox.Show(this, "cipher 长度看起来不对（正常约172字符），请检查", "提示"); return; }
                var req = new Dictionary<string, object>();
                if (p.Length > 0) req["plain"] = p;
                if (c.Length > 0) req["cipher"] = c;
                try { MainForm.SendManual(req); lblNote.Text = "已发送，引擎将在 1 秒内应用并重新预加密…"; }
                catch (Exception ex) { MessageBox.Show(this, "写入失败：" + ex.Message, "错误"); }
            };
            btnImport.Click += (s, e) =>
            {
                try { MainForm.SendManual(new Dictionary<string, object> { { "import_history", true } }); lblNote.Text = "正在从历史日志导入（含旧版本目录）…"; typed = false; }
                catch (Exception ex) { MessageBox.Show(this, "写入失败：" + ex.Message, "错误"); }
            };
            btnClear.Click += (s, e) =>
            {
                try { MainForm.SendManual(new Dictionary<string, object> { { "clear", true } }); txtPlain.Text = ""; txtCipher.Text = ""; typed = false; lblNote.Text = "已请求清除手动值"; }
                catch (Exception ex) { MessageBox.Show(this, "写入失败：" + ex.Message, "错误"); }
            };
            btnCache.Click += (s, e) =>
            {
                try
                {
                    int n = 0;
                    if (Directory.Exists(Program.EncCacheDir))
                        foreach (var f in Directory.GetFiles(Program.EncCacheDir))
                        {
                            if (f.EndsWith(".enc") || f.EndsWith(".tmp")) { File.Delete(f); n++; }
                        }
                    lblNote.Text = "已清空密文缓存 " + n + " 个文件，下次下载将按当前会话重新加密";
                }
                catch (Exception ex) { MessageBox.Show(this, "清理失败：" + ex.Message, "错误"); }
            };
            btnClose.Click += (s, e) => Close();

            Controls.Add(gbAuto); Controls.Add(gbManual);
            Controls.Add(btnApply); Controls.Add(btnImport); Controls.Add(btnClear); Controls.Add(btnCache); Controls.Add(btnClose);
            Controls.Add(lblEff); Controls.Add(lblNote); Controls.Add(lblProg); Controls.Add(prog); Controls.Add(tip);

            // 打开时预填手动值
            var d0 = MainForm.ReadSession();
            if (d0 != null) { txtPlain.Text = MainForm.S(d0, "manual_plain"); txtCipher.Text = MainForm.S(d0, "manual_cipher"); }
            typed = false;

            timer = new System.Windows.Forms.Timer { Interval = 600 };
            timer.Tick += (s, e) => Refresh2();
            timer.Start();
            Refresh2();
        }

        void Refresh2()
        {
            var d = MainForm.ReadSession();
            if (d == null) { lblAuto.Text = "设备号：—\ncipher：—（引擎未启动或状态文件不存在）"; lblEff.Text = "生效中：—"; return; }
            string p = MainForm.S(d, "plain"), c = MainForm.S(d, "cipher");
            lblAuto.Text = "设备号：" + (p.Length > 0 ? p : "未捕获") + "\ncipher：" + (c.Length > 0 ? "已捕获 " + c.Length + " 字符" : "未捕获");
            string ep = MainForm.S(d, "eff_plain"), ec = MainForm.S(d, "eff_cipher");
            bool manual = MainForm.S(d, "manual_plain").Length > 0 || MainForm.S(d, "manual_cipher").Length > 0;
            lblEff.Text = ep.Length > 0 && ec.Length > 0
                ? "生效中：" + ep + (manual ? "（手动）" : "（自动）") + " · cipher " + ec.Length + " 字符"
                : "生效中：无（先刷商店或手动填写）";
            string note = MainForm.S(d, "note");
            if (note.Length > 0) lblNote.Text = note;
            if (!typed)
            {
                string mp = MainForm.S(d, "manual_plain"), mc = MainForm.S(d, "manual_cipher");
                if (txtPlain.Text != mp) txtPlain.Text = mp;
                if (txtCipher.Text != mc) txtCipher.Text = mc;
                typed = false;   // 程序赋值会触发 TextChanged，这里复位
            }
            var enc = d.ContainsKey("enc") ? d["enc"] as Dictionary<string, object> : null;
            if (enc != null && enc.Count > 0)
            {
                try
                {
                    long done = Convert.ToInt64(enc["done"]), total = Convert.ToInt64(enc["total"]);
                    string err = MainForm.S(enc, "error"), pkg = MainForm.S(enc, "package");
                    if (total > 0)
                    {
                        int pct = (int)Math.Min(100, done * 100 / total);
                        prog.Value = pct;
                        lblProg.Text = err.Length > 0 ? "加密失败：" + err
                            : done >= total ? "密文已就绪：" + pkg
                            : "加密 " + pkg + "  " + pct + "%  " + (done / 1048576.0).ToString("0.0") + "/" + (total / 1048576.0).ToString("0.0") + " MB";
                    }
                    else { lblProg.Text = "加密进度：—"; prog.Value = 0; }
                }
                catch { }
            }
            else { lblProg.Text = "加密进度：—（捕获会话后自动预加密）"; prog.Value = 0; }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (timer != null) { timer.Stop(); timer.Dispose(); }
            base.OnFormClosed(e);
        }
    }

    // 服务器 APK 下载链接面板：显示每包的下载地址，并可直接下到电脑
    public class DownloadDialog : Form
    {
        ListView lv;
        TextBox txtUrl;
        Button btnCopy, btnOpen, btnDl, btnClose;
        ProgressBar bar;
        Label lblStatus, lblTip;
        List<ApkInfo> items;
        string gateway;
        bool running;

        public DownloadDialog(List<ApkInfo> items, string gateway, bool running)
        {
            this.items = items;
            this.gateway = gateway;
            this.running = running;

            Text = "服务器 APK 下载链接";
            ClientSize = new Size(780, 470);
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false; MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            BackColor = Color.White;
            Font = new Font("Microsoft YaHei UI", 9F);

            var head = new Panel { Dock = DockStyle.Top, Height = 66, BackColor = Color.FromArgb(24, 30, 38) };
            var t1 = new Label { Text = "服务器上的 APK 下载地址", ForeColor = Color.White, Font = new Font("Microsoft YaHei UI", 13F, FontStyle.Bold), AutoSize = true, Location = new Point(14, 10) };
            lblTip = new Label { Text = "车机/手机浏览器直接打开这个地址即可下载；也可以点下面的按钮存到电脑", ForeColor = Color.FromArgb(150, 200, 230), AutoSize = true, Location = new Point(16, 40) };
            head.Controls.Add(t1); head.Controls.Add(lblTip);

            lv = new ListView { Location = new Point(12, 78), Size = new Size(756, 190), View = View.Details, FullRowSelect = true, GridLines = true, HideSelection = false };
            lv.Columns.Add("包名", 250);
            lv.Columns.Add("版本", 130);
            lv.Columns.Add("大小", 90);
            lv.Columns.Add("下载链接", 270);
            lv.SelectedIndexChanged += (s, e) => ShowUrl();

            var lblUrl = new Label { Text = "下载地址：", Location = new Point(12, 278), AutoSize = true };
            txtUrl = new TextBox { Location = new Point(78, 274), Size = new Size(690, 26), ReadOnly = true };

            btnCopy = new Button { Text = "复制链接", Location = new Point(12, 312), Size = new Size(96, 34), FlatStyle = FlatStyle.Flat };
            btnOpen = new Button { Text = "用浏览器打开", Location = new Point(116, 312), Size = new Size(120, 34), FlatStyle = FlatStyle.Flat };
            btnDl = new Button { Text = "下载到电脑", Location = new Point(244, 312), Size = new Size(120, 34), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(0, 150, 110), ForeColor = Color.White };
            btnClose = new Button { Text = "关闭", Location = new Point(654, 312), Size = new Size(110, 34), FlatStyle = FlatStyle.Flat };

            bar = new ProgressBar { Location = new Point(12, 360), Size = new Size(756, 18), Minimum = 0, Maximum = 100 };
            lblStatus = new Label { Text = "", Location = new Point(12, 386), Size = new Size(756, 60), ForeColor = Color.FromArgb(70, 70, 70) };

            Controls.Add(head); Controls.Add(lv); Controls.Add(lblUrl); Controls.Add(txtUrl);
            Controls.Add(btnCopy); Controls.Add(btnOpen); Controls.Add(btnDl); Controls.Add(btnClose);
            Controls.Add(bar); Controls.Add(lblStatus);

            btnCopy.Click += (s, e) => { if (txtUrl.Text.Length > 0) Clipboard.SetText(txtUrl.Text); };
            btnOpen.Click += (s, e) => { if (txtUrl.Text.Length > 0) { try { Process.Start(txtUrl.Text); } catch { } } };
            btnClose.Click += (s, e) => Close();
            btnDl.Click += (s, e) => DownloadSelected();

            Fill();
            if (lv.Items.Count > 0) { lv.Items[0].Selected = true; lv.Items[0].Focused = true; }
        }

        string UrlOf(ApkInfo info)
        {
            return "http://" + gateway + "/dl/" + info.Package + ".apk";
        }

        void Fill()
        {
            lv.Items.Clear();
            if (items.Count == 0)
            {
                var guess = new ApkInfo();
                guess.Package = "默认包";
                guess.Version = "-";
                guess.Size = "-";
                guess.Package = "";       // 用兜底地址
                var it = lv.Items.Add("（未识别包名）");
                it.SubItems.Add("-"); it.SubItems.Add("-"); it.SubItems.Add("http://" + gateway + "/dl/apk.apk");
                it.Tag = null;
                lblStatus.Text = running
                    ? "还没从广播日志里识别到包名，可用上面这条兜底地址（服务端会返回默认 APK）。"
                    : "广播还没启动，先点「开始广播」，这里会自动列出每个 APK 的下载地址。";
                return;
            }
            foreach (var info in items)
            {
                var it = lv.Items.Add(info.Package);
                it.SubItems.Add(info.Version.Length > 0 ? info.Version : "-");
                it.SubItems.Add(info.Size.Length > 0 ? info.Size : "-");
                it.SubItems.Add(UrlOf(info));
                it.Tag = info;
            }
            lblStatus.Text = "共 " + items.Count + " 个 APK。地址里的 " + gateway + " 就是车机看到的服务器地址。";
        }

        void ShowUrl()
        {
            if (lv.SelectedItems.Count == 0) { txtUrl.Text = ""; return; }
            txtUrl.Text = lv.SelectedItems[0].SubItems[3].Text;
        }

        // 统一的下行实现：把展示用的地址换成本机回环，从同一个广播服务取文件
        public static long Fetch(string url, string saveTo, Action<long, long> progress, out string msg)
        {
            msg = "";
            try
            {
                int idx = url.IndexOf("/dl/");
                string local = idx >= 0 ? "http://127.0.0.1" + url.Substring(idx) : url;
                var req = (HttpWebRequest)WebRequest.Create(local);
                req.Timeout = 20000;
                req.UserAgent = "StoreCast/1.7";
                using (var resp = req.GetResponse())
                {
                    long total = resp.ContentLength;
                    long done = 0;
                    long lastTick = 0;
                    using (var s = resp.GetResponseStream())
                    using (var f = File.Create(saveTo))
                    {
                        byte[] buf = new byte[81920];
                        int n;
                        while ((n = s.Read(buf, 0, buf.Length)) > 0)
                        {
                            f.Write(buf, 0, n);
                            done += n;
                            long now = Environment.TickCount;
                            if (progress != null && (now - lastTick > 200 || done == total))
                            {
                                lastTick = now;
                                progress(done, total);
                            }
                        }
                    }
                    msg = "OK";
                    return done;
                }
            }
            catch (Exception ex)
            {
                msg = "失败: " + ex.Message;
                return -1;
            }
        }

        void DownloadSelected()
        {
            if (lv.SelectedItems.Count == 0) { MessageBox.Show("先选中一个 APK。"); return; }
            string url = lv.SelectedItems[0].SubItems[3].Text;
            string name = lv.SelectedItems[0].Text;
            if (name.IndexOf(".") < 0) name = "app";
            var sfd = new SaveFileDialog();
            sfd.FileName = name + ".apk";
            sfd.Filter = "APK 文件|*.apk|所有文件|*.*";
            try
            {
                string dl = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                if (Directory.Exists(dl)) sfd.InitialDirectory = dl;
            }
            catch { }
            if (sfd.ShowDialog(this) != DialogResult.OK) return;

            string saveTo = sfd.FileName;
            btnDl.Enabled = false; bar.Value = 0;
            lblStatus.Text = "正在下载…";
            var th = new Thread(() =>
            {
                var reporter = new Action<long, long>((d, tt) =>
                {
                    try
                    {
                        BeginInvoke(new Action(() =>
                        {
                            if (tt > 0) bar.Value = (int)Math.Min(100, (d * 100 / tt));
                            lblStatus.Text = "已接收 " + Math.Round(d / 1048576.0, 1) + " MB" + (tt > 0 ? " / " + Math.Round(tt / 1048576.0, 1) + " MB" : "");
                        }));
                    }
                    catch { }
                });
                string msg;
                long got = Fetch(url, saveTo, reporter, out msg);
                try
                {
                    BeginInvoke(new Action(() =>
                    {
                        btnDl.Enabled = true;
                        if (got >= 0)
                        {
                            bar.Value = 100;
                            lblStatus.Text = "下载完成：" + saveTo + "（" + Math.Round(got / 1048576.0, 1) + " MB）";
                            MessageBox.Show("已保存到：\n" + saveTo, "下载完成");
                        }
                        else
                        {
                            lblStatus.Text = "下载失败：" + msg;
                        }
                    }));
                }
                catch { }
            });
            th.IsBackground = true;
            th.Start();
        }
    }
}

