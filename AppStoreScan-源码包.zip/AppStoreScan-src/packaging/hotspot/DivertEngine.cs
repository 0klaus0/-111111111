using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace StoreCast
{
    // WinDivert 内核层重定向：把热点客户端发往商店 IP 的 80/443 流量改写到本机网关，
    // 回程再改回原商店 IP，实现“不依赖 DNS”的透明拦截。
    public class DivertEngine
    {
        const int LAYER_NETWORK = 0;
        const int LAYER_FLOW = 4;

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool SetDllDirectory(string path);

        [DllImport("WinDivert.dll", SetLastError = true)]
        static extern IntPtr WinDivertOpen(string filter, int layer, short priority, ulong flags);

        [DllImport("WinDivert.dll", SetLastError = true)]
        static extern bool WinDivertRecv(IntPtr handle, byte[] pPacket, uint packetLen, out uint readLen, IntPtr pAddr);

        [DllImport("WinDivert.dll", SetLastError = true)]
        static extern bool WinDivertSend(IntPtr handle, byte[] pPacket, uint packetLen, out uint writeLen, IntPtr pAddr);

        [DllImport("WinDivert.dll", SetLastError = true)]
        static extern bool WinDivertClose(IntPtr handle);

        [DllImport("WinDivert.dll", SetLastError = true)]
        static extern uint WinDivertHelperCalcChecksums(byte[] pPacket, uint packetLen, IntPtr pAddr, ulong flags);

        public volatile bool Running;
        public long PktsIn, Redirected, Returned, LastErrAt;
        public string LastError = "";
        public string Gateway = "192.168.137.1";
        public HashSet<string> StoreIps = new HashSet<string>();

        IntPtr handle = IntPtr.Zero;
        Thread loop;
        readonly Dictionary<string, string> nat = new Dictionary<string, string>();
        readonly Dictionary<string, long> natAt = new Dictionary<string, long>();
        readonly object gate = new object();
        Action<string> log;

        public static readonly string[] Domains = new string[]
        {
            "app.mi.com", "store.mi.com", "api.mi.com", "app.xiaomi.com",
            "store.huawei.com", "app.huawei.com", "app.qq.com", "sj.qq.com",
            "app.myapp.com", "api.myapp.com",
            "app.autonavi.com", "api.autonavi.com", "app.amapauto.com", "api.amapauto.com",
            "store.oppo.com", "app.oppo.com", "app.heytap.com", "app.vivo.com",
            "itunes.apple.com", "play.google.com"
        };

        public DivertEngine(Action<string> logger) { log = logger; }

        public bool LoadDriver(string dir, Action<string> logger)
        {
            string dll = Path.Combine(dir, "WinDivert.dll");
            string sys = Path.Combine(dir, "WinDivert64.sys");
            if (!File.Exists(dll) || !File.Exists(sys)) { logger("WinDivert 驱动文件缺失：" + dir); return false; }
            try { SetDllDirectory(dir); return true; }
            catch (Exception e) { logger("加载驱动目录失败：" + e.Message); return false; }
        }

        // 自检：伪造一个“热点客户端”的 TCP SYN（src=192.168.137.99，dst=商店IP:443），
        // 以 inbound 方式注入热点网卡，验证 去程改写 → 本机投递 → 回程改写 是否闭环。
        public bool SelfTest(Action<string> logger)
        {
            string targetIp = null;
            foreach (var ip in StoreIps) { targetIp = ip; break; }
            if (targetIp == null) targetIp = "8.8.8.8";
            int idx = Program.HotspotIndex();
            if (idx <= 0) { logger("自检失败：找不到热点网卡"); return false; }

            byte[] pkt = new byte[40];
            pkt[0] = 0x45; pkt[1] = 0;
            pkt[2] = 0; pkt[3] = 40;
            pkt[4] = 0x12; pkt[5] = 0x34;
            pkt[6] = 0x40; pkt[7] = 0;
            pkt[8] = 64; pkt[9] = 6;
            W32(pkt, 12, Ip("192.168.137.99"));
            W32(pkt, 16, Ip(targetIp));
            W16(pkt, 20, 40000);
            W16(pkt, 22, 443);
            W32(pkt, 24, 0x11223344);
            W32(pkt, 28, 0);
            pkt[32] = 0x50;
            pkt[33] = 0x02;                 // SYN
            W16(pkt, 34, 65535);
            W16(pkt, 36, 0);
            W16(pkt, 38, 0);
            W16(pkt, 10, Checksum(pkt, 0, 20));
            W16(pkt, 36, TcpChecksum(pkt, 20, 20));

            IntPtr addr = Marshal.AllocHGlobal(64);
            IntPtr inj = IntPtr.Zero;
            try
            {
                for (int i = 0; i < 64; i++) Marshal.WriteByte(addr, i, 0);
                Marshal.WriteByte(addr, 10, 0x00);                  // 清 outbound → 视为 inbound
                Marshal.WriteInt32(addr, 12, idx);                  // ifIdx 指向热点网卡
                // 独立句柄注入：同一个句柄发出的包不会被自己再收到
                inj = WinDivertOpen("ip and tcp and ip.SrcAddr == 192.168.137.99 and tcp.DstPort == 443", LAYER_NETWORK, 0, 0);
                if (inj == IntPtr.Zero) { logger("自检注入句柄打开失败：" + Marshal.GetLastWin32Error()); return false; }
                uint wl;
                bool ok = WinDivertSend(inj, pkt, 40, out wl, addr);
                logger("自检注入 " + (ok ? "成功" : "失败") + "：192.168.137.99:40000 → " + targetIp + ":443（网卡#" + idx + "）");
                return ok;
            }
            catch (Exception e) { logger("自检注入异常：" + e.Message); return false; }
            finally
            {
                try { if (inj != IntPtr.Zero) WinDivertClose(inj); } catch { }
                Marshal.FreeHGlobal(addr);
            }
        }

        static ushort Checksum(byte[] d, int off, int len)
        {
            uint sum = 0;
            for (int i = 0; i + 1 < len; i += 2) sum += (uint)((d[off + i] << 8) | d[off + i + 1]);
            if ((len & 1) != 0) sum += (uint)(d[off + len - 1] << 8);
            while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
            return (ushort)(~sum & 0xffff);
        }

        static ushort TcpChecksum(byte[] d, int tcpOff, int tcpLen)
        {
            byte[] tmp = new byte[12 + tcpLen];
            Array.Copy(d, 12, tmp, 0, 8);                 // src + dst
            tmp[8] = 0; tmp[9] = 6;
            tmp[10] = (byte)(tcpLen >> 8); tmp[11] = (byte)(tcpLen & 0xff);
            Array.Copy(d, tcpOff, tmp, 12, tcpLen);
            return Checksum(tmp, 0, tmp.Length);
        }

        // 用系统自带 PowerShell 解析（绕开被自己劫持的系统 DNS）
        public void RefreshIps(Action<string> logger)
        {
            var set = new HashSet<string>();
            try
            {
                var parts = new List<string>();
                foreach (var d in Domains) parts.Add("'" + d + "'");
                string names = "@(" + string.Join(",", parts) + ")";
                string script = "$ErrorActionPreference='SilentlyContinue';" +
                                "$n=" + names + ";" +
                                "foreach($d in $n){ Resolve-DnsName -Server 223.5.5.5 -Type A -Name $d -ErrorAction SilentlyContinue | Where-Object {$_.Type -eq 'A'} | ForEach-Object { $_.IPAddress } }";
                var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + script + "\"");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.StandardOutputEncoding = Encoding.UTF8;
                var p = Process.Start(psi);
                string outp = p.StandardOutput.ReadToEnd();
                p.WaitForExit(20000);
                foreach (var line in outp.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string ip = line.Trim();
                    IPAddress pa;
                    if (!IPAddress.TryParse(ip, out pa)) continue;
                    if (pa.AddressFamily != AddressFamily.InterNetwork) continue;
                    if (ip.StartsWith("192.168.") || ip.StartsWith("10.") || ip == Gateway || ip.StartsWith("127.")) continue;
                    set.Add(ip);
                    if (set.Count >= 12) break;
                }
            }
            catch (Exception e) { logger("解析目标 IP 失败：" + e.Message); }

            StoreIps = set;
            logger("WinDivert 目标 IP 共 " + set.Count + " 个");
            if (set.Count > 0) logger("  样例：" + string.Join(", ", new List<string>(set).GetRange(0, Math.Min(4, set.Count))));
        }

        string BuildFilter(bool testMode)
        {
            var sb = new StringBuilder();
            sb.Append("ip and (");
            // 1) 车机发往任意地址的 DNS（53）——写死 DNS 也能兜住
            sb.Append("(inbound and ip.SrcAddr >= 192.168.137.2 and ip.SrcAddr <= 192.168.137.254 and udp and udp.DstPort == 53)");
            sb.Append(" or (inbound and ip.SrcAddr >= 192.168.137.2 and ip.SrcAddr <= 192.168.137.254 and tcp and tcp.DstPort == 53)");
            // 2) 车机直接打商店真实 IP 的 80/443
            var ips = new List<string>(StoreIps);
            if (testMode && ips.Count == 0) ips.Add("8.8.8.8");
            foreach (var ip in ips)
            {
                foreach (var port in new[] { 443, 80 })
                {
                    sb.Append(" or (inbound and ip.SrcAddr >= 192.168.137.2 and ip.SrcAddr <= 192.168.137.254 and tcp and tcp.DstPort == ")
                      .Append(port).Append(" and ip.DstAddr == ").Append(ip).Append(")");
                }
            }
            // 3) 回程：本机 → 车机
            string back = "outbound and ip.SrcAddr == " + Gateway + " and ip.DstAddr >= 192.168.137.2 and ip.DstAddr <= 192.168.137.254";
            sb.Append(" or (").Append(back).Append(" and udp and udp.SrcPort == 53)");
            sb.Append(" or (").Append(back).Append(" and tcp and tcp.SrcPort == 53)");
            sb.Append(" or (").Append(back).Append(" and tcp and tcp.SrcPort == 443)");
            sb.Append(" or (").Append(back).Append(" and tcp and tcp.SrcPort == 80)");
            sb.Append(")");
            return sb.ToString();
        }

        public bool Start(bool testMode, Action<string> logger)
        {
            string filter = BuildFilter(testMode);
            handle = WinDivertOpen(filter, LAYER_NETWORK, 0, 0);
            if (handle == IntPtr.Zero)
            {
                int code = Marshal.GetLastWin32Error();
                LastError = "WinDivertOpen 失败，错误码 " + code + "（1326=驱动未加载/无权限，87=过滤表达式非法）";
                logger(LastError);
                return false;
            }
            Running = true;
            loop = new Thread(() => Loop());
            loop.IsBackground = true;
            loop.Start();
            logger("WinDivert 已挂载，过滤规则 " + filter.Length + " 字节" + (testMode ? "（含自检注入）" : ""));
            return true;
        }

        public void Stop()
        {
            Running = false;
            try { if (handle != IntPtr.Zero) WinDivertClose(handle); } catch { }
            handle = IntPtr.Zero;
            try { if (loop != null) loop.Join(700); } catch { }
            lock (gate) { nat.Clear(); natAt.Clear(); }
        }

        void Loop()
        {
            byte[] pkt = new byte[65535];
            IntPtr addr = Marshal.AllocHGlobal(64);
            long lastClean = NowMs();
            try
            {
                while (Running && handle != IntPtr.Zero)
                {
                    uint len;
                    if (!WinDivertRecv(handle, pkt, 65535, out len, addr))
                    {
                        if (!Running) break;
                        LastErrAt = NowMs();
                        Thread.Sleep(3);
                        continue;
                    }
                    PktsIn++;
                    try { Rewrite(pkt, len); }
                    catch (Exception e) { LastError = "改包异常：" + e.Message; }
                    uint wl;
                    try { WinDivertSend(handle, pkt, len, out wl, addr); } catch { }
                    if (NowMs() - lastClean > 60000) { lastClean = NowMs(); Clean(); }
                }
            }
            finally { Marshal.FreeHGlobal(addr); }
        }

        static ushort U16(byte[] b, int o) { return (ushort)((b[o] << 8) | b[o + 1]); }
        static void W16(byte[] b, int o, ushort v) { b[o] = (byte)(v >> 8); b[o + 1] = (byte)(v & 0xff); }
        static uint U32(byte[] b, int o) { return (uint)((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]); }
        static void W32(byte[] b, int o, uint v) { b[o] = (byte)(v >> 24); b[o + 1] = (byte)(v >> 16); b[o + 2] = (byte)(v >> 8); b[o + 3] = (byte)(v & 0xff); }

        static bool InHotspot(uint ip)
        {
            return (ip >> 24) == 192 && ((ip >> 16) & 0xff) == 168 && ((ip >> 8) & 0xff) == 137;
        }

        void Rewrite(byte[] p, uint len)
        {
            if (len < 20) return;
            if ((p[0] >> 4) != 4) return;                 // 只处理 IPv4
            int ihl = (p[0] & 0x0f) * 4;
            if (ihl < 20 || len < (uint)(ihl + 20)) return;
            if (p[9] != 6 && p[9] != 17) return;          // TCP / UDP（DNS 走 UDP）
            uint src = U32(p, 12), dst = U32(p, 16);
            int to = ihl;
            ushort sport = U16(p, to), dport = U16(p, to + 2);
            bool isDns = (dport == 53 || sport == 53);

            // 去程：车机 → 外部（DNS 任意目的 / 商店 IP 的 80·443），改写目的为网关
            bool hit = InHotspot(src) && dst != Ip(Gateway) &&
                       (dport == 53 || ((dport == 80 || dport == 443) && StoreIps.Contains(S(dst))));
            if (hit)
            {
                string key = S(src) + ":" + sport + ":" + dport;
                lock (gate)
                {
                    if (!nat.ContainsKey(key))
                    {
                        nat[key] = S(dst);
                        natAt[key] = NowMs();
                        Redirected++;
                        if (Redirected <= 8 && log != null) log("重定向 " + S(src) + ":" + sport + " → " + S(dst) + ":" + dport + (isDns ? "（DNS）" : ""));
                    }
                }
                W32(p, 16, Ip(Gateway));
                Recalc(p, len);
                return;
            }

            // 回程：本机网关 → 车机，把源地址改回原目的 IP
            if (src == Ip(Gateway) && InHotspot(dst) && (sport == 53 || sport == 80 || sport == 443))
            {
                string key = S(dst) + ":" + dport + ":" + sport;
                string orig = null;
                lock (gate) { if (nat.ContainsKey(key)) orig = nat[key]; }
                if (orig != null)
                {
                    W32(p, 12, Ip(orig));
                    Recalc(p, len);
                    Returned++;
                    if (Returned <= 8 && log != null) log("回程还原 " + orig + " → " + S(dst) + ":" + dport);
                }
            }
        }

        void Recalc(byte[] p, uint len)
        {
            try { WinDivertHelperCalcChecksums(p, len, IntPtr.Zero, 0); } catch { }
        }

        void Clean()
        {
            long now = NowMs();
            lock (gate)
            {
                var dead = new List<string>();
                foreach (var kv in natAt) if (now - kv.Value > 300000) dead.Add(kv.Key);
                foreach (var k in dead) { nat.Remove(k); natAt.Remove(k); }
            }
        }

        static long NowMs() { return (long)(Stopwatch.GetTimestamp() * 1000L / Stopwatch.Frequency); }

        static string S(uint ip) { return (ip >> 24) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 8) & 0xff) + "." + (ip & 0xff); }
        static uint Ip(string s)
        {
            var parts = s.Split('.');
            return ((uint)int.Parse(parts[0]) << 24) | ((uint)int.Parse(parts[1]) << 16) | ((uint)int.Parse(parts[2]) << 8) | (uint)int.Parse(parts[3]);
        }

        // 极简 A 记录查询（绕开系统 DNS，避免被自己的 127.0.0.1 劫持绕圈）
        public static List<string> ResolveA(string name, string server)
        {
            var res = new List<string>();
            try
            {
                using (var udp = new UdpClient())
                {
                    udp.Client.ReceiveTimeout = 1500;
                    var q = new List<byte>();
                    ushort id = (ushort)(new Random().Next(1, 65000));
                    q.AddRange(new byte[] { (byte)(id >> 8), (byte)(id & 0xff), 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0 });
                    foreach (var lab in name.Split('.')) { q.Add((byte)lab.Length); foreach (var c in lab) q.Add((byte)c); }
                    q.AddRange(new byte[] { 0, 0x00, 0x01, 0x00, 0x01 });
                    udp.Send(q.ToArray(), q.Count, server, 53);
                    var ep = new IPEndPoint(IPAddress.Any, 0);
                    var r = udp.Receive(ref ep);
                    int at = 12;
                    while (at < r.Length && r[at] != 0) { at += r[at] + 1; }
                    at += 5;                                  // 跳过 0 结尾 + qtype + qclass
                    int an = ((r[4] << 8) | r[5]) & 0xffff;
                    for (int i = 0; i < an && at + 10 < r.Length; i++)
                    {
                        if ((r[at] & 0xc0) == 0xc0) at += 2; else { while (at < r.Length && r[at] != 0) at += r[at] + 1; at += 1; }
                        ushort type = (ushort)((r[at] << 8) | r[at + 1]);
                        ushort cls = (ushort)((r[at + 2] << 8) | r[at + 3]);
                        uint ttl = (uint)((r[at + 4] << 24) | (r[at + 5] << 16) | (r[at + 6] << 8) | r[at + 7]);
                        ushort rdl = (ushort)((r[at + 8] << 8) | r[at + 9]);
                        at += 10;
                        if (type == 1 && rdl == 4) res.Add(r[at] + "." + r[at + 1] + "." + r[at + 2] + "." + r[at + 3]);
                        at += rdl;
                    }
                }
            }
            catch { }
            return res;
        }
    }
}
