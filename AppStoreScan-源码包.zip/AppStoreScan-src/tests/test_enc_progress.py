"""1.9.0 加密进度改造自测：加密回调、缓存复用、并发去重、预加密线程。"""
import os
import sys
import time
import threading
import tempfile

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
sys.path.insert(0, SRC)

from appstorescan.storecrypto import encrypt_file, encrypted_size, EncCache
from appstorescan import dns as dnsmod
from appstorescan.library import AppItem

PLAIN = "P300012304930000538"
CIPHER = "x" * 172
VARIANT = "p8"
MD5 = "d41d8cd98f00b204e9800998ecf8427e"


def make_item(tmp, pkg="com.test.demo"):
    path = os.path.join(tmp, "big.bin")
    return AppItem(path=path, package=pkg, version_name="1.0", version_code=1,
                   size=os.path.getsize(path), md5=MD5)


def test_encrypt_progress(tmp):
    src = os.path.join(tmp, "big.bin")
    n = 6 * 1024 * 1024 + 37          # 6MB + 尾巴，验证 padding
    with open(src, "wb") as f:
        f.write(os.urandom(n))
    events = []
    dst = src + ".enc"
    t0 = time.time()
    out = encrypt_file(src, dst, PLAIN[:8].encode(), progress=lambda d, t: events.append((d, t)))
    dt = time.time() - t0
    assert out == encrypted_size(n), (out, encrypted_size(n))
    assert events[0][0] < events[0][1], events[:2]
    assert events[-1] == (n, n), events[-1]
    assert all(a[0] <= b[0] for a, b in zip(events, events[1:])), "进度必须单调"
    mb = n / 1048576
    print(f"[1] 加密 {mb:.1f}MB 用时 {dt:.2f}s -> {mb/dt:.0f} MB/s，"
          f"回调 {len(events)} 次，末次 {events[-1]}  OK")


def test_cache_progress_and_reuse(tmp):
    item = make_item(tmp)
    cache = EncCache(os.path.join(tmp, "cache"))
    seen = []
    p1 = cache.get(item, CIPHER, PLAIN, VARIANT, progress=lambda d, t: seen.append((d, t)))
    assert p1 and os.path.exists(p1)
    assert seen[-1] == (item.size, item.size)
    seen2 = []
    t0 = time.time()
    p2 = cache.get(item, CIPHER, PLAIN, VARIANT, progress=lambda d, t: seen2.append((d, t)))
    dt = time.time() - t0
    assert p1 == p2
    assert seen2 == [(item.size, item.size)], seen2
    print(f"[2] 二次命中缓存 {dt*1000:.1f}ms，直接回调 100%  OK")


def test_concurrent_dedup(tmp):
    item = make_item(tmp)
    cache = EncCache(os.path.join(tmp, "cache2"))
    res = []

    def worker():
        res.append(cache.get(item, CIPHER, PLAIN, VARIANT))

    ts = [threading.Thread(target=worker) for _ in range(4)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert len(set(res)) == 1, res
    assert os.path.exists(res[0])
    leftovers = [f for f in os.listdir(cache.dir) if f.endswith(".tmp")]
    assert not leftovers, leftovers
    print("[3] 4 线程并发同一包：只产 1 份密文、无 .tmp 残留  OK")


def test_prewarm(tmp):
    item = make_item(tmp)
    cfg = dnsmod.ServeConfig(apk=item.path)
    cfg.catalog_dir = os.path.join(tmp, "data", "catalog")
    cfg.manual_plain = PLAIN
    cfg.manual_cipher = CIPHER
    cfg.apps = [item]
    cfg.prewarm()
    states = []
    deadline = time.time() + 30
    while time.time() < deadline:
        st = cfg.enc_state
        if st:
            states.append((st["package"], st["done"], st["total"], st.get("error", "")))
            if st.get("error"):
                raise AssertionError(st)
            if st["total"] and st["done"] >= st["total"]:
                break
        time.sleep(0.15)
    assert states, "预加密未产生进度状态"
    mid = [s for s in states if 0 < s[1] < s[2]]
    print(f"[4] prewarm 采到 {len(states)} 个快照，中间态 {len(mid)} 个，终态 {states[-1][:3]}  OK")
    t0 = time.time()
    assert cfg.enc_cache().get(item, CIPHER, PLAIN, VARIANT)
    print(f"[5] 预加密后下载请求取密文 {(time.time()-t0)*1000:.1f}ms  OK")


def test_prewarm_switch_session(tmp):
    """预加密途中换会话值：应放弃旧任务，新会话重新加密。"""
    item = make_item(tmp)
    cfg = dnsmod.ServeConfig(apk=item.path)
    cfg.catalog_dir = os.path.join(tmp, "data", "catalog")
    cfg.manual_plain = PLAIN
    cfg.manual_cipher = CIPHER
    cfg.apps = [item]
    cfg.prewarm()
    time.sleep(0.02)
    cfg.manual_plain = "P300012304930000599"
    cfg.manual_cipher = "y" * 172
    cfg.prewarm()
    deadline = time.time() + 20
    while time.time() < deadline and cfg._pw_thread is not None:
        time.sleep(0.1)
    path = cfg.enc_cache().get(item, cfg.eff_cipher, cfg.eff_plain, VARIANT)
    assert path and os.path.exists(path)
    print("[6] 会话切换后按新密钥重新加密  OK")


def test_no_session(tmp):
    item = make_item(tmp)
    cfg = dnsmod.ServeConfig(apk=item.path)
    cfg.catalog_dir = os.path.join(tmp, "data", "catalog")
    cfg.apps = [item]
    cfg.prewarm()
    time.sleep(0.3)
    assert not cfg.enc_state
    assert cfg._pw_thread is None
    print("[7] 无会话时 prewarm 空转不报错  OK")


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmp:
        test_encrypt_progress(tmp)
        test_cache_progress_and_reuse(tmp)
        test_concurrent_dedup(tmp)
        test_prewarm(tmp)
        test_prewarm_switch_session(tmp)
        test_no_session(tmp)
    print("ALL PASS")
