"""会话桥自测：状态心跳 / 手动值应用 / 清除 / 历史导入 / 预加密进度。"""
import os, sys, json, time, tempfile

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
sys.path.insert(0, SRC)

from appstorescan import dns as dnsmod
from appstorescan.library import AppItem
from appstorescan import sessionio


def wait_state(path, pred, timeout=8):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            if pred(d):
                return d
        except Exception:
            pass
        time.sleep(0.2)
    raise AssertionError("等待状态超时: " + path)


def main():
    tmp = tempfile.mkdtemp()
    apk = os.path.join(tmp, "t.apk")
    open(apk, "wb").write(os.urandom(1024 * 1024 + 7))
    item = AppItem(path=apk, package="com.test.app", version_name="1.0",
                   version_code=1, size=os.path.getsize(apk),
                   md5="d41d8cd98f00b204e9800998ecf8427e")
    cfg = dnsmod.ServeConfig(apk=apk)
    cfg.catalog_dir = os.path.join(tmp, "data", "catalog")
    os.makedirs(cfg.catalog_dir, exist_ok=True)
    cfg.apps = [item]
    cfg.apk_map = {item.package.lower(): item}
    cfg.default_pkg = item.package
    cfg.ip = "127.0.0.1"

    state = os.path.join(tmp, "data", "session_state.json")
    manual = os.path.join(tmp, "data", "manual_session.json")
    sessionio.start_watcher(cfg, state, manual)

    # 1 心跳
    d = wait_state(state, lambda d: "ts" in d)
    assert d["eff_plain"] == "" and d["apps"][0]["package"] == "com.test.app"
    print("[1] 心跳状态 OK，apps =", d["apps"])

    # 2 手动值应用 + 预加密
    with open(manual, "w", encoding="utf-8") as f:
        json.dump({"plain": "P300012304930000538", "cipher": "c" * 172}, f)
    d = wait_state(state, lambda d: d["eff_plain"] == "P300012304930000538")
    assert d["manual_cipher"] == "c" * 172 and not os.path.exists(manual)
    d = wait_state(state, lambda d: d["enc"].get("total", 0) > 0 and d["enc"]["done"] >= d["enc"]["total"], timeout=20)
    print("[2] 手动值应用 + 预加密完成 OK:", d["enc"]["package"], d["enc"]["done"], "/", d["enc"]["total"])

    # 3 清除
    with open(manual, "w", encoding="utf-8") as f:
        json.dump({"clear": True}, f)
    d = wait_state(state, lambda d: d["manual_plain"] == "" and d["manual_cipher"] == "")
    assert d["eff_plain"] == ""
    print("[3] 清除手动值 OK")

    # 4 历史导入（扫真实 app-* 目录）
    p, c, note = sessionio.import_history()
    print("[4] import_history:", note)
    with open(manual, "w", encoding="utf-8") as f:
        json.dump({"import_history": True}, f)
    if c:
        d = wait_state(state, lambda d: d["manual_cipher"] == c, timeout=15)
        print("[4] 历史导入应用 OK，设备号 =", d["eff_plain"])
    else:
        d = wait_state(state, lambda d: "没找到" in d["note"], timeout=15)
        print("[4] 无历史时的提示 OK")

    # 5 心跳新鲜度
    ts1 = json.load(open(state, encoding="utf-8"))["ts"]
    time.sleep(1.2)
    ts2 = json.load(open(state, encoding="utf-8"))["ts"]
    assert ts2 > ts1
    print("[5] 心跳持续更新 OK")
    print("ALL PASS")


if __name__ == "__main__":
    main()
