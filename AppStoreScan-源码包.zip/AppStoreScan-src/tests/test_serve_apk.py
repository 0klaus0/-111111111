"""1.9.1 下发链路测试：无 sdkInit 时发明文（1.6.0 行为）、有 sdkInit 时发密文、断点续传。"""
import os
import sys
import time
import json
import socket
import threading
import urllib.request
import urllib.error
import tempfile

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
sys.path.insert(0, SRC)

from appstorescan import dns as dnsmod
from appstorescan.library import AppItem
from appstorescan.storecrypto import encrypted_size

PLAIN = "P300012304930000538"
CIPHER = "c" * 172
MD5 = "d41d8cd98f00b204e9800998ecf8427e"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_store(tmp, apk_path, size):
    item = AppItem(path=apk_path, package="com.autonavi.amapauto", version_name="1.0",
                   version_code=1, size=size, md5=MD5)
    cfg = dnsmod.ServeConfig(apk=apk_path)
    cfg.catalog_dir = os.path.join(tmp, "data", "catalog")
    os.makedirs(cfg.catalog_dir, exist_ok=True)
    cfg.apps = [item]
    cfg.apk_map = {item.package.lower(): item}
    cfg.default_pkg = item.package
    cfg.ip = "127.0.0.1"
    fs = dnsmod.FakeStore(cfg, port=free_port(), host="127.0.0.1")
    threading.Thread(target=fs.run, daemon=True).start()
    time.sleep(0.6)
    return cfg, fs, item, fs.port


def fetch(port, path, hdrs=None):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", headers=hdrs or {})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status, dict(r.headers), r.read()


def main():
    tmp = tempfile.mkdtemp()
    apk = os.path.join(tmp, "amap.apk")
    payload = os.urandom(2 * 1024 * 1024 + 5)
    open(apk, "wb").write(payload)
    size = len(payload)

    # ---- 场景 1：没有 sdkInit → 必须 200 + 明文（1.6.0 行为，不是 503）
    cfg, fs, item, port = start_store(tmp, apk, size)
    code, hdr, body = fetch(port, f"/dl/{item.package}.apk")
    print(f"[无sdkInit] status={code} len={len(body)} 明文={len(body) == size} "
          f"内容一致={body == payload}")
    assert code == 200 and len(body) == size and body == payload

    # ---- 场景 2：有 sdkInit → 密文，且长度符合公式
    cfg.last_plain = PLAIN
    cfg.last_cipher = CIPHER
    code, hdr, body = fetch(port, f"/dl/{item.package}.apk")
    exp = encrypted_size(size)
    print(f"[有sdkInit] status={code} len={len(body)} 期望={exp} 匹配={len(body) == exp}")
    assert code == 200 and len(body) == exp

    # ---- 场景 3：Range 断点续传（密文）
    code, hdr, body = fetch(port, f"/dl/{item.package}.apk",
                            {"Range": f"bytes={exp // 2}-{exp - 1}"})
    print(f"[Range] status={code} got={len(body)} 期望={exp - exp // 2} "
          f"Content-Range={hdr.get('Content-Range')}")
    assert code == 206 and len(body) == exp - exp // 2

    fs.stop()

    # ---- 场景 4：明细接口的 size/md5 改写（车机按明文校验）
    print("ALL PASS")


if __name__ == "__main__":
    main()
