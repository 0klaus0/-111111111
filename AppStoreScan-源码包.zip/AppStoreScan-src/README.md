# AppStoreScan 源码包

车机商店广播 + 热点劫持的本地调试工具（Python 3.12 / tkinter）。
把任意 APK 通过伪造应用商店列表下发到车机，或用本地 DNS 劫持把车机请求引到本机。

> 仅用于自有车辆、自有设备上的调试与恢复。不要用于他人设备或商业分发。

## 目录结构

```
AppStoreScan-src/
├─ src/
│  ├─ entry.py                     启动入口（PyInstaller 用的）
│  └─ appstorescan/                主程序包
│     ├─ __main__.py               python -m appstorescan 入口
│     ├─ gui.py                    桌面界面（配置 / 启动 / 实时日志 / 会话状态按钮）
│     ├─ session_panel.py          会话自检面板（换车、换电脑排障用）
│     ├─ sessionio.py              无界面模式的会话桥（状态文件+手动值文件，供 StoreCast 外壳显示/填写）
│     ├─ cli.py                    命令行模式
│     ├─ dns.py                    DNS 服务 + 伪造商店（核心）
│     ├─ http.py                   HTTP 服务基类
│     ├─ capture.py                自签 CA、TLS 中间人
│     ├─ storecrypto.py            商店 APK 的 DES 加密（设备号派生 key）
│     ├─ inject.py                 商店列表条目注入 / 字段别名对齐
│     ├─ library.py                本地 APK 扫描与 manifest 解析
│     ├─ hotspot.py                热点检测与开启
│     ├─ netcheck.py               网络/端口自检
│     ├─ storage.py                本地库（apps.db）
│     ├─ phone.py                  手机助手
│     ├─ store_profiles.py         商店域名档案
│     ├─ model.py / context.py     数据结构
│     └─ adapters/                 商店适配（apple / googleplay / xiaomi）
├─ data/
│  └─ apps.db                      商店目录库（可直接跑，后续会自己更新）
├─ packaging/
│  ├─ AppStoreScan.spec            PyInstaller 配置
│  └─ Launcher.cs                  单 exe 启动器（自解压 payload.zip）
└─ README.md
```

## 运行（源码直跑）

```powershell
cd AppStoreScan-src\src
python -m appstorescan          # 打开界面
python -m appstorescan --help   # 命令行用法
```

依赖：Python 3.12+，`cryptography`（DES 加密与证书）。
Windows 上需要管理员权限才能改网卡 DNS、绑定 80/443 端口。

```powershell
pip install cryptography
```

## 打包成 exe

```powershell
cd AppStoreScan-src\packaging
pyinstaller --clean AppStoreScan.spec
```

产物在 `dist\AppStoreScan\`。若要用 WinDivert 劫持模式，把
`WinDivert.dll` 和 `WinDivert64.sys` 复制到 exe 同目录。

单文件版：把 `dist\AppStoreScan\` 整个压成 `payload.zip`，用 `Launcher.cs`
（`dotnet build` 或 csc）编译成启动器，payload 作为资源内嵌。

## 端口与地址

| 用途 | 地址 |
|---|---|
| 伪造商店（HTTP） | `http://<热点IP>:80` |
| 伪造商店（HTTPS） | `https://<热点IP>:443` |
| 车机装 CA 用的证书页 | `http://<热点IP>:8898/` |
| DNS | `<热点IP>:53` |

热点模式默认网关 `192.168.137.1`，车机侧 IP 通常是 `192.168.137.x`。

## 换车 / 换电脑时的排障顺序

1. 启动程序 → 车机连热点 → 打开商店首页刷一次（触发 `sdkInit`）
2. 点界面「会话状态」，看三件事：
   - 设备号是否已捕获
   - `sdkInit cipher` 是否已捕获（空 = 加密会退化成发明文，车机必然装不上）
   - 待下发 APK 的密文是"就绪"还是"过期"（过期 = 还是上一台车的 key）
3. 密文过期 → 面板里点「清空密文缓存」，再重新下载
4. 换了电脑 → 新电脑会生成新的 CA，必须用 `http://<热点IP>:8898/`
   重新给车机装一次证书，否则 HTTPS 全部握手失败

## 商店加密机制（排障要用的核心事实）

- 车机在 `sdkInit` 请求里带上设备号（`x-device` / `x-cid`，或响应体 `plainText`）
- 本地 DES key = 设备号前 8 字节，`DES-ECB-PKCS7`
- 密文长度 = `floor(n/8)*8 + 8`，上报给车机的 size/md5 仍是明文值
- 密文缓存文件名 `{package}.{sha1(cipher|variant)[:16]}.enc`
- `detail_variant.txt` 可切换派生方式，缺省为 `des-p8`

设备号换了但密文缓存没清 → 车机下载到 100% 后解密失败 → 卡在 100%。

## 版本

- 1.6.0 手机热点中介版：把 APK 经商店下发到车机，实测安装成功（本包的**下发行为基线**）
- 1.7.0 加入 `session_panel.py`（会话自检面板 + 一键清密文缓存）、多包广播
- 1.8.0 不写死设备号：运行时从 `sdkInit` 捕获、捕获不到可手动填；主页面流程图；CA 证书提醒
- 1.9.1 按成功版（v1.6.0）的下发行为回退，只保留新增的界面与进度：
  - **拿不到 `sdkInit` 时不再 503 拒绝，照旧发明文并记「无sdkInit·明文下发」**（1.6.0 就是这么成功的）
  - 加密过程出错时也退到明文兜底，不再返回 500
  - 加密算法与 1.6.0 做过逐字节比对：同一 APK + 同一设备号，密文 SHA256 完全相同，
    6 种密钥派生（p8 / p8tail / md5 / md5hex / sha256 / sha1）全部一致
  - 捕获到 `sdkInit` 后自动**后台预加密**（`ServeConfig.prewarm()`），车机点下载时几乎立刻开传
  - 主页面流程图下方出现进度条：包名 / 百分比 / 已处理-总大小 / 实时速度 / 剩余秒数
  - 加密失败打红字并给出原因，不再静默干等
  - 修复打包链：改用自带 tcl/tk 的完整 Python 打包，之前用的精简 Python 缺 tcl，
    打出来的 exe 会静默退回文本菜单（看不到界面）
- 1.7.2 **以 StoreCast 1.7.0 成功版界面为基线**，把升级功能全部并进黑色日志窗界面：
  - 按钮排新增「会话状态」；日志窗上方新增会话状态条：设备号/cipher 捕获状态（绿=就绪）+ 加密进度条
  - 头部新增七步流程提示（①开热点②车机连网③装CA证书④开始广播⑤刷商店⑥核对会话⑦下载安装），随状态打 ✔
  - 「会话状态」窗口：自动捕获值展示、手动填写设备号+cipher、从历史日志导入（扫所有旧版本目录）、
    清除手动值、清空密文缓存、实时加密进度
  - 点「开始广播」后日志自动提醒装车机 CA 证书（http://<热点IP>:8898/）
  - 实现：内层 `sessionio.py` 每 0.8s 写 `data/session_state.json`（含心跳），
    外壳每秒轮询；手动操作写 `data/manual_session.json`，内层消费后删除并自动重新预加密
  - 外壳编译需额外引用 `System.Web.Extensions.dll`（JavaScriptSerializer 解析状态文件）
