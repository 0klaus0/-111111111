"""PyInstaller 打包入口。"""

import sys

from appstorescan.cli import run

if __name__ == "__main__":
    sys.exit(run())
