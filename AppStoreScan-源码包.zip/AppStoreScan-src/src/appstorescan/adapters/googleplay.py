"""Google Play 适配器。

说明：Google Play 没有公开的目录 API，这里解析的是公开网页（play.google.com）。
大陆网络无法直连，需要设置代理：--proxy http://127.0.0.1:7890

能力：搜索、榜单（免费/付费/畅销）、详情。
"""

from __future__ import annotations

import json
import re

from ..model import AppRecord

BASE = "https://play.google.com"
ID_RE = re.compile(r"/store/apps/details\?id=([A-Za-z0-9_.]+)")
LDJSON_RE = re.compile(r'<script type="application/ld\+json">(.*?)</script>', re.S)
INSTALLS_RE = re.compile(r'([\d.,]+\s*[KMB]?\+)\s*</div>')
VERSION_RE = re.compile(r'Current Version</div>.{0,200}?>([\d.]+[^<]*)<', re.S)


class GooglePlayAdapter:
    name = "googleplay"
    label = "Google Play（需要能访问 Google 的网络）"
    modes = ("charts", "search", "detail")

    def __init__(self, ctx):
        self.ctx = ctx
        self.http = ctx.http

    def _hl(self, country="us"):
        return {"hl": "en", "gl": (country or "us").upper()}

    # -- 榜单 -------------------------------------------------------------
    def charts(self, countries, collection="topselling_free", limit=100):
        for cc in countries or ["us"]:
            key = f"googleplay|charts|{cc}|{collection}"
            if self.ctx.store.task_done(key):
                continue
            url = f"{BASE}/store/apps/collection/{collection}"
            try:
                page = self.http.get(url, params={**self._hl(cc), "num": 100}).text()
            except Exception as e:
                self.ctx.error(f"Google Play 榜单失败（多半是网络不通，试试 --proxy）: {e}")
                continue
            ids = _unique_ids(page)[:limit]
            self.ctx.log(f"[{cc}] {collection} 榜单 {len(ids)} 个应用")
            for pkg in ids:
                rec = self._detail(pkg, cc)
                if rec:
                    rec.source = f"charts:{cc}:{collection}"
                    self.ctx.emit(rec)
            self.ctx.store.mark_task(key, len(ids))

    # -- 搜索 -------------------------------------------------------------
    def search(self, keywords, country="us", limit=60, with_detail=True):
        for kw in keywords:
            key = f"googleplay|search|{country}|{kw}"
            if self.ctx.store.task_done(key):
                continue
            try:
                page = self.http.get(f"{BASE}/store/search",
                                     params={"q": kw, "c": "apps", **self._hl(country)}).text()
            except Exception as e:
                self.ctx.error(f"搜索「{kw}」失败（多半是网络不通，试试 --proxy）: {e}")
                continue
            ids = _unique_ids(page)[:limit]
            self.ctx.log(f"搜索「{kw}」({country}) 得到 {len(ids)} 个应用")
            for pkg in ids:
                if with_detail:
                    rec = self._detail(pkg, country)
                else:
                    rec = AppRecord(store="googleplay", app_id=pkg, country=country,
                                    url=f"{BASE}/store/apps/details?id={pkg}")
                if rec:
                    rec.source = f"search:{kw}"
                    self.ctx.emit(rec)
            self.ctx.store.mark_task(key, len(ids))

    # -- 详情 -------------------------------------------------------------
    def detail(self, app_ids, country="us"):
        for pkg in app_ids:
            rec = self._detail(pkg, country)
            if rec:
                rec.source = "detail"
                self.ctx.emit(rec)

    def _detail(self, pkg, country="us"):
        try:
            page = self.http.get(f"{BASE}/store/apps/details", params={"id": pkg, **self._hl(country)}).text()
        except Exception as e:
            self.ctx.error(f"详情 {pkg} 失败: {e}")
            return None
        return _parse_detail(page, pkg, country)


def _unique_ids(page):
    seen, out = set(), []
    for pkg in ID_RE.findall(page):
        if pkg not in seen:
            seen.add(pkg)
            out.append(pkg)
    return out


def _parse_detail(page, pkg, country):
    rec = AppRecord(store="googleplay", app_id=pkg, country=country,
                    url=f"{BASE}/store/apps/details?id={pkg}")

    for block in LDJSON_RE.findall(page):
        try:
            data = json.loads(block)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict) and data.get("@type") in ("SoftwareApplication", "MobileApplication"):
            rec.name = data.get("name", "") or rec.name
            rec.developer = (data.get("author") or {}).get("name", "") if isinstance(data.get("author"), dict) else rec.developer
            rec.category = data.get("applicationCategory", "") or rec.category
            rec.description = (data.get("description") or "")[:2000]
            rec.icon = data.get("image", "") or rec.icon
            agg = data.get("aggregateRating") or {}
            if agg:
                try:
                    rec.rating = float(agg.get("ratingValue"))
                except (TypeError, ValueError):
                    pass
                try:
                    rec.rating_count = int(str(agg.get("ratingCount", "")).replace(",", ""))
                except (TypeError, ValueError):
                    pass
            offers = data.get("offers") or {}
            if isinstance(offers, dict):
                price = offers.get("price")
                rec.price = "免费" if str(price) in ("0", "0.0") else f"{offers.get('priceCurrency', '')} {price}"
                rec.currency = offers.get("priceCurrency", "")
            break

    if not rec.name:
        m = re.search(r"<title[^>]*>(.*?)</title>", page, re.S)
        if m:
            rec.name = m.group(1).split(" - ")[0].strip()

    m = INSTALLS_RE.search(page)
    if m:
        rec.installs = re.sub(r"\s+", "", m.group(1))
    m = VERSION_RE.search(page)
    if m:
        rec.version = m.group(1).strip()

    return rec
