"""适配器注册表。要新增商店，在 ADAPTERS 里加一行即可。"""

from .apple import AppleAdapter
from .googleplay import GooglePlayAdapter
from .xiaomi import XiaomiAdapter

ADAPTERS = {
    AppleAdapter.name: AppleAdapter,
    GooglePlayAdapter.name: GooglePlayAdapter,
    XiaomiAdapter.name: XiaomiAdapter,
}


def get_adapter(name):
    if name not in ADAPTERS:
        raise KeyError(f"未知商店: {name}，可选: {', '.join(ADAPTERS)}")
    return ADAPTERS[name]


def all_adapters():
    return list(ADAPTERS.values())
