"""Apple App Store 适配器。

使用苹果官方的 iTunes Search API 与 RSS 榜单，无需登录、无需密钥：
  * 搜索：https://itunes.apple.com/search
  * 榜单：https://itunes.apple.com/{国家}/rss/{榜单}/limit=100/genre={分类}/json
  * 详情：https://itunes.apple.com/lookup?id=...
官方文档：https://performance-partners.apple.com/search-api
"""

from __future__ import annotations

import time

from ..model import AppRecord

BASE = "https://itunes.apple.com"
FEEDS = {
    "free": "topfreeapplications",
    "paid": "toppaidapplications",
    "grossing": "topgrossingapplications",
}
# 这些国家/地区的榜单可以匿名访问
COUNTRIES = ["cn", "hk", "tw", "us", "jp", "kr", "sg", "gb", "de", "fr", "ca", "au"]

FALLBACK_GENRES = {
    "6000": "商务", "6001": "天气", "6002": "工具", "6003": "旅行", "6004": "体育",
    "6005": "社交", "6006": "参考", "6007": "效率", "6008": "摄影与录像", "6009": "新闻",
    "6010": "导航", "6011": "音乐", "6012": "生活", "6013": "健康健美", "6014": "游戏",
    "6015": "财务", "6016": "娱乐", "6017": "教育", "6018": "图书", "6020": "医疗",
    "6021": "报刊杂志", "6022": "目录", "6023": "美食佳饮", "6024": "购物", "6025": "贴纸",
    "6026": "开发者工具", "6027": "图形与设计",
}


class AppleAdapter:
    name = "apple"
    label = "Apple App Store（iPhone / iPad）"
    modes = ("charts", "search", "lookup")

    def __init__(self, ctx):
        self.ctx = ctx
        self.http = ctx.http

    # -- 榜单 -------------------------------------------------------------
    def charts(self, countries, feed="free", genres=None, limit=100):
        countries = countries or ["cn"]
        for cc in countries:
            genre_ids = genres or list(self._genres().keys())
            for gid in genre_ids:
                gname = self._genres().get(gid, gid)
                key = f"apple|charts|{cc}|{feed}|{gid}|{limit}"
                if self.ctx.store.task_done(key):
                    self.ctx.log(f"跳过已完成任务 {key}")
                    continue

                url = f"{BASE}/{cc}/rss/{FEEDS.get(feed, FEEDS['free'])}/limit={min(limit, 100)}/genre={gid}/json"
                try:
                    data = self.http.get(url).json()
                except Exception as e:
                    self.ctx.error(f"榜单失败 {cc}/{gid}: {e}")
                    continue

                entries = (data.get("feed") or {}).get("entry") or []
                ids = []
                for e in entries:
                    aid = _id_of(e)
                    if aid:
                        ids.append(aid)
                self.ctx.log(f"[{cc}] {gname} {feed} 榜单 {len(ids)} 个应用")

                found = 0
                for rec in self._lookup_batches(ids, country=cc):
                    rec.category = rec.category or gname
                    rec.source = f"charts:{cc}:{feed}:{gid}"
                    self.ctx.emit(rec)
                    found += 1
                self.ctx.store.mark_task(key, found)

    # -- 搜索 -------------------------------------------------------------
    def search(self, keywords, country="cn", limit=50):
        country = country or "cn"
        for kw in keywords:
            key = f"apple|search|{country}|{kw}|{limit}"
            if self.ctx.store.task_done(key):
                self.ctx.log(f"跳过已完成任务 {key}")
                continue
            params = {
                "term": kw,
                "country": country,
                "entity": "software",
                "limit": min(int(limit), 200),
            }
            try:
                data = self.http.get(f"{BASE}/search", params=params).json()
            except Exception as e:
                self.ctx.error(f"搜索失败 {kw}: {e}")
                continue
            results = data.get("results") or []
            self.ctx.log(f"搜索「{kw}」({country}) 得到 {len(results)} 个结果")
            for item in results:
                rec = _from_search_result(item, country)
                rec.source = f"search:{kw}"
                self.ctx.emit(rec)
            self.ctx.store.mark_task(key, len(results))

    # -- 详情 -------------------------------------------------------------
    def lookup(self, app_ids, country="cn"):
        for rec in self._lookup_batches(app_ids, country=country):
            rec.source = "lookup"
            self.ctx.emit(rec)

    # -- 内部 -------------------------------------------------------------
    def _genres(self):
        if getattr(self, "_genre_cache", None):
            return self._genre_cache
        genres = {}
        try:
            data = self.http.get(
                f"{BASE}/WebObjects/MZStoreServices.woa/ws/genres", {"id": "36"}
            ).json()
            subs = (data.get("36") or {}).get("subgenres") or {}
            for gid, g in subs.items():
                # 官方接口给的是英文分类名，中文名优先用内置表
                genres[gid] = FALLBACK_GENRES.get(gid) or g.get("name") or gid
        except Exception as e:
            self.ctx.error(f"获取分类列表失败，使用内置分类表: {e}")
            genres = dict(FALLBACK_GENRES)
        if not genres:
            genres = dict(FALLBACK_GENRES)
        self._genre_cache = genres
        return genres

    def _lookup_batches(self, app_ids, country="cn", batch=100):
        ids = [str(i) for i in app_ids if i]
        for i in range(0, len(ids), batch):
            chunk = ids[i:i + batch]
            params = {"id": ",".join(chunk), "country": country}
            try:
                data = self.http.get(f"{BASE}/lookup", params=params).json()
            except Exception as e:
                self.ctx.error(f"lookup 失败 ({len(chunk)} 个 id): {e}")
                continue
            for item in data.get("results") or []:
                rec = _from_lookup(item, country)
                if rec:
                    yield rec


# -- 解析 ----------------------------------------------------------------
def _id_of(entry):
    try:
        return entry["id"]["attributes"]["im:id"]
    except (KeyError, TypeError):
        return None


def _from_search_result(it, country):
    return AppRecord(
        store="apple",
        app_id=str(it.get("trackId", "")),
        name=it.get("trackName", ""),
        developer=it.get("artistName", "") or it.get("sellerName", ""),
        category=_genre_name(it),
        price=it.get("formattedPrice", ""),
        currency=it.get("currency", ""),
        rating=_rating(it.get("averageUserRating")),
        rating_count=it.get("userRatingCount"),
        version=it.get("version", ""),
        updated=_date(it.get("currentVersionReleaseDate") or it.get("releaseDate")),
        size=_size(it.get("fileSizeBytes")),
        url=it.get("trackViewUrl", ""),
        icon=it.get("artworkUrl512", "") or it.get("artworkUrl100", ""),
        description=(it.get("description") or "")[:2000],
        country=country,
    )


def _from_lookup(it, country):
    if not it.get("trackId"):
        return None
    rec = AppRecord(
        store="apple",
        app_id=str(it["trackId"]),
        name=it.get("trackName", ""),
        developer=it.get("artistName", "") or it.get("sellerName", ""),
        category=_genre_name(it),
        price=it.get("formattedPrice", ""),
        currency=it.get("currency", ""),
        rating=_rating(it.get("averageUserRating")),
        rating_count=it.get("userRatingCount"),
        version=it.get("version", ""),
        updated=_date(it.get("currentVersionReleaseDate") or it.get("releaseDate")),
        size=_size(it.get("fileSizeBytes")),
        url=it.get("trackViewUrl", ""),
        icon=it.get("artworkUrl512", "") or it.get("artworkUrl100", ""),
        description=(it.get("description") or "")[:2000],
        country=country,
    )
    rec.overwrite = True  # lookup 返回的是详情字段，覆盖榜单里的占位值
    return rec


def _rating(v):
    try:
        return round(float(v), 2)
    except (TypeError, ValueError):
        return None


def _genre_name(it):
    """分类名：接口返回英文，能映射成中文就用中文。"""
    gid = str(it.get("primaryGenreId", "") or "")
    return FALLBACK_GENRES.get(gid) or it.get("primaryGenreName", "")


def _date(val):
    if not val:
        return ""
    return str(val)[:10]


def _size(val):
    try:
        n = int(val)
    except (TypeError, ValueError):
        return ""
    return f"{n / 1024 / 1024:.1f} MB"
