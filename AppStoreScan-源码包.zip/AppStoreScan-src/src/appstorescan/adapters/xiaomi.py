"""小米应用商店适配器（app.mi.com 网页版）。

小米商店的网页端是服务端渲染的 HTML，列表页里内嵌了一段 JS 数组/HTML 列表，
直接解析即可，不需要登录。因为网页改版会导致失效，解析做了多重兜底。

覆盖能力：分类浏览（每个分类约 30~40 个应用）+ 关键词搜索 + 详情补全。
"""

from __future__ import annotations

import html
import re

from ..model import AppRecord

BASE = "https://app.mi.com"
ITEM_RE = re.compile(r"<li>(.*?)</li>", re.S)
ID_RE = re.compile(r'href="/details\?id=([^"&]+)"')
NAME_RE = re.compile(r"<h5>\s*<a[^>]*>(.*?)</a>", re.S)
CAT_RE = re.compile(r'class="app-desc">\s*<a[^>]*>(.*?)</a>', re.S)
ICON_RE = re.compile(r'data-src="([^"]+)"')
TAG_RE = re.compile(r"<[^>]+>")


class XiaomiAdapter:
    name = "xiaomi"
    label = "小米应用商店（app.mi.com 网页版）"
    modes = ("categories", "detail")

    def __init__(self, ctx):
        self.ctx = ctx
        self.http = ctx.http

    # -- 分类 -------------------------------------------------------------
    def categories(self, only=None, with_detail=False):
        cats = self.list_categories()
        if only:
            want = {str(x).strip() for x in only}
            cats = [(cid, cname) for cid, cname in cats if cid in want or cname in want]
        if not cats:
            self.ctx.error("没有取到任何分类，网页结构可能已经变化。")
            return
        self.ctx.log(f"共 {len(cats)} 个分类待扫描")
        for cid, cname in cats:
            key = f"xiaomi|cat|{cid}"
            if self.ctx.store.task_done(key):
                continue
            recs = self._list_category(cid, cname)
            self.ctx.log(f"分类「{cname}」({cid}) 拿到 {len(recs)} 个应用")
            for rec in recs:
                if with_detail:
                    rec = self._fill_detail(rec) or rec
                self.ctx.emit(rec)
            self.ctx.store.mark_task(key, len(recs))

    def list_categories(self):
        """从首页导航里抓分类 id 与名称。"""
        try:
            page = self.http.get(BASE + "/").text()
        except Exception as e:
            self.ctx.error(f"打开小米商店首页失败: {e}")
            return []
        pairs = re.findall(r'href="/category/(\d+)"[^>]*>\s*([^<]{1,20}?)\s*<', page)
        seen, out = set(), []
        for cid, cname in pairs:
            cname = html.unescape(TAG_RE.sub("", cname)).strip()
            if not cname or cid in seen:
                continue
            seen.add(cid)
            out.append((cid, cname))
        return out

    def _list_category(self, cid, cname):
        """分类页比 /category/{id} 条目更多。"""
        recs = []
        for path in (f"/hotCatApp/{cid}", f"/category/{cid}"):
            try:
                page = self.http.get(BASE + path).text()
            except Exception as e:
                self.ctx.error(f"分类页 {path} 失败: {e}")
                continue
            recs = self._parse_list(page, cname)
            if recs:
                break
        return recs

    # -- 解析 -------------------------------------------------------------
    def _parse_list(self, page, cname):
        recs, seen = [], set()
        for block in ITEM_RE.findall(page):
            m = ID_RE.search(block)
            if not m:
                continue
            pkg = m.group(1)
            if pkg in seen:
                continue
            seen.add(pkg)

            name = ""
            nm = NAME_RE.search(block)
            if nm:
                name = html.unescape(TAG_RE.sub("", nm.group(1))).strip()
            if not name:
                alt = re.search(r'alt="([^"]+)"', block)
                name = html.unescape(alt.group(1)).strip() if alt else ""

            cat = ""
            cm = CAT_RE.search(block)
            if cm:
                cat = html.unescape(TAG_RE.sub("", cm.group(1))).strip()

            icon = ""
            im = ICON_RE.search(block)
            if im:
                icon = im.group(1)

            recs.append(AppRecord(
                store="xiaomi",
                app_id=pkg,
                name=name,
                category=cat or cname,
                url=f"{BASE}/details?id={pkg}",
                icon=icon,
                country="cn",
            ))
        return recs

    # -- 搜索 -------------------------------------------------------------
    # 说明：app.mi.com 的 /search 页面已经改成前端渲染，服务端返回的是首页内容，
    # 抓不到真实搜索结果，所以不提供搜索模式。需要按名称找应用时，用分类扫描后
    # 在表格里筛选，或者用下面 detail 模式直接按包名补数据。

    # -- 详情 -------------------------------------------------------------
    def detail(self, app_ids):
        for pkg in app_ids:
            rec = AppRecord(store="xiaomi", app_id=pkg, url=f"{BASE}/details?id={pkg}", country="cn")
            rec = self._fill_detail(rec) or rec
            rec.source = "detail"
            self.ctx.emit(rec)

    def _fill_detail(self, rec):
        try:
            page = self.http.get(f"{BASE}/details?id={rec.app_id}").text()
        except Exception as e:
            self.ctx.error(f"详情 {rec.app_id} 失败: {e}")
            return None

        # 标题形如 "<title>微信-小米应用商店</title>"
        m = re.search(r"<title>(.*?)</title>", page, re.S)
        if m:
            title = html.unescape(TAG_RE.sub("", m.group(1))).strip()
            name = title.split("-")[0].strip()
            if name:
                rec.name = name

        fields = _kv(page)
        rec.version = rec.version or fields.get("版本号", "")
        rec.updated = rec.updated or fields.get("更新时间", "")
        rec.size = rec.size or fields.get("软件大小", "")
        rec.developer = rec.developer or fields.get("开发者", "")

        m = re.search(r"<b>\s*分类\s*[：:]\s*</b>\s*([^<|]+)", page)
        if m:
            rec.category = html.unescape(m.group(1)).strip() or rec.category

        # 评分：星级宽度 star1-N，N 为 0~10
        m = re.search(r"star1-hover\s+star1-(\d+)", page)
        if m:
            try:
                rec.rating = round(int(m.group(1)) / 2, 1)
            except ValueError:
                pass
        m = re.search(r"\(\s*([\d,]+)\s*次评分\s*\)", page)
        if m:
            try:
                rec.rating_count = int(m.group(1).replace(",", ""))
            except ValueError:
                pass

        # 应用介绍
        m = re.search(r'<h3>\s*应用介绍\s*</h3>\s*<p class="pslide">(.*?)</p>', page, re.S)
        if m:
            rec.description = html.unescape(TAG_RE.sub("", m.group(1))).strip()[:2000]

        rec.overwrite = True  # 详情页字段更权威，允许覆盖列表页的旧值
        return rec


def _kv(page):
    """详情页用「左 label / 右 value」两个 div 展示属性，冒号是 CSS 画出来的。"""
    out = {}
    pattern = re.compile(
        r'<div style="float:\s*left">\s*([^<]{1,10}?)\s*</div>\s*'
        r'<div style="[^"]*float:\s*right[^"]*"[^>]*>\s*(.*?)\s*</div>',
        re.S,
    )
    for label, value in pattern.findall(page):
        label = label.strip().rstrip("：:")
        value = html.unescape(TAG_RE.sub("", value)).strip()
        if label and label not in out:
            out[label] = value
    return out
