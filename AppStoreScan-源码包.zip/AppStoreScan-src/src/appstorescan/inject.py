"""把一个自定义条目注入到商店返回的 JSON 列表里。

不同商店的目录结构差别很大，这里不做硬编码：递归找出响应中最像“应用列表”的那个
数组（元素是对象、且带包名/名称/下载地址一类的键），把你的条目追加进去。
"""

from __future__ import annotations

import copy
import hashlib
import json

PACKAGE_KEYS = ("packagename", "package_name", "pkgname", "pkg", "apkid", "appid", "id")
NAME_KEYS = ("name", "appname", "app_name", "title", "displayname", "display_name")
URL_KEYS = ("url", "downloadurl", "download_url", "apkurl", "apk_url", "fileurl", "link")


def _lower_keys(d):
    return {k.lower(): k for k in d.keys()} if isinstance(d, dict) else {}


def _score(item):
    if not isinstance(item, dict):
        return 0
    keys = _lower_keys(item)
    score = 0
    if any(k in keys for k in PACKAGE_KEYS):
        score += 3
    if any(k in keys for k in NAME_KEYS):
        score += 2
    if any(k in keys for k in URL_KEYS):
        score += 1
    return score


def find_best_list(node, _path=""):
    """深度遍历，返回 (列表引用, 平均得分)。"""
    best = (None, 0.0, _path)
    if isinstance(node, dict):
        for k, v in node.items():
            if isinstance(v, list) and v:
                scores = [_score(i) for i in v]
                avg = sum(scores) / len(scores)
                if avg > best[1]:
                    best = (v, avg, f"{_path}/{k}")
            else:
                cand = find_best_list(v, f"{_path}/{k}")
                if cand[0] is not None and cand[1] > best[1]:
                    best = cand
    elif isinstance(node, list):
        for i, v in enumerate(node):
            cand = find_best_list(v, f"{_path}[{i}]")
            if cand[0] is not None and cand[1] > best[1]:
                best = cand
    return best


def _existing_packages(lst):
    out = set()
    for item in lst:
        if not isinstance(item, dict):
            continue
        keys = _lower_keys(item)
        for k in PACKAGE_KEYS:
            if k in keys:
                val = item[keys[k]]
                if isinstance(val, str):
                    out.add(val.lower())
                break
    return out


def inject_entry(payload, entry):
    """把 entry 追加到最合适的列表里。返回 (新的 payload, 是否注入, 说明)。"""
    if not isinstance(entry, dict) or not entry.get("packageName"):
        return payload, False, "条目缺少 packageName"

    lst, score, path = find_best_list(payload)
    if lst is None or score < 2:
        return payload, False, "响应里没找到像应用列表的数组"

    if entry["packageName"].lower() in _existing_packages(lst):
        return payload, False, "列表里已有这个包名"

    # 优先“照抄列表里已有的一项”，这样字段名、嵌套结构都和商店一致，
    # 商店的解析器才不会因为缺字段而忽略我们。
    base = next((i for i in lst if isinstance(i, dict) and _score(i) >= 3), None)
    if base is not None:
        item = copy.deepcopy(base)
        _apply_overrides(item, entry)
        how = "克隆已有条目"
    else:
        item = dict(entry)
        item.pop("_comment", None)
        how = "直接追加"

    lst.insert(0, item)
    return payload, True, f"{how} → {path}（共 {len(lst)} 项）"


OVERRIDE_MAP = {
    "name": ("name", "appname", "app_name", "displayname", "display_name", "title", "applabel"),
    "packageName": ("packagename", "package_name", "pkgname", "pkg_name", "pkg",
                   "packageid", "package_id", "apkid", "apk_id"),
    "versionName": ("versionname", "version_name", "version", "ver"),
    "versionCode": ("versioncode", "version_code", "build", "buildno",
                    "softversion", "soft_version", "versionno", "version_no"),
    "size": ("size", "filesize", "file_size", "apksize", "apk_size", "length", "bytes"),
    "md5": ("md5", "filemd5", "file_md5", "hash", "sign", "checksum"),
    "downloadUrl": ("downloadurl", "download_url", "apkurl", "apk_url", "fileurl", "url", "link"),
    "icon": ("icon", "iconurl", "icon_url", "logo", "iconpath", "icon_path"),
}

# 这些键是商店内部的条目 ID，克隆会重复，按包名生成一个稳定的数字 ID
ID_KEYS = ("appid", "app_id", "entryid", "entry_id", "itemid", "item_id", "appkey",
           "id", "softid", "soft_id")


def _stable_id(package_name):
    digits = "".join(ch for ch in hashlib.md5(package_name.encode("utf-8")).hexdigest() if ch.isdigit())
    return int(digits[:8] or "1")


def _apply_overrides(item, entry, _depth=0):
    """按“键名像什么”把 entry 的值写进克隆出来的条目，兼容多层嵌套。"""
    if not isinstance(item, dict) or _depth > 3:
        return
    for key, value in list(item.items()):
        lower = key.lower()
        replaced = False
        for field, aliases in OVERRIDE_MAP.items():
            if lower in aliases and entry.get(field) not in (None, ""):
                item[key] = entry[field]
                replaced = True
                break
        if not replaced and lower in ID_KEYS and isinstance(value, (int, str)):
            item[key] = _stable_id(entry.get("packageName", "x"))
            replaced = True
        if not replaced and isinstance(value, dict):
            _apply_overrides(value, entry, _depth + 1)


def inject_entries(payload, entries):
    """一次注入多条条目（多包广播）。返回 (payload, 是否有注入, 说明)。"""
    notes = []
    last_reason = ""
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        payload, ok, msg = inject_entry(payload, entry)
        if ok:
            notes.append(entry.get("packageName") or "?")
        else:
            last_reason = msg
    if not notes:
        return payload, False, last_reason or "没有可注入的条目"
    return payload, True, "注入 " + "、".join(notes)


def load_entry(path):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def make_template(apk_path, package_name, app_name, server_ip, http_port, apk_md5, apk_size):
    """生成一个可直接用的上架条目模板。"""
    pkg = package_name or "com.example.myapp"
    return {
        "_comment": "改这个文件可以让商店列表里出现你自己的应用，改完重启程序生效",
        "packageName": pkg,
        "name": app_name or "我的应用",
        "versionName": "9.9.9",
        "versionCode": 999999,
        "size": apk_size,
        "md5": apk_md5,
        "downloadUrl": f"http://{server_ip}:{http_port}/dl/{pkg}.apk",
        "icon": "",
        "summary": "由 AppStoreScan 注入",
        "developer": "me",
    }
