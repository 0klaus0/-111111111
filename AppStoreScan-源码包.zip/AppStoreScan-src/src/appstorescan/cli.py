"""命令行入口 + 双击启动时的交互菜单。"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import socket
import threading
import sys
import time
import traceback

from .adapters import ADAPTERS, get_adapter
from .context import Context
from .http import HttpClient
from .storage import Store

PROJECT_DIR = (
    os.path.dirname(sys.executable)
    if getattr(sys, "frozen", False)          # PyInstaller 打包后，数据跟着 exe 走
    else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)
DEFAULT_DB = os.path.join(PROJECT_DIR, "data", "apps.db")
ERROR_LOG = os.path.join(PROJECT_DIR, "data", "error.log")


class CliError(RuntimeError):
    """参数/用法错误，打印一行提示即可，不需要堆栈。"""


# --------------------------------------------------------------------------
# 双击启动：没有参数就进菜单，避免"窗口一闪就没"
# --------------------------------------------------------------------------
MENU = """
============================================================
  应用商店目录扫描器  v1.0
  数据文件：{db}
============================================================
  1) 苹果商店 · 中国区免费榜（27 个分类）
  2) 苹果商店 · 中国区三个榜（免费/付费/畅销）
  3) 苹果商店 · 关键词搜索
  4) 小米商店 · 全部分类（较慢，约 350 条）
  5) 导出数据到 data\\apps.csv
  6) 查看数据统计
  0) 退出
"""


def _pause(msg="按回车键继续..."):
    """只有连着控制台时才等回车，脚本/管道调用时不会卡住。"""
    try:
        if sys.stdin and sys.stdin.isatty():
            input(msg)
    except (EOFError, KeyboardInterrupt):
        pass


def _log_error(text):
    try:
        os.makedirs(os.path.dirname(ERROR_LOG), exist_ok=True)
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n{text}\n")
    except OSError:
        pass


def wizard(db=DEFAULT_DB):
    while True:
        print(MENU.format(db=db))
        try:
            choice = input("请选择 [0-6]：").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if choice in ("0", "q", "Q", ""):
            return 0
        elif choice == "1":
            _run_and_pause(["scan", "--store", "apple", "--mode", "charts",
                            "--countries", "cn", "--feed", "free", "--db", db])
        elif choice == "2":
            _run_and_pause(["scan", "--store", "apple", "--mode", "charts",
                            "--countries", "cn", "--feed", "all", "--db", db])
        elif choice == "3":
            kw = input("输入关键词，多个用逗号隔开（例如 记账,健身,番茄钟）：").strip()
            if not kw:
                print("没有输入关键词，返回菜单。\n")
                continue
            _run_and_pause(["scan", "--store", "apple", "--mode", "search",
                            "--keywords", kw, "--limit", "100", "--db", db])
        elif choice == "4":
            _run_and_pause(["scan", "--store", "xiaomi", "--mode", "categories",
                            "--detail", "--db", db])
        elif choice == "5":
            out = os.path.join(os.path.dirname(db), "apps.csv")
            _run_and_pause(["export", "--out", out, "--db", db])
        elif choice == "6":
            _run_and_pause(["stats", "--db", db])
        else:
            print("输入无效，请重新选择。\n")


def _run_and_pause(argv):
    print()
    try:
        main(argv)
    except CliError as e:
        print(f"[错误] {e}")
    except SystemExit:
        pass
    except KeyboardInterrupt:
        print("\n已中断。")
    except Exception:
        tb = traceback.format_exc()
        print(tb, file=sys.stderr)
        _log_error(tb)
        print(f"\n出错了，详情已写入 {ERROR_LOG}")
    _pause("\n按回车返回菜单...")


# --------------------------------------------------------------------------
# 入口
# --------------------------------------------------------------------------
def run(argv=None):
    """真正的程序入口：兜住所有异常，双击启动时不至于一闪而过。"""
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "gui":
        argv = []
    # 输出被重定向到文件时，避免个别字符编码不了导致崩溃
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    try:
        if not argv:
            rc = _launch_gui_or_menu()
        else:
            rc = main(argv)
    except CliError as e:
        print(f"[错误] {e}", file=sys.stderr)
        _pause("按回车键退出...")
        return 2
    except SystemExit as e:
        # argparse 的正常退出（--help 等），不当作错误
        return e.code if isinstance(e.code, int) else 0
    except KeyboardInterrupt:
        print("\n已取消。")
        return 130
    except Exception:
        tb = traceback.format_exc()
        print(tb, file=sys.stderr)
        _log_error(tb)
        print(f"\n程序出错，详情已写入 {ERROR_LOG}")
        _pause("按回车键退出...")
        return 1
    return rc or 0


def _launch_gui_or_menu():
    """没有参数时优先开图形界面；没有 tkinter 就退回文字菜单。"""
    try:
        from .gui import run_gui
    except Exception:
        return wizard()
    return run_gui()


def build_parser():
    p = argparse.ArgumentParser(
        prog="appstorescan",
        description="应用商店目录扫描器：把商店里能看到的应用列表抓下来，存成表格。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例：
  python -m appstorescan scan --store apple --mode charts --countries cn --feed free
  python -m appstorescan scan --store apple --mode search --keywords 微信,记账
  python -m appstorescan scan --store xiaomi --mode categories --detail
  python -m appstorescan scan --store googleplay --mode search --keywords "todo list" --proxy http://127.0.0.1:7890
  python -m appstorescan export --out apps.csv
""",
    )
    sub = p.add_subparsers(dest="command", required=True)

    # scan -----------------------------------------------------------------
    s = sub.add_parser("scan", help="执行一次扫描")
    s.add_argument("--store", required=True, choices=sorted(ADAPTERS), help="要扫描的应用商店")
    s.add_argument("--mode", default=None,
                   help="扫描方式：apple=charts/search/lookup，googleplay=charts/search/detail，xiaomi=categories/detail")
    s.add_argument("--countries", default="cn", help="国家/地区代码，逗号分隔，如 cn,hk,us（苹果/谷歌）")
    s.add_argument("--keywords", default="", help="关键词，逗号分隔（search 模式必填）")
    s.add_argument("--ids", default="", help="应用 id，逗号分隔（lookup/detail 模式用）")
    s.add_argument("--genres", default="all", help="苹果分类 id，逗号分隔；all 表示全部分类")
    s.add_argument("--feed", default="free", choices=["free", "paid", "grossing", "all"],
                   help="苹果榜单类型（charts 模式）")
    s.add_argument("--collection", default="topselling_free",
                   help="谷歌榜单名，如 topselling_free / topselling_paid / topgrossing")
    s.add_argument("--categories", default="", help="小米分类 id 或名称，逗号分隔；留空表示全部")
    s.add_argument("--limit", type=int, default=100, help="每个子任务最多取多少条（默认 100）")
    s.add_argument("--detail", action="store_true", help="顺带抓取应用详情，更慢但字段更全")
    s.add_argument("--no-resume", action="store_true", help="忽略断点记录，重扫已完成的子任务")

    # export ---------------------------------------------------------------
    e = sub.add_parser("export", help="把数据库导出成表格")
    e.add_argument("--out", default=os.path.join(PROJECT_DIR, "data", "apps.csv"))
    e.add_argument("--format", default="csv", choices=["csv", "json", "jsonl"])
    e.add_argument("--store", default=None, choices=sorted(ADAPTERS))

    # stats / stores -------------------------------------------------------
    sub.add_parser("stats", help="查看数据库里已有多少数据")
    sub.add_parser("stores", help="列出支持的商店")

    # capture / report -----------------------------------------------------
    c = sub.add_parser("capture", help="启动抓包代理（手机商店流量经过电脑）")
    c.add_argument("--port", type=int, default=8899, help="监听端口，默认 8899")
    c.add_argument("--host", default="0.0.0.0", help="监听地址，默认所有网卡")
    c.add_argument("--ca-dir", default=os.path.join(PROJECT_DIR, "data", "ca"), help="CA 证书目录")
    c.add_argument("--log-dir", default=os.path.join(PROJECT_DIR, "data", "capture"), help="抓包日志目录")
    c.add_argument("--max-body", type=int, default=512 * 1024, help="每条响应最多记录多少字节")
    c.add_argument("--timeout", type=float, default=20, help="上游超时秒数")
    c.add_argument("--cert-port", type=int, default=8898, help="证书分发网页端口，0 表示关闭")
    c.add_argument("--no-mitm", action="store_true", help="只抓 HTTP，不解密 HTTPS")
    c.add_argument("--quiet", action="store_true", help="不在屏幕上逐条打印")

    d = sub.add_parser("dns", help="DNS 劫持 + 假下载站（不需要证书）")
    d.add_argument("--ip", default="", help="把所有域名解析到的 IP，默认自动取本机局域网 IP")
    d.add_argument("--dns-port", type=int, default=53, help="DNS 端口，默认 53")
    d.add_argument("--http-port", type=int, default=80, help="HTTP 端口，默认 80")
    d.add_argument("--upstream", default="", help="未命中域名的上游 DNS，如 223.5.5.5；不填则全部劫持")
    d.add_argument("--only", default="", help="只劫持这些域名，逗号分隔，支持 *.xxx.com")
    d.add_argument("--apk", default="", help="任意 .apk 请求都返回这个文件")
    d.add_argument("--apps-dir", default="", help="APK 目录：里面的每个包都会被广播，按包名分别下发")
    d.add_argument("--root", default="", help="静态目录，按请求路径找同名文件")
    d.add_argument("--fallback", default="", help="未命中时统一返回这个文件（用来伪造目录接口）")
    d.add_argument("--fallback-type", default="application/json; charset=utf-8", help="fallback 的 Content-Type")
    d.add_argument("--log-dir", default=os.path.join(PROJECT_DIR, "data", "dns"), help="日志目录")
    d.add_argument("--quiet", action="store_true", help="不逐条打印")
    d.add_argument("--https-port", type=int, default=443, help="HTTPS 端口，0 表示不接管")
    d.add_argument("--cert-port", type=int, default=8898, help="证书下载页端口，0 关闭")
    d.add_argument("--passthrough", action="store_true", help="其它请求转发给真实服务器")
    d.add_argument("--no-rewrite", action="store_true", help="转发时不改写 MD5/大小")

    dl = sub.add_parser("dnslog", help="汇总 DNS 和 HTTP 日志：它到底访问了哪些域名/路径")
    dl.add_argument("--log-dir", default=os.path.join(PROJECT_DIR, "data", "dns"), help="日志目录")

    ct = sub.add_parser("cert", help="导出 CA 证书（root 手机可装成系统证书）")
    ct.add_argument("--ca-dir", default=os.path.join(PROJECT_DIR, "data", "ca"), help="CA 目录")

    r = sub.add_parser("report", help="汇总抓到的接口，方便判断商店用了什么协议")
    r.add_argument("--log", default=None, help="指定 jsonl 日志；不给就取最新的")
    r.add_argument("--log-dir", default=os.path.join(PROJECT_DIR, "data", "capture"), help="抓包日志目录")

    # 公共参数
    for sp in (s, e, sub.choices["stats"], sub.choices["stores"]):
        _add_common(sp)
    return p


def _add_common(sp):
    sp.add_argument("--db", default=DEFAULT_DB, help="SQLite 数据库路径")
    sp.add_argument("--delay", type=float, default=0.6, help="每次请求之间的间隔秒数（默认 0.6）")
    sp.add_argument("--retries", type=int, default=3, help="单个请求失败重试次数")
    sp.add_argument("--timeout", type=float, default=25, help="单次请求超时秒数")
    sp.add_argument("--proxy", default=None, help="代理地址，如 http://127.0.0.1:7890")
    sp.add_argument("--insecure", action="store_true", help="跳过 HTTPS 证书校验（仅调试用）")
    sp.add_argument("--quiet", action="store_true", help="只输出错误")


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.command == "stores":
        for name, cls in ADAPTERS.items():
            print(f"{name:<12} {cls.label}")
            print(f"{'':<12} 支持模式: {', '.join(cls.modes)}")
        return 0

    if args.command == "stats":
        store = Store(args.db)
        rows = store.stats()
        total = store.count()
        if not rows:
            print(f"数据库 {args.db} 里还没有数据。")
        else:
            print(f"数据库: {args.db}")
            for name, n in rows:
                print(f"  {name:<12} {n:>8} 条")
            print(f"  {'合计':<10} {total:>8} 条")
        store.close()
        return 0

    if args.command == "export":
        store = Store(args.db)
        n = store.export(args.out, fmt=args.format, store=args.store)
        store.close()
        print(f"已导出 {n} 条记录到 {args.out}")
        return 0

    if args.command == "cert":
        return run_cert(args)

    if args.command == "capture":
        return run_capture(args)

    if args.command == "dns":
        return run_dns(args)

    if args.command == "dnslog":
        return run_dnslog(args)

    if args.command == "report":
        return run_report(args)

    if args.command == "scan":
        return run_scan(args)

    return 1


def run_scan(args):
    http = HttpClient(proxy=args.proxy, timeout=args.timeout, retries=args.retries,
                      delay=args.delay, insecure=args.insecure)
    store = Store(args.db)
    if args.no_resume:
        store.conn.execute("DELETE FROM tasks")
        store.conn.commit()

    ctx = Context(http, store, quiet=args.quiet)
    adapter = get_adapter(args.store)(ctx)
    mode = args.mode or ("categories" if args.store == "xiaomi" else "charts")

    started = time.time()
    print(f"== 商店 {args.store} / 模式 {mode} ==", flush=True)
    try:
        _dispatch(adapter, mode, args, ctx)
    except KeyboardInterrupt:
        print("\n已中断，正在保存……")
    finally:
        store.commit()
        elapsed = time.time() - started
        total = store.count(args.store)
        print(f"\n本次新增 {store.inserted} 条，补全 {store.updated} 条，"
              f"{args.store} 库内共 {total} 条，用时 {elapsed:.0f}s")
        if ctx.errors:
            print(f"失败 {len(ctx.errors)} 次，前几条：")
            for msg in ctx.errors[:5]:
                print("  -", msg)
        store.close()
    return 0


def _dispatch(adapter, mode, args, ctx):
    if mode not in adapter.modes:
        raise CliError(
            f"{adapter.name} 不支持「{mode}」模式，可用模式：{', '.join(adapter.modes)}"
        )
    countries = _split(args.countries)
    keywords = _split(args.keywords)
    ids = _split(args.ids)

    if mode == "charts":
        if adapter.name == "apple":
            feed = args.feed
            genres = None if args.genres in ("", "all") else _split(args.genres)
            feeds = ["free", "paid", "grossing"] if feed == "all" else [feed]
            for f in feeds:
                adapter.charts(countries, feed=f, genres=genres, limit=args.limit)
        else:
            adapter.charts(countries, collection=args.collection, limit=args.limit)

    elif mode == "search":
        if not keywords:
            raise CliError("search 模式需要用 --keywords 指定关键词，例如 --keywords 微信,记账")
        if adapter.name == "apple":
            for cc in countries:
                adapter.search(keywords, country=cc, limit=args.limit)
        elif adapter.name == "googleplay":
            for cc in countries:
                adapter.search(keywords, country=cc, limit=args.limit, with_detail=args.detail)
        else:
            adapter.search(keywords, with_detail=args.detail)

    elif mode == "categories":
        only = _split(args.categories) or None
        adapter.categories(only=only, with_detail=args.detail)

    elif mode in ("lookup", "detail"):
        if not ids:
            raise CliError(f"{mode} 模式需要用 --ids 指定应用 id")
        if adapter.name == "googleplay":
            adapter.detail(ids, country=countries[0])
        elif adapter.name == "xiaomi":
            adapter.detail(ids)
        else:
            adapter.lookup(ids, country=countries[0])

    else:
        raise CliError(f"不支持的模式: {mode}（可选: {', '.join(adapter.modes)}）")


def _split(value):
    if not value:
        return []
    return [x.strip() for x in value.replace("，", ",").split(",") if x.strip()]



def _local_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


def run_capture(args):
    try:
        from .capture import CaptureProxy, CertificateAuthority
    except ImportError as e:
        print(f"缺少依赖：{e}", file=sys.stderr)
        print("源码版请先执行：pip install cryptography", file=sys.stderr)
        return 1

    ca = CertificateAuthority(args.ca_dir)
    if getattr(args, "cert_port", 0):
        from .capture import start_cert_server
        start_cert_server(ca, args.cert_port, host=args.host)
        print(f"[证书网页] http://<本机IP>:{args.cert_port}/  （手机浏览器打开可下载 ca.crt）")

    print("\n本机地址（手机 WiFi 代理填这里面的一个 IP）：")
    for ip in _local_ips():
        print(f"   {ip}:{args.port}")

    proxy = CaptureProxy(ca, args.log_dir, host=args.host, port=args.port,
                         max_body=args.max_body, timeout=args.timeout,
                         verbose=not args.quiet, mitm=not args.no_mitm)
    proxy.run()
    return 0


def run_report(args):
    from .capture import summarize

    log = args.log
    if not log:
        files = sorted(glob.glob(os.path.join(args.log_dir, "capture-*.jsonl")))
        if not files:
            print(f"{args.log_dir} 里还没有抓包记录")
            return 1
        log = files[-1]

    groups = summarize(log)
    if not groups:
        print(f"{log} 是空的")
        return 1

    rows = sorted(groups.items(), key=lambda kv: -kv[1]["n"])
    print(f"日志：{log}\n")
    print(f"{'次数':>4}  {'方法':<6} {'接口':<58} {'状态':<14} 最大响应")
    for (scheme, host, port, method, path), g in rows:
        url = f"{scheme}://{host}:{port}{path}"
        if len(url) > 56:
            url = url[:53] + "..."
        size = f"{max(g['sizes'])}B" if g["sizes"] else "-"
        print(f"{g['n']:>4}  {method:<6} {url:<58} {','.join(sorted(g['status'])):<14} {size}")
    print("\n如果接口里出现 apk / packageName 之类字样，就是商店的目录接口，把它发我。")
    return 0



def run_dns(args):
    from .dns import DnsServer, FakeStore, ServeConfig

    ip = args.ip or (_local_ips() or ["127.0.0.1"])[0]
    target = args.apps_dir or args.apk
    if target and not os.path.exists(target):
        print(f"APK 不存在：{target}", file=sys.stderr)
        return 1

    log_dir = args.log_dir
    os.makedirs(log_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")

    cfg = ServeConfig(
        apk=target or None,
        root=args.root or None,
        fallback=args.fallback or None,
        fallback_type=args.fallback_type,
        log_path=os.path.join(log_dir, f"http-{stamp}.jsonl"),
        verbose=not args.quiet,
    )
    cfg.passthrough = bool(args.passthrough)
    cfg.rewrite = not args.no_rewrite
    cfg.upstream_dns = args.upstream or "223.5.5.5"
    cfg.ip = ip
    cfg.progress_echo = True   # 热点/命令行模式：加密进度打进日志，StoreCast 窗口可见
    cfg.load_apk()
    # 会话桥：状态文件 + 手动值文件，供外层 StoreCast 界面显示/填写
    from .sessionio import start_watcher
    start_watcher(cfg,
                  os.path.join(PROJECT_DIR, "data", "session_state.json"),
                  os.path.join(PROJECT_DIR, "data", "manual_session.json"))
    if cfg.apps:
        print(f"[APK] 待广播 {len(cfg.apps)} 个：")
        for a in cfg.apps:
            print(f"       {a.describe()}")
        # 热点/dns 模式同样要“转发真实商店 + 注入自己的条目”，否则商店接口只会拿到 404
        cfg.catalog_dir = os.path.join(PROJECT_DIR, "data", "catalog")
        cfg.inject = cfg.entries(ip, args.http_port)
        print(f"[注入] 上架条目 {len(cfg.inject)} 条：{', '.join(e.get('packageName','?') for e in cfg.inject)}")
    threading.Thread(target=FakeStore(cfg, port=args.http_port).run, daemon=True).start()

    if args.https_port:
        try:
            from .capture import CertificateAuthority, start_cert_server
            ca = CertificateAuthority(os.path.join(PROJECT_DIR, "data", "ca"))
            threading.Thread(target=FakeStore(cfg, port=args.https_port, ca=ca).run,
                             daemon=True).start()
            if args.cert_port:
                start_cert_server(ca, args.cert_port, host="0.0.0.0")
                print(f"[证书网页] http://{ip}:{args.cert_port}/  （手机浏览器打开装 ca.crt）")
        except Exception as e:
            print(f"[HTTPS] 未启用：{e}", file=sys.stderr)

    dns = DnsServer(ip, port=args.dns_port, upstream=args.upstream or None,
                    only=_split(args.only),
                    log_path=os.path.join(log_dir, f"dns-{stamp}.jsonl"),
                    verbose=not args.quiet)

    print("\n=== 手机端设置 ===")
    print(f"  WiFi 改成静态 IP，DNS 填：{ip}")
    print(f"  网关保持原样，IP 随便给个同网段不冲突的地址")
    print(f"  然后打开那个商店，它访问的每个域名/路径都会打印在下面")
    print(f"  日志目录：{log_dir}\n")
    try:
        dns.run()
    except KeyboardInterrupt:
        print("\n已停止，跑 dnslog 看汇总。")
    return 0


def run_dnslog(args):
    dns_files = sorted(glob.glob(os.path.join(args.log_dir, "dns-*.jsonl")))
    http_files = sorted(glob.glob(os.path.join(args.log_dir, "http-*.jsonl")))

    if dns_files:
        counts = {}
        for f in dns_files:
            with open(f, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        e = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    counts[e["qname"]] = counts.get(e["qname"], 0) + 1
        print("== 它问过哪些域名 ==")
        for name, n in sorted(counts.items(), key=lambda kv: -kv[1])[:60]:
            print(f"{n:>5}  {name}")

    if http_files:
        recs = []
        for f in http_files:
            with open(f, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        recs.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        print("\n== 它请求过哪些路径 ==")
        seen = {}
        for r in recs:
            k = (r.get("host", ""), r.get("path", ""))
            seen[k] = seen.get(k, 0) + 1
        for (host, path), n in sorted(seen.items(), key=lambda kv: -kv[1])[:60]:
            print(f"{n:>5}  {host:<30} {path}")

        apks = sorted({r.get("path", "") for r in recs
                       if r.get("path", "").lower().endswith(".apk")})
        if apks:
            print("\n== 疑似 APK 下载地址 ==")
            for p in apks[:20]:
                print("  ", p)

    if not dns_files and not http_files:
        print(f"{args.log_dir} 里还没有日志")
    return 0


if __name__ == "__main__":
    sys.exit(run())


def run_cert(args):
    try:
        from .capture import CertificateAuthority
    except ImportError as e:
        print(f"缺少依赖：{e}", file=sys.stderr)
        return 1

    ca = CertificateAuthority(args.ca_dir)
    name_der = ca.cert.subject.public_bytes()
    hash_hex = hashlib.md5(name_der).digest()[:4][::-1].hex()
    out = os.path.join(args.ca_dir, hash_hex + ".0")
    with open(ca.cert_path, "rb") as f:
        pem = f.read()
    with open(out, "wb") as f:
        f.write(pem)

    print(f"证书已导出：{out}")
    print(f"（文件名 {hash_hex}.0 就是安卓要的 subject_hash_old）\n")
    print("有 root 的手机可以把它装成系统证书，安卓 7+ 也认：")
    print("  1. 把文件复制到 /system/etc/security/cacerts/  或做成 Magisk 模块")
    print("  2. 权限 chmod 644，属主 root:root")
    print("  3. 重启手机")
    return 0


if __name__ == "__main__":
    sys.exit(run())
