"""商店 APK 本地加密（DES-ECB-PKCS7），复刻 DSV 云端处理但完全离线。

原理（逆向 DSV 客户端得出）：
- 商店下载 APK 后：DES密钥 = RSA解密(encryptKey) 的前 8 字节。
- 目录应用：服务器把随机 8 字节密钥 RSA 包裹成 encryptKey。
- DSV/本地广播：复用 sdkInit 返回的 cipher（里面 RSA 包裹的是设备号 plainText），
  商店解出设备号后取前 8 字节当 DES 密钥。因此本地只需用「设备号派生的 8 字节密钥」
  做 DES-ECB-PKCS7 加密，再把真实 cipher 原样填进 encryptKey/encryptPos 即可。
- size/md5 上报明文值；密文长度 = floor(明文长/8)*8 + 8。

cryptography 50 移除了 DES，用 TripleDES(key*3) 退化为单 DES（已和 .NET DES 交叉验证一致）。
"""
from __future__ import annotations

import hashlib
import os
import threading

try:
    from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES
except ImportError:
    from cryptography.hazmat.primitives.ciphers.algorithms import TripleDES
from cryptography.hazmat.primitives.ciphers import Cipher, modes

CHUNK = 1 << 20  # 1MB，8 的倍数


def derive_key(plain: str, variant: str) -> bytes:
    """由设备号 plainText 派生 8 字节 DES 密钥。variant 见 key_variant 说明。"""
    p = (plain or "").encode("utf-8")
    if variant == "md5":
        return hashlib.md5(p).digest()[:8]
    if variant == "md5hex":
        return hashlib.md5(p).hexdigest()[:8].encode("ascii")
    if variant == "sha256":
        return hashlib.sha256(p).digest()[:8]
    if variant == "sha1":
        return hashlib.sha1(p).digest()[:8]
    if variant == "p8tail":
        return p[-8:] if len(p) >= 8 else p.ljust(8, b"\x00")
    # 默认 p8：设备号前 8 字节（= RSA 解密 cipher 后取前 8 字节）
    return p[:8].ljust(8, b"\x00")


def _cipher(key8: bytes):
    return Cipher(TripleDES(key8 * 3), modes.ECB())


def encrypt_file(src: str, dst: str, key8: bytes, progress=None) -> int:
    """流式 DES-ECB-PKCS7 加密，低内存。返回密文长度。

    progress(done_bytes, total_bytes)：每处理完一块回调一次，用于界面显示进度。
    """
    enc = _cipher(key8).encryptor()
    size = os.path.getsize(src)
    done = 0
    total = 0
    with open(src, "rb") as fi, open(dst, "wb") as fo:
        remaining = size
        while True:
            chunk = fi.read(min(CHUNK, remaining)) if remaining > 0 else b""
            remaining -= len(chunk)
            done += len(chunk)
            if remaining <= 0:
                pad = 8 - (len(chunk) % 8)
                chunk += bytes([pad]) * pad
                out = enc.update(chunk) + enc.finalize()
                fo.write(out)
                total += len(out)
                if progress:
                    progress(size, size)
                break
            out = enc.update(chunk)
            fo.write(out)
            total += len(out)
            if progress:
                progress(done, size)
    return total


def encrypted_size(orig: int) -> int:
    return (orig // 8) * 8 + 8


class EncCache:
    """按 (包名, cipher指纹, 派生方式) 缓存加密结果，避免重复加密大文件。"""

    def __init__(self, cache_dir: str):
        self.dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self._guard = threading.Lock()
        self._locks = {}

    def _path_lock(self, path: str):
        """同一个包同时被预加密和下载请求命中时，串行化，避免重复加密与文件冲突。"""
        with self._guard:
            return self._locks.setdefault(path, threading.Lock())

    def path_for(self, item, cipher: str, variant: str):
        tag = hashlib.sha1((cipher + "|" + variant).encode()).hexdigest()[:16]
        return os.path.join(self.dir, f"{item.package}.{tag}.enc"), tag

    def get(self, item, cipher: str, plain: str, variant: str, progress=None):
        if not cipher:
            return None
        path, _tag = self.path_for(item, cipher, variant)
        if os.path.exists(path) and os.path.getsize(path) == encrypted_size(item.size):
            if progress:
                progress(item.size, item.size)
            return path
        with self._path_lock(path):
            if os.path.exists(path) and os.path.getsize(path) == encrypted_size(item.size):
                return path
            key = derive_key(plain, variant)
            tmp = path + ".tmp"
            encrypt_file(item.path, tmp, key, progress=progress)
            os.replace(tmp, path)
        return path