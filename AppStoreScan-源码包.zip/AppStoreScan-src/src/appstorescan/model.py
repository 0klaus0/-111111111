"""统一的 App 记录模型。"""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field, fields


@dataclass
class AppRecord:
    store: str                 # apple / googleplay / xiaomi
    app_id: str                # 商店内的唯一标识（Apple 数字 id / 包名）
    name: str = ""
    developer: str = ""
    category: str = ""
    price: str = ""            # 已经格式化好的价格文本，如 "免费" / "¥6.00"
    currency: str = ""
    rating: float | None = None
    rating_count: int | None = None
    installs: str = ""         # 安装量（文本，Google Play 只给区间）
    version: str = ""
    updated: str = ""          # 最近更新日期（ISO）
    size: str = ""
    url: str = ""
    icon: str = ""
    description: str = ""
    country: str = ""
    source: str = ""           # 来自哪次扫描：charts:cn:6000 / search:微信 ...
    fetched_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))

    @property
    def key(self):
        return (self.store, self.app_id)

    def as_dict(self):
        return asdict(self)

    def merge_missing(self, other: "AppRecord") -> "AppRecord":
        """用 other 补全 self 中为空的字段。"""
        for f in fields(self):
            cur = getattr(self, f.name)
            new = getattr(other, f.name)
            if _is_empty(cur) and not _is_empty(new):
                setattr(self, f.name, new)
        return self


def _is_empty(v):
    return v is None or v == "" or v == [] or v == {}


COLUMNS = [f.name for f in fields(AppRecord)]
