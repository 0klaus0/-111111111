"""扫描上下文：把 HTTP 客户端、存储和日志串起来。"""

from __future__ import annotations


class Context:
    def __init__(self, http, store, quiet=False):
        self.http = http
        self.store = store
        self.quiet = quiet
        self.errors = []

    def emit(self, rec):
        if not rec or not rec.app_id:
            return
        self.store.upsert(rec)

    def log(self, msg):
        if not self.quiet:
            print(msg, flush=True)

    def error(self, msg):
        self.errors.append(msg)
        print(f"[错误] {msg}", flush=True)
