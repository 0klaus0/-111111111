"""Windows 热点相关：找热点网卡、改/还原系统 DNS。"""

from __future__ import annotations

import re
import subprocess

HOTSPOT_PREFIXES = ("192.168.137.", "192.168.173.", "192.168.0.1")


def _run(cmd, timeout=8):
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    for enc in ("utf-8", "gbk", "latin-1"):
        try:
            return p.stdout.decode(enc)
        except UnicodeDecodeError:
            continue
    return p.stdout.decode("utf-8", "replace")


def list_adapters():
    """返回 [{name, ip}]，从 ipconfig 解析。"""
    out = _run(["ipconfig"])
    adapters = []
    name = ""
    ip = ""
    for raw in out.splitlines():
        line = raw.strip()
        if line.endswith(":") and ("适配器" in line or "adapter" in line.lower()):
            if name and ip:
                adapters.append({"name": name, "ip": ip})
            # "以太网适配器 以太网:" / "Wireless LAN adapter Wi-Fi:" → 只留真实连接名
            cleaned = re.sub(r"^.*?(?:adapter|适配器)\s+", "", line.rstrip(":"), flags=re.I).strip()
            name = cleaned or line.rstrip(":")
            ip = ""
            continue
        m = re.search(r"IPv4.*?:\s*(\d{1,3}(?:\.\d{1,3}){3})", line)
        if m and not ip:
            ip = m.group(1)
    if name and ip:
        adapters.append({"name": name, "ip": ip})
    return adapters


def hotspot_info():
    """找 Windows 移动热点用的那块网卡（通常是 192.168.137.1）。"""
    ads = list_adapters()
    for a in ads:
        for pre in HOTSPOT_PREFIXES:
            if a["ip"].startswith(pre):
                return a
    for a in ads:
        if "本地连接" in a["name"] or "Local Area Connection" in a["name"]:
            return a
    return None


def gateway():
    """默认网关（用来判断哪块网卡在联网）。"""
    out = _run(["ipconfig"])
    for line in out.splitlines():
        if "默认网关" in line or "Default Gateway" in line.lower():
            m = re.search(r"(\d{1,3}(?:\.\d{1,3}){3})", line)
            if m:
                return m.group(1)
    return ""


def get_dns(adapter_name):
    out = _run(["netsh", "interface", "ip", "show", "dns", f"name={adapter_name}"])
    ips = re.findall(r"(\d{1,3}(?:\.\d{1,3}){3})", out)
    return ips


def set_dns(adapter_name, server):
    _run(["netsh", "interface", "ip", "set", "dns", f"name={adapter_name}", "static", server, "primary"])
    _run(["ipconfig", "/flushdns"])
    return get_dns(adapter_name)


def reset_dns(adapter_name):
    _run(["netsh", "interface", "ip", "set", "dns", f"name={adapter_name}", "dhcp"])
    _run(["ipconfig", "/flushdns"])
    return get_dns(adapter_name)


def hotspot_state():
    """Windows 移动热点是否开启（尽力而为）。"""
    out = _run(["netsh", "wlan", "show", "hostednetwork"])
    if "已启动" in out or "started" in out.lower():
        return True
    return hotspot_info() is not None
