"""手机中介模式：通过 adb 把手机热点里的 DNS 查询转到电脑。

原理：老手机连新手机的热点，DNS 由新手机下发（指向它自己）。
在新手机上用 iptables 把 53 端口的流量 DNAT 到电脑，查询就落到本程序。
需要：新手机开 USB 调试 + 能被 adb 识别 + 有 root（su）。
"""

from __future__ import annotations

import os
import shutil
import subprocess

CANDIDATES = [
    "adb",
    os.path.join("platform-tools", "adb.exe"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Android", "Sdk", "platform-tools", "adb.exe"),
    r"C:\platform-tools\adb.exe",
]


def find_adb():
    for c in CANDIDATES:
        if not c:
            continue
        p = shutil.which(c) if os.sep not in c else (c if os.path.exists(c) else None)
        if p:
            return p
    return None


def _run(adb, args, timeout=15):
    try:
        p = subprocess.run([adb] + args, capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)
    out = p.stdout.decode("utf-8", "replace") + p.stderr.decode("utf-8", "replace")
    return p.returncode, out.strip()


def devices(adb):
    rc, out = _run(adb, ["devices"])
    if rc != 0:
        return []
    lines = [l.strip() for l in out.splitlines()[1:] if l.strip()]
    return [l.split("\t")[0] for l in lines if "\tdevice" in l]


def has_root(adb, serial):
    rc, out = _run(adb, ["-s", serial, "shell", "su -c id"])
    return rc == 0 and "uid=0" in out


def phone_ip(adb, serial):
    """手机自己在各网段上的地址（取 Wi-Fi / 热点那段）。"""
    rc, out = _run(adb, ["-s", serial, "shell", "ip -4 addr"])
    ips = []
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("inet "):
            ip = line.split()[1].split("/")[0]
            if not ip.startswith("127."):
                ips.append(ip)
    return ips


def install_redirect(adb, serial, pc_ip, port=53):
    """把手机上的 DNS（UDP/TCP 53）转到电脑。"""
    cmds = [
        f"iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to-destination {pc_ip}:{port}",
        f"iptables -t nat -A PREROUTING -p tcp --dport 53 -j DNAT --to-destination {pc_ip}:{port}",
    ]
    results = []
    for c in cmds:
        rc, out = _run(adb, ["-s", serial, "shell", f"su -c \"{c}\""])
        results.append((c, rc, out))
    return results


def remove_redirect(adb, serial, pc_ip, port=53):
    cmds = [
        f"iptables -t nat -D PREROUTING -p udp --dport 53 -j DNAT --to-destination {pc_ip}:{port}",
        f"iptables -t nat -D PREROUTING -p tcp --dport 53 -j DNAT --to-destination {pc_ip}:{port}",
    ]
    results = []
    for c in cmds:
        rc, out = _run(adb, ["-s", serial, "shell", f"su -c \"{c}\""])
        results.append((c, rc, out))
    return results


def manual_commands(pc_ip, port=53):
    return [
        f"adb shell su -c \"iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to-destination {pc_ip}:{port}\"",
        f"adb shell su -c \"iptables -t nat -A PREROUTING -p tcp --dport 53 -j DNAT --to-destination {pc_ip}:{port}\"",
        "# 撤销：把 -A 换成 -D 再执行一次",
    ]
