"""SQLite 存储 + CSV/JSONL 导出。"""

from __future__ import annotations

import csv
import json
import os
import sqlite3
import time

from .model import COLUMNS, AppRecord

SCHEMA = """
CREATE TABLE IF NOT EXISTS apps (
    store        TEXT NOT NULL,
    app_id       TEXT NOT NULL,
    name         TEXT,
    developer    TEXT,
    category     TEXT,
    price        TEXT,
    currency     TEXT,
    rating       REAL,
    rating_count INTEGER,
    installs     TEXT,
    version      TEXT,
    updated      TEXT,
    size         TEXT,
    url          TEXT,
    icon         TEXT,
    description  TEXT,
    country      TEXT,
    source       TEXT,
    fetched_at   TEXT,
    first_seen   TEXT,
    last_seen    TEXT,
    PRIMARY KEY (store, app_id)
);
CREATE INDEX IF NOT EXISTS idx_apps_store ON apps(store);

CREATE TABLE IF NOT EXISTS runs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    started    TEXT,
    finished   TEXT,
    store      TEXT,
    mode       TEXT,
    args       TEXT,
    found      INTEGER DEFAULT 0,
    inserted   INTEGER DEFAULT 0,
    updated    INTEGER DEFAULT 0,
    errors     TEXT
);

CREATE TABLE IF NOT EXISTS tasks (
    task_key   TEXT PRIMARY KEY,   -- store|mode|参数指纹
    done_at    TEXT,
    found      INTEGER DEFAULT 0
);
"""


class Store:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self.inserted = 0
        self.updated = 0

    def close(self):
        self.conn.commit()
        self.conn.close()

    # -- 写入 -------------------------------------------------------------
    def upsert(self, rec: AppRecord) -> bool:
        """返回 True 表示新增，False 表示补全/更新了已有记录。"""
        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        row = self.conn.execute(
            "SELECT * FROM apps WHERE store=? AND app_id=?", (rec.store, rec.app_id)
        ).fetchone()

        data = rec.as_dict()
        if row is None:
            cols = COLUMNS + ["first_seen", "last_seen"]
            vals = [data[c] for c in COLUMNS] + [now, now]
            self.conn.execute(
                f"INSERT INTO apps ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
                vals,
            )
            self.inserted += 1
            return True

        # 已有记录：默认只补空字段（避免榜单的少量字段覆盖详情数据）；
        # 来自详情页的数据（rec.overwrite = True）则用非空新值覆盖旧值。
        overwrite = getattr(rec, "overwrite", False)
        updates = {}
        for c in COLUMNS:
            if c in ("store", "app_id"):
                continue
            old = row[c]
            new = data[c]
            if new in (None, ""):
                continue
            if overwrite or old is None or old == "":
                updates[c] = new
        updates["last_seen"] = now
        sets = ",".join(f"{k}=?" for k in updates)
        self.conn.execute(
            f"UPDATE apps SET {sets} WHERE store=? AND app_id=?",
            list(updates.values()) + [rec.store, rec.app_id],
        )
        self.updated += 1
        return False

    def commit(self):
        self.conn.commit()

    # -- 任务去重（断点续扫） ---------------------------------------------
    def task_done(self, key) -> bool:
        return self.conn.execute("SELECT 1 FROM tasks WHERE task_key=?", (key,)).fetchone() is not None

    def mark_task(self, key, found=0):
        self.conn.execute(
            "INSERT OR REPLACE INTO tasks (task_key, done_at, found) VALUES (?,?,?)",
            (key, time.strftime("%Y-%m-%dT%H:%M:%S"), found),
        )
        self.conn.commit()

    # -- 统计与导出 -------------------------------------------------------
    def count(self, store=None) -> int:
        if store:
            return self.conn.execute("SELECT COUNT(*) FROM apps WHERE store=?", (store,)).fetchone()[0]
        return self.conn.execute("SELECT COUNT(*) FROM apps").fetchone()[0]

    def stats(self):
        rows = self.conn.execute(
            "SELECT store, COUNT(*) n FROM apps GROUP BY store ORDER BY n DESC"
        ).fetchall()
        return [(r["store"], r["n"]) for r in rows]

    def iter_apps(self, store=None):
        sql = "SELECT * FROM apps"
        args = ()
        if store:
            sql += " WHERE store=?"
            args = (store,)
        sql += " ORDER BY store, name"
        for row in self.conn.execute(sql, args):
            yield dict(row)

    def export(self, out_path, fmt="csv", store=None):
        rows = list(self.iter_apps(store))
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        if fmt == "csv":
            with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else COLUMNS)
                writer.writeheader()
                writer.writerows(rows)
        elif fmt == "jsonl":
            with open(out_path, "w", encoding="utf-8") as f:
                for r in rows:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
        elif fmt == "json":
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(rows, f, ensure_ascii=False, indent=2)
        else:
            raise ValueError(f"不支持的格式: {fmt}")
        return len(rows)
