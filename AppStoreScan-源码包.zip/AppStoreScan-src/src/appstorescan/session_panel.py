# -*- coding: utf-8 -*-
"""会话状态面板：换车 / 换电脑时，一眼看出「卡在 100%」是哪一环。

放进 build/src/appstorescan/session_panel.py

它读的是运行时事实，不做任何猜测：
  1. 当前会话设备号      cfg.last_plain     （车机 sdkInit 带过来的）
  2. 是否捕获到 sdkInit  cfg.last_cipher     （空 = 没有，加密会退化成发明文）
  3. 磁盘密文是按哪次会话生成的  文件名里的 cipher 指纹
  4. 本机自签 CA 指纹    data/ca/ca.crt     （要和车机里装的那张一致）
"""

from __future__ import annotations

import hashlib
import os
import sys
import time
import tkinter as tk
from tkinter import messagebox

BG = "#f5f6f8"
CARD = "#ffffff"
MUTED = "#6b7280"

FONT = ("Microsoft YaHei UI", 9)
MONO = ("Consolas", 9)


def _project_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cipher_tag(cipher: str, variant: str) -> str:
    """必须和 storecrypto.EncCache 里的算法完全一致。"""
    return hashlib.sha1((cipher + "|" + variant).encode()).hexdigest()[:16]


def _variant_of(mode: str) -> str:
    return mode[4:] if mode.startswith("des-") else "p8"


def _human(n: int) -> str:
    if n <= 0:
        return "0 B"
    f = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if f < 1024 or unit == "GB":
            return ("%d %s" % (int(f), unit)) if unit == "B" else ("%.1f %s" % (f, unit))
        f /= 1024.0
    return str(n)


class SessionPanel:
    def __init__(self, app, master=None):
        self.app = app
        self._plain_since = None
        self._plain_seen = None

        self.win = tk.Toplevel(master or app.root)
        self.win.title("会话状态 — 换车自检")
        self.win.geometry("780x660")
        self.win.configure(bg=BG)
        self.win.protocol("WM_DELETE_WINDOW", self.hide)

        head = tk.Frame(self.win, bg=BG)
        head.pack(fill="x", padx=10, pady=(8, 4))
        tk.Label(head, text="会话状态自检", bg=BG, fg="#111827",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left")

        bar = tk.Frame(self.win, bg=BG)
        bar.pack(fill="x", padx=10, pady=(0, 6))
        tk.Button(bar, text="刷新", command=self.tick, font=FONT,
                  bg="#e5e7eb", relief="flat", padx=10).pack(side="left")
        tk.Button(bar, text="复制全部", command=self._copy, font=FONT,
                  bg="#e5e7eb", relief="flat", padx=10).pack(side="left", padx=6)
        tk.Button(bar, text="打开日志目录", command=self._open_logs, font=FONT,
                  bg="#e5e7eb", relief="flat", padx=10).pack(side="left")
        tk.Button(bar, text="清空密文缓存", command=self._clear_cache, font=FONT,
                  bg="#fee2e2", relief="flat", padx=10).pack(side="right")

        # ---- 手动填写（没捕获到 sdkInit 时的兜底）----
        man = tk.Frame(self.win, bg=CARD, highlightbackground="#e3e6ea", highlightthickness=1)
        man.pack(fill="x", padx=10, pady=(0, 6))
        self.man_plain = tk.StringVar()
        self.man_cipher = tk.StringVar()
        mr1 = tk.Frame(man, bg=CARD); mr1.pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(mr1, text="设备号", bg=CARD, font=FONT, width=7, anchor="w").pack(side="left")
        tk.Entry(mr1, textvariable=self.man_plain, font=MONO, relief="solid", bd=1).pack(
            side="left", fill="x", expand=True, ipady=2)
        mr2 = tk.Frame(man, bg=CARD); mr2.pack(fill="x", padx=10, pady=2)
        tk.Label(mr2, text="cipher", bg=CARD, font=FONT, width=7, anchor="w").pack(side="left")
        tk.Entry(mr2, textvariable=self.man_cipher, font=MONO, relief="solid", bd=1).pack(
            side="left", fill="x", expand=True, ipady=2)
        mr3 = tk.Frame(man, bg=CARD); mr3.pack(fill="x", padx=10, pady=(2, 8))
        tk.Button(mr3, text="应用手动值", command=self._apply_manual, font=FONT,
                  bg="#dbeafe", relief="flat", padx=10).pack(side="left")
        tk.Button(mr3, text="清除手动值", command=self._clear_manual, font=FONT,
                  bg="#e5e7eb", relief="flat", padx=10).pack(side="left", padx=6)
        tk.Button(mr3, text="从历史日志导入（含成功那次）", command=self._import_logs, font=FONT,
                  bg="#ecfdf5", relief="flat", padx=10).pack(side="left")
        tk.Label(mr3, text="留空 = 自动捕获；两项都填才生效", bg=CARD, fg=MUTED,
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=8)

        self.txt = tk.Text(self.win, bg=CARD, fg="#111827", font=MONO,
                           relief="flat", wrap="word", padx=12, pady=10,
                           highlightbackground="#e3e6ea", highlightthickness=1)
        self.txt.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.txt.configure(state="disabled")

        self.tick()
        self._tick_loop()

    # ------------------------------------------------------------- 数据采集
    def _cache_dir(self) -> str:
        return os.path.join(_project_dir(), "data", "enc_cache")

    def _collect(self):
        cfg = getattr(self.app, "cfg", None)
        running = bool(getattr(self.app, "running", False))
        mode = "des-p8"
        variant = "p8"
        plain = ""
        cipher = ""
        if cfg is not None:
            try:
                mode = cfg.store_mode() or "des-p8"
            except Exception:
                mode = "des-p8"
            variant = _variant_of(mode)
            plain = getattr(cfg, "eff_plain", "") or getattr(cfg, "last_plain", "") or ""
            cipher = getattr(cfg, "eff_cipher", "") or getattr(cfg, "last_cipher", "") or ""
        man_plain = getattr(self.app, "manual_plain", "") or ""
        man_cipher = getattr(self.app, "manual_cipher", "") or ""
        plain_src = "手动" if man_plain else "自动捕获"
        cipher_src = "手动" if man_cipher else "自动捕获"

        # 设备号变化时间（只能从本次进程开始观察）
        if plain and plain != self._plain_seen:
            self._plain_seen = plain
            self._plain_since = time.strftime("%H:%M:%S")

        tag = _cipher_tag(cipher, variant) if cipher else ""

        # CA 指纹
        ca_path = os.path.join(_project_dir(), "data", "ca", "ca.crt")
        ca_fp = ""
        if os.path.exists(ca_path):
            try:
                with open(ca_path, "rb") as f:
                    ca_fp = hashlib.sha1(f.read()).hexdigest()
            except OSError:
                ca_fp = ""

        # 每个包的密文状态
        apps = list(getattr(cfg, "apps", []) or []) if cfg is not None else []
        cache = self._cache_dir()
        enc_rows = []
        for item in apps:
            expected = os.path.join(cache, "%s.%s.enc" % (item.package, tag)) if tag else ""
            files = []
            try:
                files = [f for f in os.listdir(cache)
                         if f.startswith(item.package + ".") and f.endswith(".enc")]
            except OSError:
                pass
            if expected and os.path.exists(expected):
                size = os.path.getsize(expected)
                mtime = time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(expected)))
                enc_rows.append((item, "OK", size, mtime, ""))
            elif files:
                newest = max(files, key=lambda f: os.path.getmtime(os.path.join(cache, f)))
                p = os.path.join(cache, newest)
                size = os.path.getsize(p)
                mtime = time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(p)))
                other_tag = newest[len(item.package) + 1:-4]
                enc_rows.append((item, "STALE", size, mtime, other_tag))
            else:
                enc_rows.append((item, "NONE", 0, "", ""))

        return dict(running=running, cfg=cfg, mode=mode, variant=variant,
                    plain=plain, cipher=cipher, tag=tag, ca_fp=ca_fp,
                    apps=apps, enc_rows=enc_rows, cache=cache,
                    plain_src=plain_src, cipher_src=cipher_src)

    def _render(self, d):
        L = []
        L.append("【会话】")
        L.append("  运行状态      : %s" % ("运行中" if d["running"] else "未启动（先点「启动」）"))
        if d["plain"]:
            L.append("  当前设备号    : %s   (%s%s)" % (
                d["plain"], d["plain_src"],
                "，捕获于 " + self._plain_since if d["plain_src"] == "自动捕获" and self._plain_since else ""))
            L.append("  DES key       : %s  ← 设备号前 8 字节" % (d["plain"][:8] or ""))
        else:
            L.append("  当前设备号    : 未捕获")
            L.append("                   ↑ 车机刷一次商店首页；或在上方手动填写/从历史日志导入")
        if d["cipher"]:
            L.append("  sdkInit cipher: 已有（%s，%d 字符，指纹 %s）" % (
                d["cipher_src"], len(d["cipher"]), d["tag"]))
        else:
            L.append("  sdkInit cipher: 未捕获")
            L.append("                   ↑ 没有它程序会拒绝下发；可手动填写或从历史日志导入")
        L.append("  加密模式      : %s（派生=%s）" % (d["mode"], d["variant"]))
        L.append("  本机 CA 指纹  : %s" % (d["ca_fp"] or "未生成（HTTPS 还没开过）"))
        L.append("                   ↑ 必须在车机「加密与凭据」里装的是这一张")
        L.append("")

        L.append("【待广播 APK】")
        if not d["apps"]:
            L.append("  （空）APK 目录里没有可解析的包")
        for item, state, size, mtime, other in d["enc_rows"]:
            L.append("  %s  %s  %s" % (item.package, item.version_name or "",
                                        _human(item.size)))
            if state == "OK":
                L.append("    密文 : 就绪 ✓  按当前会话生成  %s  %s" % (_human(size), mtime))
            elif state == "STALE":
                L.append("    密文 : 过期 ✗  仍是旧会话生成的（指纹 %s，%s）" % (other, mtime))
                L.append("           新车用自己的设备号解不开 → 会卡在 100%")
            else:
                L.append("    密文 : 尚未生成（第一次点下载时现场加密，约 1~2 分钟）")
        L.append("")

        L.append("【结论】")
        if not d["running"]:
            L.append("  程序没在广播：车机请求到不了这里，任何下载都会卡住或走真网。")
        elif not d["plain"] or not d["cipher"]:
            L.append("  还没拿到这台车的 sdkInit：先在车机打开商店首页刷新；")
            L.append("  捕获不到就在上方手动填写，或点「从历史日志导入」用成功那次的值。")
        elif any(r[1] == "STALE" for r in d["enc_rows"]):
            L.append("  密文是旧车生成的：点右上「清空密文缓存」后重新下载。")
        elif any(r[1] == "NONE" for r in d["enc_rows"]) and d["apps"]:
            L.append("  可以下载：密文会在第一次请求时按当前设备号生成，耐心等加密完成。")
        elif any(r[1] == "OK" for r in d["enc_rows"]):
            L.append("  可以下载：设备号已捕获，密文与当前会话一致。")
        else:
            L.append("  没有待广播的包。")

        return "\n".join(L)

    # ------------------------------------------------------------- 手动值
    def _apply_manual(self):
        p = self.man_plain.get().strip()
        c = self.man_cipher.get().strip()
        if not p or not c:
            messagebox.showwarning(
                "手动填写", "设备号和 cipher 两项都要填才生效。\n\n"
                "cipher 是 sdkInit 响应里 data.cipher 那串 base64，\n"
                "可点「从历史日志导入」自动找成功那次的值。", parent=self.win)
            return
        self.app.manual_plain = p
        self.app.manual_cipher = c
        cfg = getattr(self.app, "cfg", None)
        if cfg is not None:
            cfg.manual_plain = p
            cfg.manual_cipher = c
            try:
                cfg.prewarm()      # 值一填好就在后台把密文备好
            except Exception:
                pass
        self.tick()
        messagebox.showinfo(
            "手动填写", "已应用。后续加密按这个设备号派生密钥。\n"
            "注意：cipher 必须就是这台车 sdkInit 返回的那串，\n"
            "填了别的车的值，车机解出来对不上仍会安装失败。", parent=self.win)

    def _clear_manual(self):
        self.app.manual_plain = ""
        self.app.manual_cipher = ""
        cfg = getattr(self.app, "cfg", None)
        if cfg is not None:
            cfg.manual_plain = ""
            cfg.manual_cipher = ""
        self.man_plain.set("")
        self.man_cipher.set("")
        self.tick()

    def _data_roots(self):
        """本目录 + 历史版本目录（成功那次的日志在旧版本目录里）。"""
        roots = [os.path.join(_project_dir(), "data")]
        base = os.path.join(os.environ.get("LOCALAPPDATA", ""), "AppStoreScan")
        if os.path.isdir(base):
            for name in os.listdir(base):
                d = os.path.join(base, name, "data")
                if name.startswith("app-") and os.path.isdir(d) and d not in roots:
                    roots.append(d)
        return roots

    def _import_logs(self):
        """从 catalog 里的 sdkInit 响应找 cipher，从 http 日志找 plainText。"""
        import json
        import glob
        cands = []   # (mtime, cipher, path)
        plains = []  # (ts, plain)
        for root in self._data_roots():
            for f in glob.glob(os.path.join(root, "catalog", "*.json")):
                if "sdkinit" not in os.path.basename(f).lower():
                    continue
                try:
                    with open(f, encoding="utf-8") as fh:
                        obj = json.load(fh)
                    c = (obj.get("data") or {}).get("cipher")
                    if c:
                        cands.append((os.path.getmtime(f), c, f))
                except Exception:
                    pass
            for f in glob.glob(os.path.join(root, "dns", "http-*.jsonl")):
                try:
                    with open(f, encoding="utf-8") as fh:
                        for line in fh:
                            if "sdkInit" not in line:
                                continue
                            try:
                                ev = json.loads(line)
                            except Exception:
                                continue
                            if not ev.get("path", "").split("?")[0].endswith("sdkInit"):
                                continue
                            body = ev.get("body") or ""
                            try:
                                pb = json.loads(body)
                                if pb.get("plainText"):
                                    plains.append((ev.get("ts", 0), pb["plainText"]))
                            except Exception:
                                pass
                except OSError:
                    pass
        if not cands:
            messagebox.showinfo(
                "从历史日志导入",
                "没找到含 cipher 的 sdkInit 响应。\n"
                "说明这台电脑上还没有成功捕获过会话；\n"
                "先让车机连热点刷一次商店，或从成功那台电脑拷 data 目录过来。",
                parent=self.win)
            return
        cands.sort(key=lambda x: x[0])
        mt, cipher, cpath = cands[-1]
        plain = ""
        if plains:
            plains.sort(key=lambda x: abs(x[0] - mt))
            plain = plains[0][1]
        self.man_plain.set(plain)
        self.man_cipher.set(cipher)
        when = time.strftime("%m-%d %H:%M:%S", time.localtime(mt))
        messagebox.showinfo(
            "从历史日志导入",
            f"找到 {len(cands)} 条会话，已填入最近一条（{when}）：\n"
            f"设备号：{plain or '（日志里没找到，请手填）'}\n"
            f"cipher：{len(cipher)} 字符\n"
            f"来源：{cpath}\n\n"
            "确认是目标车机的值后，点「应用手动值」。", parent=self.win)

    # ------------------------------------------------------------- 交互
    def tick(self):
        try:
            text = self._render(self._collect())
        except Exception as e:
            text = "读取状态失败：%r" % (e,)
        self.txt.configure(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("1.0", text)
        self.txt.configure(state="disabled")

    def _tick_loop(self):
        try:
            if self.win.winfo_exists():
                self.tick()
                self.win.after(800, self._tick_loop)
        except tk.TclError:
            pass

    def _copy(self):
        self.win.clipboard_clear()
        self.win.clipboard_append(self.txt.get("1.0", "end").strip())

    def _open_logs(self):
        path = os.path.join(_project_dir(), "data", "dns")
        if not os.path.isdir(path):
            messagebox.showinfo("日志目录", "还没有日志：%s" % path, parent=self.win)
            return
        try:
            os.startfile(path)
        except Exception:
            messagebox.showinfo("日志目录", path, parent=self.win)

    def _clear_cache(self):
        cache = self._cache_dir()
        if not os.path.isdir(cache):
            messagebox.showinfo("密文缓存", "目录不存在，无需清理。", parent=self.win)
            return
        if not messagebox.askyesno(
                "清空密文缓存",
                "会删掉 %s 下所有 .enc，下次下载按当前车机设备号重新加密。\n确定？" % cache,
                parent=self.win):
            return
        removed = 0
        for f in os.listdir(cache):
            if f.endswith(".enc") or f.endswith(".tmp"):
                try:
                    os.remove(os.path.join(cache, f))
                    removed += 1
                except OSError:
                    pass
        messagebox.showinfo("密文缓存", "已删除 %d 个文件。" % removed, parent=self.win)
        self.tick()

    def show(self):
        self.win.deiconify()
        self.win.lift()
        self.tick()

    def hide(self):
        self.win.withdraw()
