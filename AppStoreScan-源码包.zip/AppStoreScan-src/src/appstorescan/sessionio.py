"""无界面模式的会话桥：把设备号/cipher/加密进度写成 JSON 状态文件，
并监听手动值文件，让外层界面（StoreCast）能显示和手动填写。

状态文件  data/session_state.json   内层每 0.8s 写一次（含心跳 ts）
手动值文件 data/manual_session.json  外层写入，内层消费后删除：
    {"plain": "...", "cipher": "..."}   应用手动值
    {"clear": true}                     清除手动值
    {"import_history": true}            从历史日志导入并直接应用
"""
from __future__ import annotations

import glob
import json
import os
import sys
import threading
import time


def _project_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def data_roots():
    """本目录 + 历史版本目录（成功那次的日志在旧版本目录里）。"""
    roots = [os.path.join(_project_dir(), "data")]
    base = os.path.join(os.environ.get("LOCALAPPDATA", ""), "AppStoreScan")
    if os.path.isdir(base):
        for name in os.listdir(base):
            d = os.path.join(base, name, "data")
            if name.startswith("app-") and os.path.isdir(d) and d not in roots:
                roots.append(d)
    return roots


def import_history():
    """从 catalog 的 sdkInit 响应找 cipher，从 http 日志找 plainText。
    返回 (plain, cipher, note)；找不到时 plain/cipher 为空。"""
    cands = []   # (mtime, cipher, path)
    plains = []  # (ts, plain)
    for root in data_roots():
        for f in glob.glob(os.path.join(root, "catalog", "*.json")):
            if "sdkinit" not in os.path.basename(f).lower():
                continue
            try:
                with open(f, encoding="utf-8") as fh:
                    obj = json.load(fh)
                c = (obj.get("data") or {}).get("cipher")
                if c:
                    cands.append((os.path.getmtime(f), c, f))
            except Exception:
                pass
        for f in glob.glob(os.path.join(root, "dns", "http-*.jsonl")):
            try:
                with open(f, encoding="utf-8") as fh:
                    for line in fh:
                        if "sdkInit" not in line:
                            continue
                        try:
                            ev = json.loads(line)
                        except Exception:
                            continue
                        if not ev.get("path", "").split("?")[0].endswith("sdkInit"):
                            continue
                        try:
                            pb = json.loads(ev.get("body") or "")
                            if pb.get("plainText"):
                                plains.append((ev.get("ts", 0), pb["plainText"]))
                        except Exception:
                            pass
            except OSError:
                pass
    if not cands:
        return "", "", "没找到含 cipher 的 sdkInit 响应：先让车机连热点刷一次商店"
    cands.sort(key=lambda x: x[0])
    mt, cipher, cpath = cands[-1]
    plain = ""
    if plains:
        plains.sort(key=lambda x: abs(x[0] - mt))
        plain = plains[0][1]
    when = time.strftime("%m-%d %H:%M:%S", time.localtime(mt))
    note = (f"找到 {len(cands)} 条会话，已应用最近一条（{when}）；"
            f"设备号：{plain or '（日志里没找到，请手填）'}；cipher {len(cipher)} 字符")
    return plain, cipher, note


def build_state(cfg, note=""):
    enc = dict(getattr(cfg, "enc_state", {}) or {})
    return {
        "plain": cfg.last_plain,
        "cipher": cfg.last_cipher,
        "manual_plain": cfg.manual_plain,
        "manual_cipher": cfg.manual_cipher,
        "eff_plain": cfg.eff_plain,
        "eff_cipher": cfg.eff_cipher,
        "enc": enc,
        "apps": [{"package": a.package, "size": a.size} for a in cfg.apps],
        "note": note,
        "ts": time.time(),
    }


def _write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)


def start_watcher(cfg, state_path, manual_path):
    """后台线程：写状态心跳 + 消费手动值文件。命令行/热点模式专用。"""
    os.makedirs(os.path.dirname(state_path), exist_ok=True)
    note = ""

    def loop():
        nonlocal note
        while True:
            try:
                if os.path.exists(manual_path):
                    try:
                        with open(manual_path, encoding="utf-8-sig") as f:
                            req = json.load(f)
                    except Exception as e:
                        req = {}
                        note = f"手动值文件解析失败：{e}"
                    try:
                        os.remove(manual_path)
                    except OSError:
                        pass
                    if req.get("clear"):
                        cfg.manual_plain = ""
                        cfg.manual_cipher = ""
                        note = "已清除手动值，恢复自动捕获"
                        print("[会话] 已清除手动值", flush=True)
                    elif req.get("import_history"):
                        p, c, note = import_history()
                        if c:
                            if p:
                                cfg.manual_plain = p
                            cfg.manual_cipher = c
                            print(f"[会话] 历史导入：{note}", flush=True)
                            try:
                                cfg.prewarm()
                            except Exception:
                                pass
                        else:
                            print(f"[会话] 历史导入失败：{note}", flush=True)
                    elif req.get("plain") or req.get("cipher"):
                        p = (req.get("plain") or "").strip()
                        c = (req.get("cipher") or "").strip()
                        if p:
                            cfg.manual_plain = p
                        if c:
                            cfg.manual_cipher = c
                        note = f"已应用手动值：设备号 {cfg.manual_plain or '（空）'}，cipher {len(cfg.manual_cipher)} 字符"
                        print(f"[会话] {note}", flush=True)
                        try:
                            cfg.prewarm()
                        except Exception:
                            pass
                _write(state_path, build_state(cfg, note))
            except Exception:
                pass
            time.sleep(0.8)

    t = threading.Thread(target=loop, daemon=True)
    t.start()
    return t
