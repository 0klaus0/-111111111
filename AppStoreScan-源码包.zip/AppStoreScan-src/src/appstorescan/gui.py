"""桌面图形界面：配置、启动、实时看手机请求了什么。"""

from __future__ import annotations

import atexit
import ctypes
import hashlib
import json
import os
import queue
import socket
import subprocess
import sys
import threading
import traceback
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .dns import DnsServer, FakeStore, ServeConfig

PROJECT_DIR = (
    os.path.dirname(sys.executable)
    if getattr(sys, "frozen", False)
    else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)
CONFIG_PATH = os.path.join(PROJECT_DIR, "data", "gui-config.json")
MAX_ROWS = 800

# 热点模式下只接管这些域名，其它放行，保证电脑和老手机都能正常上网
DEFAULT_HOTSPOT_ONLY = ",".join([
    "*.mi.com", "*.miui.com", "*.xiaomi.com",
    "*.hicloud.com", "*.dbankcloud.com", "*.appgallery.huawei.com",
    "*.oppomobile.com", "*.heytap.com", "*.vivo.com.cn",
    "*.myapp.com", "*.sj.qq.com", "*.gtimg.cn",
    "*.360.cn", "*.wandoujia.com", "*.apkpure.com", "*.coolapk.com",
])

BG = "#f5f6f8"
CARD = "#ffffff"
ACCENT = "#2563eb"
OK = "#16a34a"
BAD = "#dc2626"
MUTED = "#6b7280"


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"


def hide_console():
    if sys.platform != "win32":
        return
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
    except Exception:
        pass


class App:
    def __init__(self, root):
        self.root = root
        self.queue = queue.Queue()
        self.dns = None
        self.http = None
        self.running = False
        self.counts = {"dns": 0, "http": 0, "apk": 0, "tls_fail": 0}
        self._tls_warned = False
        self._stores_seen = set()
        self.summary = {}
        self._rows_pending = 0

        root.title(f"应用商店救砖助手 v{__version__} — AppStoreScan")
        root.geometry("1060x720")
        root.minsize(900, 620)
        root.configure(bg=BG)

        self._build_ui()
        self._load_config()
        self.root.after(150, self._pump)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.report_callback_exception = self._on_tk_error
        atexit.register(self._emergency_restore)
        self.root.after(500, self._check_stale_backup)

        # 会话自检面板：换车/换电脑时定位「卡在 100%」用（默认隐藏，点「会话状态」打开）
        try:
            from .session_panel import SessionPanel
            self.panel = SessionPanel(self, self.root)
            self.panel.hide()
        except Exception as _e:
            self.panel = None
            print(f"[面板] 初始化失败：{_e}", flush=True)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("TLabel", background=BG, font=("Microsoft YaHei UI", 9))
        style.configure("Card.TFrame", background=CARD)
        style.configure("TButton", font=("Microsoft YaHei UI", 9))
        style.configure("Big.TButton", font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("Treeview", font=("Microsoft YaHei UI", 9), rowheight=24)
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 9, "bold"))

        outer = tk.Frame(self.root, bg=BG)
        outer.pack(fill="both", expand=True, padx=12, pady=10)

        # ---- 操作流程图（随状态点亮）----
        self.flow = tk.Canvas(outer, bg=CARD, height=92, highlightthickness=1,
                              highlightbackground="#e3e6ea")
        self.flow.pack(fill="x", pady=(0, 8))
        self.flow.bind("<Configure>", lambda e: self._draw_flow())
        self._flow_state = None

        # ---- 配置卡片 ----
        card = tk.Frame(outer, bg=CARD, highlightbackground="#e3e6ea", highlightthickness=1)
        self.card_frame = card
        card.pack(fill="x")

        # ---- 加密进度条（默认隐藏，加密时出现）----
        self.enc_frame = tk.Frame(outer, bg=CARD, highlightbackground="#e3e6ea",
                                  highlightthickness=1)
        self.enc_head = tk.Label(self.enc_frame, text="", bg=CARD, fg="#111", anchor="w",
                                 font=("Microsoft YaHei UI", 9), padx=12)
        self.enc_head.pack(fill="x", pady=(7, 3))
        self.enc_bar = tk.Canvas(self.enc_frame, height=9, bg=CARD, highlightthickness=0)
        self.enc_bar.pack(fill="x", padx=12, pady=(0, 8))
        self._enc_visible = False
        self._enc_prev = None
        self._enc_rate = None

        self.banner = tk.Label(card, text="", bg=CARD, fg="#111", anchor="w",
                               font=("Microsoft YaHei UI", 9), padx=12, pady=6)
        self.banner.pack(fill="x", padx=14, pady=(10, 0))

        quick = tk.Frame(card, bg=CARD)
        quick.pack(fill="x", padx=14, pady=(8, 0))
        tk.Button(quick, text="⚡ 一键替换", command=self.one_click_replace,
                  relief="flat", bg="#16a34a", fg="white",
                  font=("Microsoft YaHei UI", 11, "bold"), padx=24, pady=6).pack(side="left")
        tk.Button(quick, text="⟳ 一键刷新列表", command=self.one_click_refresh,
                  relief="flat", bg="#2563eb", fg="white",
                  font=("Microsoft YaHei UI", 11, "bold"), padx=20, pady=6).pack(side="left", padx=10)
        self.quick_note = tk.Label(quick, text="选好 APK（或整个文件夹）后点「一键替换」，剩下交给它",
                                   bg=CARD, fg=MUTED, font=("Microsoft YaHei UI", 9))
        self.quick_note.pack(side="left", padx=12)

        head = tk.Frame(card, bg=CARD)
        head.pack(fill="x", padx=14, pady=(6, 4))
        tk.Label(head, text="① 选择要广播的 APK（可点「选文件夹」一次上架多个）", bg=CARD,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(side="left")
        self.status_dot = tk.Label(head, text="●  未启动   ·   本机 IP " + local_ip(), bg=CARD, fg=MUTED,
                                   font=("Microsoft YaHei UI", 10, "bold"))
        self.status_dot.pack(side="right")

        row1 = tk.Frame(card, bg=CARD)
        row1.pack(fill="x", padx=14, pady=4)
        self.apk_var = tk.StringVar()
        tk.Entry(row1, textvariable=self.apk_var, font=("Consolas", 9),
                 relief="solid", bd=1).pack(side="left", fill="x", expand=True, ipady=4)
        tk.Button(row1, text="浏览…", command=self._browse, relief="solid", bd=1,
                  bg="#eef2ff", padx=12).pack(side="left", padx=(8, 0))
        tk.Button(row1, text="选文件夹…", command=self._browse_dir, relief="solid", bd=1,
                  bg="#f3f4f6", padx=10).pack(side="left", padx=(6, 0))

        tk.Label(card, text="② 劫持设置（留空 = 所有域名都指到本机）", bg=CARD,
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=14, pady=(10, 2))

        row2 = tk.Frame(card, bg=CARD)
        row2.pack(fill="x", padx=14, pady=4)
        tk.Label(row2, text="只劫持：", bg=CARD).pack(side="left")
        self.only_var = tk.StringVar()
        tk.Entry(row2, textvariable=self.only_var, width=34, relief="solid", bd=1).pack(side="left", ipady=3)
        tk.Label(row2, text="例 *.xxx.com,*.yyy.cn", bg=CARD, fg=MUTED).pack(side="left", padx=(6, 16))

        tk.Label(row2, text="上游DNS：", bg=CARD).pack(side="left")
        self.upstream_var = tk.StringVar(value="")
        tk.Entry(row2, textvariable=self.upstream_var, width=14, relief="solid", bd=1).pack(side="left", ipady=3)
        tk.Label(row2, text="留空=不放行", bg=CARD, fg=MUTED).pack(side="left", padx=(4, 0))

        row_opt = tk.Frame(card, bg=CARD)
        row_opt.pack(fill="x", padx=14, pady=(2, 0))
        self.passthrough_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row_opt, text="转发到真实服务器（商店还能用时勾上）",
                       variable=self.passthrough_var, bg=CARD, activebackground=CARD,
                       font=("Microsoft YaHei UI", 9)).pack(side="left")
        self.rewrite_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row_opt, text="自动改写 MD5/大小（防校验失败）",
                       variable=self.rewrite_var, bg=CARD, activebackground=CARD,
                       font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(18, 0))
        self.https_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row_opt, text="同时接管 HTTPS（手机要装证书）",
                       variable=self.https_var, bg=CARD, activebackground=CARD,
                       font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(18, 0))
        self.md5_label = tk.Label(row_opt, text="", bg=CARD, fg=MUTED,
                                  font=("Consolas", 8))
        self.md5_label.pack(side="right")

        row_inj = tk.Frame(card, bg=CARD)
        row_inj.pack(fill="x", padx=14, pady=(4, 0))
        self.inject_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row_inj, text="把我的应用加进商店列表（不只是替换）",
                       variable=self.inject_var, bg=CARD, activebackground=CARD,
                       font=("Microsoft YaHei UI", 9)).pack(side="left")
        tk.Button(row_inj, text="编辑上架条目…", command=self._edit_entry,
                  relief="solid", bd=1, bg="#eef2ff", padx=10).pack(side="left", padx=(12, 0))
        tk.Button(row_inj, text="打开目录样本", command=self._open_catalog,
                  relief="solid", bd=1, bg="#f3f4f6", padx=10).pack(side="left", padx=6)
        self.inject_hint = tk.Label(row_inj, text="", bg=CARD, fg=MUTED,
                                    font=("Microsoft YaHei UI", 8))
        self.inject_hint.pack(side="right")

        row_hs = tk.Frame(card, bg=CARD)
        row_hs.pack(fill="x", padx=14, pady=(4, 0))
        self.hotspot_var = tk.BooleanVar(value=False)
        tk.Checkbutton(row_hs, text="电脑开热点模式（手机不能改 DNS 时用这个）",
                       variable=self.hotspot_var, bg=CARD, activebackground=CARD,
                       command=self._on_hotspot_toggle,
                       font=("Microsoft YaHei UI", 9)).pack(side="left")
        self.hs_label = tk.Label(row_hs, text="", bg=CARD, fg=MUTED,
                                 font=("Microsoft YaHei UI", 8))
        self.hs_label.pack(side="left", padx=10)
        tk.Button(row_hs, text="恢复系统 DNS", command=self._restore_dns,
                  relief="solid", bd=1, bg="#fef3c7", padx=10).pack(side="right")
        self.observe_var = tk.BooleanVar(value=False)
        tk.Checkbutton(row_hs, text="观察模式（只记录域名，不改写）",
                       variable=self.observe_var, bg=CARD, activebackground=CARD,
                       font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(14, 0))
        tk.Button(row_hs, text="导出系统证书", command=self.export_system_cert,
                  relief="solid", bd=1, bg="#e0e7ff", padx=10).pack(side="right", padx=6)

        row3 = tk.Frame(card, bg=CARD)
        row3.pack(fill="x", padx=14, pady=(6, 12))
        tk.Label(row3, text="DNS 端口", bg=CARD).pack(side="left")
        self.dns_port = tk.StringVar(value="53")
        tk.Spinbox(row3, from_=1, to=65535, textvariable=self.dns_port, width=6,
                   relief="solid", bd=1).pack(side="left", padx=(4, 14), ipady=2)
        tk.Label(row3, text="HTTP 端口", bg=CARD).pack(side="left")
        self.http_port = tk.StringVar(value="80")
        tk.Spinbox(row3, from_=1, to=65535, textvariable=self.http_port, width=6,
                   relief="solid", bd=1).pack(side="left", padx=(4, 18), ipady=2)

        self.btn_start = tk.Button(row3, text="启动", command=self.start, bg=ACCENT, fg="white",
                                   font=("Microsoft YaHei UI", 10, "bold"), relief="flat",
                                   padx=22, pady=4, state="normal")
        self.btn_start.pack(side="left")
        self.btn_stop = tk.Button(row3, text="停止", command=self.stop, bg="#e5e7eb", fg="#111",
                                  font=("Microsoft YaHei UI", 10), relief="flat",
                                  padx=18, pady=4, state="disabled")
        self.btn_stop.pack(side="left", padx=8)
        tk.Button(row3, text="手机怎么设置？", command=self._show_help, relief="flat",
                  bg="#eef2ff", padx=12, pady=4).pack(side="left", padx=8)
        tk.Button(row3, text="会话状态", command=self._show_panel, relief="flat",
                  bg="#ecfdf5", padx=12, pady=4).pack(side="left", padx=8)

        # ---- 状态栏（先占住底部，免得被表格挤掉）----
        bar = tk.Frame(outer, bg=BG)
        bar.pack(side="bottom", fill="x", pady=(4, 0))
        self.ip_label = tk.Label(bar, text="本机 IP：" + local_ip(), bg=BG, fg="#111",
                                 font=("Microsoft YaHei UI", 9, "bold"))
        self.ip_label.pack(side="left")
        self.count_label = tk.Label(bar, text="记录 0 条", bg=BG, fg=MUTED,
                                    font=("Microsoft YaHei UI", 9))
        self.count_label.pack(side="left", padx=18)
        self.log_label = tk.Label(bar, text="", bg=BG, fg=MUTED, font=("Microsoft YaHei UI", 9))
        self.log_label.pack(side="right")

        # ---- 标签页 ----
        nb = ttk.Notebook(outer)
        nb.pack(fill="both", expand=True, pady=(10, 6))
        self.nb = nb

        live = tk.Frame(nb, bg=CARD)
        nb.add(live, text="  实时请求  ")
        cols = ("time", "kind", "client", "host", "path", "action")
        self.tree = ttk.Treeview(live, columns=cols, show="headings", height=14)
        for c, t, w, anchor in (
            ("time", "时间", 70, "center"),
            ("kind", "类型", 60, "center"),
            ("client", "来源", 110, "w"),
            ("host", "域名 / 主机", 250, "w"),
            ("path", "路径", 260, "w"),
            ("action", "结果", 130, "w"),
        ):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor=anchor, stretch=(c in ("host", "path")))
        vs = ttk.Scrollbar(live, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.tree.tag_configure("apk", background="#dcfce7")
        self.tree.tag_configure("dns", foreground="#374151")
        self.tree.tag_configure("miss", foreground="#9ca3af")
        self.tree.tag_configure("fail", background="#fef2f2", foreground="#b91c1c")

        summ = tk.Frame(nb, bg=CARD)
        nb.add(summ, text="  汇总  ")
        self.sum_tree = ttk.Treeview(summ, columns=("what", "n"), show="headings", height=14)
        self.sum_tree.heading("what", text="域名 / 路径")
        self.sum_tree.heading("n", text="次数")
        self.sum_tree.column("what", width=680, anchor="w")
        self.sum_tree.column("n", width=90, anchor="center")
        self.sum_tree.pack(fill="both", expand=True)
        self.sum_hint = tk.Label(summ, text="启动后自动统计", bg=CARD, fg=MUTED, anchor="w")
        self.sum_hint.pack(fill="x", padx=8, pady=4)

        net_tab = tk.Frame(nb, bg=CARD)
        nb.add(net_tab, text="  自检  ")
        bar_net = tk.Frame(net_tab, bg=CARD)
        bar_net.pack(fill="x", padx=10, pady=8)
        tk.Button(bar_net, text="一键自检", command=self.net_selftest,
                  relief="flat", bg=ACCENT, fg="white", padx=14, pady=3).pack(side="left")
        tk.Button(bar_net, text="扫描局域网设备", command=self.net_scan,
                  relief="solid", bd=1, bg="#f3f4f6", padx=12, pady=3).pack(side="left", padx=8)
        tk.Button(bar_net, text="检测上游 DNS", command=self.net_dns,
                  relief="solid", bd=1, bg="#f3f4f6", padx=12, pady=3).pack(side="left")
        self.net_text = tk.Text(net_tab, wrap="none", relief="flat", bg="#0f172a",
                                fg="#d1fae5", insertbackground="white",
                                font=("Consolas", 9), padx=10, pady=8)
        self.net_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.net_text.insert("1.0", "点「一键自检」开始：会检查本机网段、端口、上游 DNS，并给出建议。\n")
        self.net_text.configure(state="disabled")

        phone_tab = tk.Frame(nb, bg=CARD)
        nb.add(phone_tab, text="  手机中介  ")
        bar_ph = tk.Frame(phone_tab, bg=CARD)
        bar_ph.pack(fill="x", padx=10, pady=8)
        tk.Button(bar_ph, text="检测手机", command=self.phone_detect,
                  relief="flat", bg=ACCENT, fg="white", padx=14, pady=3).pack(side="left")
        tk.Button(bar_ph, text="下发 DNS 转发", command=self.phone_install,
                  relief="solid", bd=1, bg="#dcfce7", padx=12, pady=3).pack(side="left", padx=8)
        tk.Button(bar_ph, text="撤销转发", command=self.phone_remove,
                  relief="solid", bd=1, bg="#fee2e2", padx=12, pady=3).pack(side="left")
        tk.Button(bar_ph, text="复制手动命令", command=self.phone_copy,
                  relief="solid", bd=1, bg="#f3f4f6", padx=12, pady=3).pack(side="left", padx=8)
        self.phone_text = tk.Text(phone_tab, wrap="word", relief="flat", bg="#0f172a",
                                  fg="#e5e7eb", font=("Consolas", 9), padx=10, pady=8)
        self.phone_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self._phone_log("手机中介模式：老手机连新手机热点，新手机用 USB 连电脑。\n"
                        "点「检测手机」看 adb 是否可用。\n")

        help_tab = tk.Frame(nb, bg=CARD)
        nb.add(help_tab, text="  使用说明  ")
        self.help_text = tk.Text(help_tab, wrap="word", relief="flat", bg=CARD,
                                 font=("Microsoft YaHei UI", 10), padx=16, pady=12)
        self.help_text.pack(fill="both", expand=True)
        self._fill_help()


    def _log_action(self, text):
        try:
            os.makedirs(os.path.join(PROJECT_DIR, "data"), exist_ok=True)
            with open(os.path.join(PROJECT_DIR, "data", "action.log"), "a",
                      encoding="utf-8") as f:
                f.write("[" + time.strftime("%H:%M:%S") + "] " + text + "\n")
        except OSError:
            pass

    def _banner(self, text, kind="info"):
        colors = {"info": ("#eef2ff", "#1e3a8a"), "ok": ("#dcfce7", "#166534"),
                  "warn": ("#fef3c7", "#92400e"), "err": ("#fee2e2", "#991b1b")}
        bg, fg = colors.get(kind, colors["info"])
        self.banner.configure(text=text, bg=bg, fg=fg)
        self._log_action("横幅：" + text)

    def _ui_stopped(self):
        self.running = False
        try:
            self.btn_start.configure(state="normal", bg=ACCENT)
            self.btn_stop.configure(state="disabled", bg="#e5e7eb")
        except Exception:
            pass

    def _emergency_restore(self):
        """进程退出（含异常）时的最后一道保险。"""
        try:
            if self._load_backup():
                self._restore_dns(silent=True)
        except Exception:
            pass

    def _write_error_log(self, text):
        try:
            os.makedirs(os.path.join(PROJECT_DIR, "data"), exist_ok=True)
            path = os.path.join(PROJECT_DIR, "data", "error.log")
            with open(path, "a", encoding="utf-8") as f:
                f.write("\n===== " + time.strftime("%Y-%m-%d %H:%M:%S") + " =====\n")
                f.write(text + "\n")
        except OSError:
            pass

    def _on_tk_error(self, exc, val, tb):
        text = "".join(traceback.format_exception(exc, val, tb))
        self._write_error_log(text)
        try:
            self.status_dot.configure(text="●  出错了（见 data\\error.log）", fg=BAD)
        except Exception:
            pass
        messagebox.showerror("出错了", f"{val}\n\n详情：data\\error.log", parent=self.root)

    # ------------------------------------------------------------ 交互
    def _browse(self):
        path = filedialog.askopenfilename(title="选择要安装到手机的 APK（选多个可用「选文件夹」）",
                                          filetypes=[("Android 安装包", "*.apk"), ("所有文件", "*.*")])
        if path:
            self.apk_var.set(path)
            self._show_apk_info()

    def _browse_dir(self):
        path = filedialog.askdirectory(title="选择存放 APK 的文件夹（里面的包会一起广播）")
        if path:
            self.apk_var.set(path)
            self._show_apk_info()

    # ------------------------------------------------------------ 上架条目
    def _entry_path(self):
        return os.path.join(PROJECT_DIR, "data", "entry.json")

    def _ensure_entry(self, cfg, ip, http_port):
        """生成上架条目：单个 APK 出一条，APK 目录出多条。"""
        entries = cfg.entries(ip, http_port)
        if not entries:
            return []

        path = self._entry_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(entries if len(entries) > 1 else entries[0], f,
                          ensure_ascii=False, indent=2)
        except OSError:
            pass

        names = "、".join(e.get("packageName", "?") for e in entries)
        if len(entries) > 1:
            self.inject_hint.configure(text=f"广播 {len(entries)} 个应用：{names[:60]}")
        else:
            self.inject_hint.configure(text=f"条目：{entries[0].get('name')} / {names}")
        return entries

    def _edit_entry(self):
        path = self._entry_path()
        if not os.path.exists(path):
            messagebox.showinfo("还没有条目", "先选一个 APK 再点启动，程序会自动生成条目文件。")
            return
        try:
            os.startfile(path)          # Windows 用默认程序打开
        except AttributeError:
            pass

    def _open_catalog(self):
        path = os.path.join(PROJECT_DIR, "data", "catalog")
        if not os.path.isdir(path):
            messagebox.showinfo("还没有样本",
                                "先启动、并用手机打开商店，程序会把商店返回的目录 JSON 存到这里。")
            return
        try:
            os.startfile(path)
        except AttributeError:
            pass

    # ------------------------------------------------------------ 热点模式
    def _on_hotspot_toggle(self):
        if not self.hotspot_var.get():
            self.hs_label.configure(text="")
            return
        from . import hotspot
        info = hotspot.hotspot_info()
        self.hs_label.configure(text=f"热点网关 {info['ip']}" if info else "没检测到热点网卡")

    def _internet_adapter(self):
        """找正在上网的那块网卡（有默认网关的那块）。"""
        from . import hotspot
        gw = hotspot.gateway()
        for a in hotspot.list_adapters():
            if a["ip"] and gw and a["ip"].rsplit(".", 1)[0] == gw.rsplit(".", 1)[0]:
                return a
        for a in hotspot.list_adapters():
            if a["ip"].startswith("192.168.137."):
                continue
        return hotspot.list_adapters()[0] if hotspot.list_adapters() else None

    def export_system_cert(self):
        try:
            import hashlib
            from .capture import CertificateAuthority
        except Exception as e:
            messagebox.showerror("导出失败", str(e), parent=self.root)
            return
        ca = CertificateAuthority(os.path.join(PROJECT_DIR, "data", "ca"))
        name_der = ca.cert.subject.public_bytes()
        hash_hex = hashlib.md5(name_der).digest()[:4][::-1].hex()
        out = os.path.join(PROJECT_DIR, "data", "ca", hash_hex + ".0")
        with open(out, "wb") as f:
            with open(ca.cert_path, "rb") as src:
                f.write(src.read())
        self._banner(f"系统证书已导出：data\\ca\\{hash_hex}.0", "ok")
        messagebox.showinfo(
            "系统证书",
            f"已导出：\n{out}\n\n"
            "有 root 的手机：\n"
            f"1. 把 {hash_hex}.0 复制到 /system/etc/security/cacerts/\n"
            "2. chmod 644，属主 root:root\n"
            "3. 重启手机\n\n"
            "（Magisk 用户做成模块也一样）",
            parent=self.root)

    # ------------------------------------------------------------ 一键操作
    def one_click_replace(self):
        from .store_profiles import DEFAULT_ONLY
        if self.running:
            self._banner("已经在运行了，直接打开手机商店即可", "warn")
            return
        apk = self.apk_var.get().strip()
        if not apk or not os.path.exists(apk):
            self._banner("先在上面第 ① 步选一个 APK", "warn")
            messagebox.showinfo("还差一步", "先点「浏览…」选择要装到手机上的 APK。",
                                parent=self.root)
            return
        self.passthrough_var.set(True)
        self.rewrite_var.set(True)
        self.inject_var.set(True)
        self.https_var.set(True)
        self.only_var.set(DEFAULT_ONLY)
        self.quick_note.configure(text="华为 / 腾讯 双商店模式：下载换包 + 列表注入 + 免缓存")
        self._banner("一键替换：正在启动（华为 / 腾讯 通用）…", "info")
        self.start()

    def one_click_refresh(self):
        if not self.running:
            self._banner("还没启动，先点「一键替换」", "warn")
            messagebox.showinfo("还没启动", "先点「⚡ 一键替换」，再刷新列表。", parent=self.root)
            return
        self._refresh_token = getattr(self, "_refresh_token", 0) + 1
        cfg = getattr(self, "cfg", None)
        if cfg is not None:
            cfg.refresh_token = self._refresh_token
        # 清掉本地视图，方便对照新数据
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.summary.clear()
        self._refresh_summary()
        self.counts = {"dns": 0, "http": 0, "apk": 0, "tls_fail": 0}
        self._banner(f"刷新信号已发出（第 {self._refresh_token} 次）："
                     f"到手机上回到商店首页下拉刷新，或退出重进商店", "ok")
        self._log_action(f"一键刷新列表 #{self._refresh_token}")

    # ---------- 网络保险：备份 / 还原 / 看门狗 ----------
    def _backup_path(self):
        return os.path.join(PROJECT_DIR, "data", "dns-backup.json")

    def _save_backup(self, name, servers):
        try:
            os.makedirs(os.path.dirname(self._backup_path()), exist_ok=True)
            with open(self._backup_path(), "w", encoding="utf-8") as f:
                json.dump({"adapter": name, "servers": servers,
                           "time": time.strftime("%Y-%m-%d %H:%M:%S")},
                          f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def _load_backup(self):
        try:
            with open(self._backup_path(), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return None

    def _clear_backup(self):
        try:
            os.remove(self._backup_path())
        except OSError:
            pass

    def _apply_hotspot_dns(self, info):
        from . import hotspot
        adapter = self._internet_adapter()
        if not adapter:
            self._banner("找不到上网网卡，DNS 没有改动", "err")
            return False
        name = adapter["name"]
        original = hotspot.get_dns(name)
        self._save_backup(name, original)          # 先落盘，再动手
        self._dns_backup = (name, original)
        hotspot.set_dns(name, "127.0.0.1")
        current = hotspot.get_dns(name)
        if "127.0.0.1" not in current:
            self._restore_dns(silent=True)
            self._banner("设置 DNS 失败（可能要管理员权限），已自动还原", "err")
            return False
        try:
            self.hs_label.configure(text=f"DNS → {', '.join(current)}")
        except Exception:
            pass
        return True

    def _restore_dns(self, silent=False):
        backup = getattr(self, "_dns_backup", None) or self._load_backup()
        if not backup:
            self._reset_all_dns(silent=silent)
            return
        from . import hotspot
        name = backup.get("adapter") if isinstance(backup, dict) else backup[0]
        servers = backup.get("servers") if isinstance(backup, dict) else backup[1]
        if servers:
            hotspot.set_dns(name, servers[0])
        else:
            hotspot.reset_dns(name)
        self._dns_backup = None
        self._clear_backup()
        try:
            self.hs_label.configure(text="DNS 已还原")
        except Exception:
            pass
        if not silent:
            self._banner(f"{name} 的 DNS 已还原", "ok")

    def _reset_all_dns(self, silent=False):
        """兜底：把所有在用网卡恢复成自动获取 DNS。"""
        cmd = ("Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | "
               "ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex "
               "-ResetServerAddresses }; ipconfig /flushdns")
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                           capture_output=True, timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            pass
        self._dns_backup = None
        self._clear_backup()
        try:
            self.hs_label.configure(text="DNS 已恢复自动获取")
        except Exception:
            pass
        if not silent:
            self._banner("所有网卡的 DNS 已恢复为自动获取", "ok")

    def _check_stale_backup(self):
        """上次没正常退出（崩溃/强杀）的话，开机先还原网络。"""
        if not self._load_backup():
            return
        self._banner("检测到上次没有正常退出，正在还原网络…", "warn")
        self._restore_dns(silent=True)
        self._banner("网络已还原：上次遗留的 DNS 设置已清除", "ok")

    def _start_dns_watchdog(self):
        self._watch_stop = threading.Event()
        port = int(self.dns_port.get() or 53)

        def loop():
            fails = 0
            while not self._watch_stop.is_set():
                time.sleep(5)
                if self._watch_stop.is_set():
                    break
                if self._dns_alive(port):
                    fails = 0
                    continue
                fails += 1
                if fails >= 3:
                    self._restore_dns(silent=True)
                    self._banner("DNS 服务连续无响应，已自动把网络还原", "err")
                    return

        threading.Thread(target=loop, daemon=True).start()

    def _dns_alive(self, port):
        pkt = (b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00"
               b"\x03www\x05baidu\x03com\x00\x00\x01\x00\x01")
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        try:
            s.sendto(pkt, ("127.0.0.1", port))
            data, _ = s.recvfrom(512)
            return len(data) > 12
        except OSError:
            return False
        finally:
            s.close()

    # ------------------------------------------------------------ 手机中介
    def _phone_log(self, text):
        self.phone_text.configure(state="normal")
        self.phone_text.insert("end", text + "\n")
        self.phone_text.see("end")
        self.phone_text.configure(state="disabled")

    def phone_detect(self):
        self._bg(self._phone_detect_worker)

    def _phone_detect_worker(self):
        from . import phone

        adb = phone.find_adb()
        if not adb:
            self._phone_log("✗ 没找到 adb。")
            self._phone_log("  装一个 platform-tools，把 adb.exe 放到程序目录，或加进 PATH。")
            self._phone_log("  没有 adb 就只能用「手动命令」那套，在手机上用终端 App 执行。")
            return
        self._phone_log(f"✓ adb: {adb}")
        devs = phone.devices(adb)
        if not devs:
            self._phone_log("✗ 没有设备。检查：USB 线是否数据线、手机是否开了「USB 调试」、")
            self._phone_log("  手机上是否点了「允许此电脑调试」。")
            return
        self._phone_log(f"✓ 设备: {', '.join(devs)}")
        self._adb = adb
        self._serial = devs[0]
        rooted = phone.has_root(adb, self._serial)
        self._phone_log(f"{'✓' if rooted else '✗'} root：{'有' if rooted else '没有（无法自动下发 iptables）'}")
        ips = phone.phone_ip(adb, self._serial)
        self._phone_log(f"手机地址: {', '.join(ips) if ips else '(没取到)'}")
        self._phone_log(f"电脑候选地址: {local_ip()}")
        self._phone_log("\n下一步：确认老手机已连上新手机热点，然后点「下发 DNS 转发」。")

    def _target_ip(self):
        """挑一个手机能访问到的电脑地址。"""
        from . import netcheck

        return netcheck.local_ip()

    def phone_install(self):
        self._bg(self._phone_install_worker)

    def _phone_install_worker(self):
        from . import phone

        adb = getattr(self, "_adb", None) or phone.find_adb()
        serial = getattr(self, "_serial", None)
        if not adb or not serial:
            self._phone_log("先点「检测手机」。")
            return
        if not phone.has_root(adb, serial):
            self._phone_log("✗ 没有 root，无法下发。用「复制手动命令」在手机上手动执行。")
            return
        pc_ip = self._target_ip()
        self._phone_log(f"下发规则：手机 53 → {pc_ip} …")
        for cmd, rc, out in phone.install_redirect(adb, serial, pc_ip):
            self._phone_log(f"  {'✓' if rc == 0 else '✗'} {cmd}")
            if out:
                self._phone_log(f"    {out[:120]}")
        self._phone_log("完成。现在打开老手机的商店，看有没有 DNS 行进来。")

    def phone_remove(self):
        self._bg(self._phone_remove_worker)

    def _phone_remove_worker(self):
        from . import phone

        adb = getattr(self, "_adb", None) or phone.find_adb()
        serial = getattr(self, "_serial", None)
        if not adb or not serial:
            self._phone_log("先点「检测手机」。")
            return
        pc_ip = self._target_ip()
        self._phone_log(f"撤销规则（{pc_ip}）…")
        for cmd, rc, out in phone.remove_redirect(adb, serial, pc_ip):
            self._phone_log(f"  {'✓' if rc == 0 else '✗'} {cmd}")

    def phone_copy(self):
        from . import phone
        cmds = "\n".join(phone.manual_commands(self._target_ip()))
        self.root.clipboard_clear()
        self.root.clipboard_append(cmds)
        self._phone_log("已复制到剪贴板：\n" + cmds)

    # ------------------------------------------------------------ 自检
    def _net_log(self, text):
        self.net_text.configure(state="normal")
        self.net_text.insert("end", text + "\n")
        self.net_text.see("end")
        self.net_text.configure(state="disabled")

    def _bg(self, fn):
        threading.Thread(target=fn, daemon=True).start()

    def net_selftest(self):
        self._bg(self._selftest_worker)

    def _selftest_worker(self):
        from . import netcheck

        ip = netcheck.local_ip()
        gw = netcheck.gateway()
        self._net_log("=" * 52)
        self._net_log(f"本机 IP     : {ip}")
        self._net_log(f"默认网关    : {gw or '(没拿到)'}")
        self._net_log(f"网段        : {'.'.join(ip.split('.')[:3])}.0/24")

        for port, udp, name in ((53, True, "DNS(UDP)"), (80, False, "HTTP"),
                                (443, False, "HTTPS")):
            free = netcheck.check_port(port, udp=udp)
            self._net_log(f"端口 {name:<9}: {'可用' if free else '被占用（换个程序或关掉占用者）'}")

        self._net_log("\n正在测上游 DNS ……")
        results = netcheck.check_dns()
        best = ""
        for r in results:
            if r["ok"]:
                self._net_log(f"  {r['server']:<16} 可用  {r['ms']} ms")
                if not best:
                    best = r["server"]
            else:
                self._net_log(f"  {r['server']:<16} 不可用")
        if best:
            self.upstream_var.set(best)
            self._net_log(f"\n建议上游 DNS：{best}（已自动填入）")
        else:
            self._net_log("\n所有候选 DNS 都不通，检查电脑本身能不能上网")

        self._net_log("\n正在扫描局域网 ……")
        devices = netcheck.scan_lan()
        if not devices:
            self._net_log("  没扫到设备（可能是防火墙拦了 ICMP，不影响劫持）")
        for d in devices[:30]:
            tag = d["vendor"] or "未知设备"
            mark = "  ← 本机" if d["ip"] == ip else ""
            self._net_log(f"  {d['ip']:<15} {d['mac']:<18} {tag}{mark}")
        self._net_log("\n手机连上热点后，把它的 DNS 指到本机 IP 即可。")

    def net_scan(self):
        self._bg(self._scan_worker)

    def _scan_worker(self):
        from . import netcheck
        self._net_log("\n扫描中（每个地址 ping 一次，约 5~15 秒）……")
        devices = netcheck.scan_lan()
        for d in devices[:40]:
            self._net_log(f"  {d['ip']:<15} {d['mac']:<18} {d['vendor'] or '未知设备'}")

    def net_dns(self):
        self._bg(self._dns_worker)

    def _dns_worker(self):
        from . import netcheck
        self._net_log("\n测上游 DNS ……")
        for r in netcheck.check_dns():
            self._net_log(f"  {r['server']:<16} {'可用  ' + str(r['ms']) + ' ms' if r['ok'] else '不可用'}")

    def _show_apk_info(self):
        path = self.apk_var.get().strip()
        if not path or not os.path.exists(path):
            self.md5_label.configure(text="")
            return
        try:
            if os.path.isdir(path):
                from .library import scan_dir
                items, errors = scan_dir(path)
                total = sum(i.size for i in items)
                self.md5_label.configure(
                    text=f"{len(items)} 个包  {total/1048576:.0f} MB"
                         + (f"  ({len(errors)} 个跳过)" if errors else ""))
                return
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                md5 = hashlib.md5(f.read()).hexdigest()
            size_text = f"{size/1024/1024:.1f} MB" if size >= 1024 * 1024 else f"{size/1024:.0f} KB"
            self.md5_label.configure(text=f"{size_text}   md5 {md5[:12]}…")
        except OSError:
            self.md5_label.configure(text="")

    def _show_help(self):
        ip = local_ip()
        messagebox.showinfo("手机设置", (
            f"1. 手机连上同一个 WiFi\n"
            f"2. WiFi → 修改网络 → 高级 → IP 设置改成「静态」\n"
            f"3. IP 地址：{ip.rsplit('.', 1)[0]}.200（同网段、不冲突即可）\n"
            f"4. 网关：你家路由器地址\n"
            f"5. DNS 1：{ip}   ← 关键\n"
            f"6. 保存后打开那个应用商店\n\n"
            f"电脑上会逐条显示它访问了什么。"
        ))

    def _show_panel(self):
        """打开（或重新打开）会话自检面板。"""
        if getattr(self, "panel", None) is None:
            try:
                from .session_panel import SessionPanel
                self.panel = SessionPanel(self, self.root)
            except Exception as e:
                messagebox.showerror("会话状态", f"面板创建失败：{e}")
                return
        self.panel.show()

    # ---------- 主页面操作流程图 ----------
    FLOW_STEPS = [
        ("① 开热点",   "电脑开启移动热点"),
        ("② 车机连网", "车机 WiFi 连热点"),
        ("③ 装CA证书", "车机浏览器开 :8898"),
        ("④ 启动广播", "选好APK → 点启动"),
        ("⑤ 刷商店",   "车机商店首页刷新"),
        ("⑥ 核对会话", "会话状态=已捕获"),
        ("⑦ 下载安装", "商店里点下载"),
    ]

    def _flow_states(self):
        """每一步的点亮状态：done(绿)/warn(红)/todo(灰)。"""
        cfg = getattr(self, "cfg", None)
        running = self.running
        got_session = bool(cfg is not None and cfg.eff_plain and cfg.eff_cipher)
        tls_bad = bool(self.counts.get("tls_fail"))
        apk_ok = bool(self.counts.get("apk"))
        return [
            "todo",                                  # ① 热点：程序无法直接感知
            "done" if (self.counts.get("dns") or self.counts.get("http")) else "todo",
            "warn" if tls_bad else "todo",           # ③ 证书：握手失败=没装/装错
            "done" if running else "todo",
            "done" if got_session else "todo",
            "done" if got_session else "todo",
            "done" if apk_ok else "todo",
        ]

    def _draw_flow(self):
        c = self.flow
        c.delete("all")
        w = max(c.winfo_width(), 600)
        h = 92
        n = len(self.FLOW_STEPS)
        gap = 14
        bw = (w - 20 - gap * (n - 1)) / n
        states = self._flow_states()
        colors = {"done": ("#ecfdf5", "#16a34a"), "warn": ("#fef2f2", "#dc2626"),
                  "todo": ("#f9fafb", "#9ca3af")}
        for i, ((title, sub), st) in enumerate(zip(self.FLOW_STEPS, states)):
            x0 = 10 + i * (bw + gap)
            x1 = x0 + bw
            fill, line = colors[st]
            c.create_rectangle(x0, 12, x1, h - 12, fill=fill, outline=line, width=1)
            c.create_text((x0 + x1) / 2, 34, text=title, fill="#111827",
                          font=("Microsoft YaHei UI", 9, "bold"))
            c.create_text((x0 + x1) / 2, 56, text=sub, fill="#6b7280",
                          font=("Microsoft YaHei UI", 8))
            if st == "warn" and i == 2:
                c.create_text((x0 + x1) / 2, h - 22, text="握手被拒→先装证书!",
                              fill="#dc2626", font=("Microsoft YaHei UI", 8, "bold"))
            if i < n - 1:
                ax = x1 + gap / 2
                c.create_line(x1 + 2, h / 2, x1 + gap - 3, h / 2,
                              fill="#9ca3af", arrow="last", width=1)
        self._flow_state = tuple(states)

    def _maybe_redraw_flow(self):
        st = tuple(self._flow_states())
        if st != self._flow_state:
            self._draw_flow()

    # ---------------- 加密进度 ----------------
    @staticmethod
    def _fmt_size(n):
        n = float(n)
        if n >= 1048576:
            return f"{n / 1048576:.1f} MB"
        if n >= 1024:
            return f"{n / 1024:.0f} KB"
        return f"{n:.0f} B"

    def _update_enc_progress(self):
        cfg = getattr(self, "cfg", None)
        st = getattr(cfg, "enc_state", None) if cfg is not None else None
        if not st or not st.get("total"):
            if self._enc_visible:
                self.enc_frame.pack_forget()
                self._enc_visible = False
            self._enc_prev = None
            self._enc_rate = None
            return

        pkg = st.get("package") or "APK"
        done = int(st.get("done") or 0)
        total = max(int(st.get("total") or 1), 1)
        err = (st.get("error") or "").strip()
        now = time.time()
        pct = min(done * 100.0 / total, 100.0)

        # 完成态只停留 2.5 秒，随后收起
        if not err and done >= total and now - float(st.get("ts") or now) > 2.5:
            if self._enc_visible:
                self.enc_frame.pack_forget()
                self._enc_visible = False
            self._enc_prev = None
            self._enc_rate = None
            return

        # 速度：对相邻采样做指数平滑
        if not err and done < total:
            prev = self._enc_prev
            if prev and prev[0] == pkg:
                dt = now - prev[1]
                dd = done - prev[2]
                if dt >= 0.12 and dd > 0:
                    inst = dd / dt
                    self._enc_rate = (inst if self._enc_rate is None
                                      else 0.55 * self._enc_rate + 0.45 * inst)
            elif prev and prev[0] != pkg:
                self._enc_rate = None      # 换了包，速度重新计
            self._enc_prev = (pkg, now, done)
        else:
            self._enc_prev = None

        if err:
            head, color, fill = f"加密失败 · {pkg}", "#c62828", pct
            detail = err
        elif done >= total:
            head, color, fill = f"密文已就绪 · {pkg}", "#16a34a", 100
            detail = "车机点下载即可立刻开始传输，不用再等"
        else:
            head, color, fill = f"正在加密 · {pkg}", ACCENT, pct
            bits = [f"{pct:.0f}%", f"{self._fmt_size(done)} / {self._fmt_size(total)}"]
            rate = self._enc_rate or 0
            if rate > 0:
                bits.append(f"{self._fmt_size(rate)}/s")
                remain = (total - done) / rate
                if 0 < remain < 600:
                    bits.append(f"剩余约 {max(1, round(remain))} 秒")
            detail = "  ·  ".join(bits)

        self.enc_head.configure(text=f"{head}\n{detail}",
                                fg=color if (err or done >= total) else "#111")

        self.enc_bar.delete("all")
        w = self.enc_bar.winfo_width()
        if w <= 1:
            w = max(self.enc_frame.winfo_width() - 24, 240)
        h = 9
        self.enc_bar.create_rectangle(0, 0, w, h, fill="#eef1f4", outline="")
        if fill > 0:
            self.enc_bar.create_rectangle(0, 0, max(w * fill / 100.0, 2), h,
                                          fill=color, outline="")

        if not self._enc_visible:
            self.enc_frame.pack(fill="x", pady=(0, 8), before=self.card_frame)
            self._enc_visible = True

    def start(self):
        if self.running:
            self._banner("已经在运行了，先点「停止」再启动。", "warn")
            return
        try:
            self.status_dot.configure(text="●  正在启动…", fg=ACCENT)
            self._log_action(f"点击启动 apk={self.apk_var.get()!r} "
                             f"dns={self.dns_port.get()} http={self.http_port.get()} "
                             f"https={self.https_var.get()} hotspot={self.hotspot_var.get()}")
            self.root.update_idletasks()
            self._start_impl()
        except Exception:
            tb = traceback.format_exc()
            self._write_error_log(tb)
            self._log_action("启动失败：\n" + tb)
            self._ui_stopped()
            self.status_dot.configure(text="●  启动失败（见 data\\error.log）", fg=BAD)
            self._banner("启动失败：" + tb.strip().splitlines()[-1][:120], "err")
            messagebox.showerror("启动失败", tb[-1500:], parent=self.root)

    def _start_impl(self):
        apk = self.apk_var.get().strip()
        if apk and not os.path.exists(apk):
            messagebox.showerror("找不到文件", f"APK 不存在：\n{apk}")
            return
        try:
            dns_port = int(self.dns_port.get())
            http_port = int(self.http_port.get())
        except ValueError:
            messagebox.showerror("端口错误", "端口必须是数字")
            return

        if not self._port_free(dns_port, udp=True):
            messagebox.showerror("DNS 端口被占用",
                                 f"UDP {dns_port} 已被占用。\n\n"
                                 "常见原因：Docker、Internet 连接共享、安全软件。\n"
                                 "用 netstat -ano | findstr :53 查占用进程。")
            return
        if not self._port_free(http_port, udp=False):
            messagebox.showerror("HTTP 端口被占用",
                                 f"TCP {http_port} 已被占用，换个端口试试。")
            return

        ip = local_ip()
        bind_host = "0.0.0.0"
        auto_discover = False
        only_override = None
        if self.hotspot_var.get():
            from . import hotspot
            info = hotspot.hotspot_info()
            if not info:
                self._banner("没检测到热点网卡：请先在 设置 → 网络和 Internet → 移动热点 打开热点", "err")
                self._ui_stopped()
                messagebox.showerror("没找到热点",
                                     "请先在 Windows 设置 → 网络和 Internet → 移动热点 打开热点，\n"
                                     "等老手机连上后再点启动。",
                                     parent=self.root)
                return
            self._banner(f"热点模式：网关 {info['ip']}（{info['name']}），正在接管 DNS …", "info")
            if not messagebox.askyesno(
                    "热点模式",
                    f"将把上网网卡的 DNS 临时改成 127.0.0.1，\n"
                    f"让热点转发链路上的域名查询都走本程序。\n\n"
                    f"热点网关：{info['ip']}（{info['name']}）\n"
                    f"停止时会自动还原。继续？",
                    parent=self.root):
                self._banner("已取消（你在确认框里点了「否」）", "warn")
                self._ui_stopped()
                return
            ip = info["ip"]
            bind_host = "127.0.0.1"
            auto_discover = True
            only_override = self.only_var.get().strip() or DEFAULT_HOTSPOT_ONLY
            self._pending_hs = info
        stamp = time.strftime("%Y%m%d-%H%M%S")
        log_dir = os.path.join(PROJECT_DIR, "data", "dns")
        os.makedirs(log_dir, exist_ok=True)

        cfg = ServeConfig(
            apk=apk or None,
            root=None,
            fallback=None,
            log_path=os.path.join(log_dir, f"http-{stamp}.jsonl"),
            verbose=False,
            on_event=self.queue.put,
        )
        self.cfg = cfg
        cfg.manual_plain = getattr(self, "manual_plain", "") or ""
        cfg.manual_cipher = getattr(self, "manual_cipher", "") or ""
        cfg.passthrough = bool(self.passthrough_var.get())
        cfg.rewrite = bool(self.rewrite_var.get())
        cfg.upstream_dns = self.upstream_var.get().strip() or "223.5.5.5"
        cfg.load_apk()
        cfg.catalog_dir = os.path.join(PROJECT_DIR, "data", "catalog")
        entry = self._ensure_entry(cfg, ip, http_port)
        cfg.inject = entry if (self.inject_var.get() and entry) else None
        self.http = FakeStore(cfg, port=http_port)
        self.https = None
        https_note = ""
        if self.https_var.get():
            if self._port_free(443, udp=False):
                try:
                    from .capture import CertificateAuthority, start_cert_server
                    ca = CertificateAuthority(os.path.join(PROJECT_DIR, "data", "ca"))
                    self.https = FakeStore(cfg, port=443, ca=ca)
                    threading.Thread(target=self._safe_run,
                                     args=(self.https.run, "HTTPS"), daemon=True).start()
                    start_cert_server(ca, 8898, host="0.0.0.0")
                    https_note = "  ·  HTTPS 已开，证书页 :8898"
                except Exception as e:
                    https_note = f"  ·  HTTPS 未开（{e}）"
            else:
                https_note = "  ·  443 被占用，HTTPS 未开"
        self.dns = DnsServer(
            ip, port=dns_port,
            upstream=self.upstream_var.get().strip() or "223.5.5.5",
            only=[x.strip() for x in (only_override or self.only_var.get()).replace("，", ",").split(",") if x.strip()],
            bind_host=bind_host,
            auto_discover=auto_discover,
            observe=bool(self.observe_var.get()),
            log_path=os.path.join(log_dir, f"dns-{stamp}.jsonl"),
            verbose=False,
            on_event=self.queue.put,
        )

        threading.Thread(target=self._safe_run, args=(self.http.run, "HTTP"), daemon=True).start()
        threading.Thread(target=self._safe_run, args=(self.dns.run, "DNS"), daemon=True).start()

        self.running = True
        try:
            cfg.prewarm()   # 已有会话/手动值的话，启动即开始后台加密
        except Exception:
            pass
        self.btn_start.configure(state="disabled", bg="#9ca3af")
        self.btn_stop.configure(state="normal", bg="#fee2e2")
        self.status_dot.configure(text="●  运行中", fg=OK)
        self.log_label.configure(text=f"日志：data\\dns  ·  {ip}:{dns_port} / {http_port}" + https_note)
        self._draw_flow()
        # CA 证书提醒：换了电脑=换了CA，车机没装新证书 HTTPS 全挂
        if self.https is not None and not getattr(self, "_ca_reminded", False):
            self._ca_reminded = True
            messagebox.showinfo(
                "先确认车机已装 CA 证书",
                f"HTTPS 劫持已开启。车机必须先信任本机的 CA 证书，否则商店打不开：\n\n"
                f"1. 车机浏览器打开  http://{ip}:8898/\n"
                f"2. 下载 ca.crt 并安装（设置→安全→加密与凭据→安装证书）\n"
                f"3. 装好后回商店首页刷新一次\n\n"
                f"注意：每台电脑生成的证书不同。换了电脑就要重新装一次；\n"
                f"同一台电脑证书会复用，装过一次即可。\n"
                f"若日志出现「TLS失败/证书未被信任」，就是证书没装或装错了。")
        self._v("only", self.only_var.get())
        self._v("upstream", self.upstream_var.get())
        self._v("dns_port", str(dns_port))
        self._v("http_port", str(http_port))
        self._v("passthrough", self.passthrough_var.get())
        self._v("rewrite", self.rewrite_var.get())
        self._v("https", self.https_var.get())
        self._v("inject", self.inject_var.get())
        self._save_config()
        self._log_action(f"启动成功 dns={dns_port} http={http_port}")
        where = "热点模式" if self.hotspot_var.get() else "普通模式"
        if self.observe_var.get():
            where += " · 观察模式"
        self._banner(f"已启动（{where}）DNS {ip}:{dns_port} / HTTP 0.0.0.0:{http_port}"
                     + (" / HTTPS 443" if self.https_var.get() else ""), "ok")

        pending = getattr(self, "_pending_hs", None)
        if pending:
            self._pending_hs = None
            if not self._apply_hotspot_dns(pending):
                self.stop()
                return
            self._start_dns_watchdog()
            self._banner("已启动（热点模式）：本机 DNS 已指向 127.0.0.1，"
                         "停止/关窗会自动还原，异常退出下次启动也会还原", "ok")

    def _safe_run(self, fn, name):
        try:
            fn()
        except Exception as e:
            self.queue.put({"kind": "error", "text": f"{name} 启动失败：{e}"})

    def stop(self):
        if getattr(self, "_watch_stop", None):
            self._watch_stop.set()
        self._restore_dns(silent=True)
        if self.dns:
            self.dns.stop()
        if self.http:
            self.http.stop()
        if getattr(self, "https", None):
            self.https.stop()
            self.https = None
        self.running = False
        self.btn_start.configure(state="normal", bg=ACCENT)
        self.btn_stop.configure(state="disabled", bg="#e5e7eb")
        self.status_dot.configure(text="●  已停止", fg=MUTED)
        self._banner("已停止，DNS 已还原（如果有改过）", "info")

    def on_close(self):
        self.stop()
        self.root.destroy()

    # ------------------------------------------------------------ 事件泵
    def _pump(self):
        drained = 0
        while drained < 200:
            try:
                ev = self.queue.get_nowait()
            except queue.Empty:
                break
            drained += 1
            self._consume(ev)
        if self._rows_pending:
            self.tree.yview_moveto(1.0)
            self._rows_pending = 0
        extra = ""
        if self.counts.get("tls_fail"):
            extra = f"  ·  TLS失败 {self.counts['tls_fail']}"
        self.count_label.configure(
            text=f"记录 {self.counts['dns'] + self.counts['http']} 条  ·  "
                 f"域名 {self.counts['dns']}  ·  请求 {self.counts['http']}  ·  "
                 f"换包 {self.counts['apk']}{extra}")
        self._maybe_redraw_flow()
        self._update_enc_progress()
        self.root.after(150, self._pump)

    def _consume(self, ev):
        kind = ev.get("kind")
        if kind == "error":
            self._write_error_log(ev.get("text", ""))
            self._log_action("线程错误：" + ev.get("text", ""))
            self._ui_stopped()
            self.status_dot.configure(text="●  启动失败（见 data\\error.log）", fg=BAD)
            messagebox.showerror("启动失败", ev.get("text", ""), parent=self.root)
            self.stop()
            return
        if kind == "dns":
            self.counts["dns"] += 1
            try:
                from .netcheck import identify_store
                store = identify_store(ev.get("name", ""))
                if store and store not in self._stores_seen:
                    self._stores_seen.add(store)
                    self._net_log(f"[发现商店] {store}  ({ev.get('name')})")
                    self.status_dot.configure(text=f"●  运行中  ·  已识别 {store}", fg=OK)
            except Exception:
                pass
            self._add_row(ev["time"], "DNS", ev["client"], ev["name"], "", ev["action"], "dns")
            self._bump(ev["name"], ev["action"])
        elif kind == "tls_fail":
            self.counts["tls_fail"] = self.counts.get("tls_fail", 0) + 1
            host = ev.get("host") or "（未拿到域名）"
            self._add_row(ev["time"], "TLS失败", ev["client"], host,
                          ev["error"][:60], "证书未被信任", "fail")
            if not self._tls_warned:
                self._tls_warned = True
                self.status_dot.configure(text="●  运行中  ·  HTTPS 被拒绝", fg=BAD)
                self.sum_hint.configure(
                    text=f"HTTPS 握手被拒：车机多半没装本机 CA。车机浏览器开 http://{local_ip()}:8898/ 下载安装；"
                         f"装过旧电脑证书的要先删掉再装新的")
        elif kind == "http":
            self.counts["http"] += 1
            tag = "apk" if ev["action"] == "换成你的APK" else ("miss" if ev["action"] == "没找到" else "")
            if tag == "apk":
                self.counts["apk"] += 1
            self._add_row(ev["time"], "HTTP", ev["client"], ev["host"], ev["path"],
                          f"{ev['action']} {ev['size']}B", tag)
            self._bump(f"{ev['host']}  {ev['path']}", ev["action"])

    def _add_row(self, t, kind, client, host, path, action, tag):
        self.tree.insert("", 0, values=(t, kind, client, host, path, action), tags=(tag,))
        if len(self.tree.get_children()) > MAX_ROWS:
            self.tree.delete(self.tree.get_children()[-1])
        self._rows_pending = 1

    def _bump(self, what, action):
        key = what
        self.summary[key] = self.summary.get(key, 0) + 1
        self._refresh_summary()

    def _refresh_summary(self):
        self.sum_tree.delete(*self.sum_tree.get_children())
        for what, n in sorted(self.summary.items(), key=lambda kv: -kv[1])[:200]:
            self.sum_tree.insert("", "end", values=(what, n))
        self.sum_hint.configure(text=f"共 {len(self.summary)} 个不同地址")

    # ------------------------------------------------------------ 小工具
    @staticmethod
    def _port_free(port, udp=False):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if udp else socket.SOCK_STREAM)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("0.0.0.0", port))
            return True
        except OSError:
            return False
        finally:
            s.close()

    def _fill_help(self):
        ip = local_ip()
        text = f"""先点「自检」页

  「一键自检」会依次检查：
    · 本机 IP、网关、所在网段
    · 53 / 80 / 443 端口有没有被占
    · 几个公共 DNS 哪个最快（会自动填进「上游DNS」）
    · 扫一遍局域网，列出连着的设备

  跑起来之后，手机一访问商店，状态栏会显示「已识别 小米应用商店」之类。

这个窗口在做什么

它把你的电脑变成"那台已经关停的商店服务器"：
  · 手机上的 DNS 指向电脑后，商店以为所有服务器都还在
  · 商店来下载 APK 时，电脑直接把你在第 ① 步选的包发过去
  · 手机装上的就是你给的包，旧版本就变成新版本了

三步走

1. 选好 APK（第 ① 步）
2. 点「启动」，会提示端口能否占用
3. 手机 WiFi 里把 DNS 改成 {ip}

手机设置细节

  WiFi → 长按当前网络 → 修改网络 → 高级选项
  IP 设置：静态
  IP 地址：{ip.rsplit('.', 1)[0]}.200（同网段不冲突即可）
  网关：路由器地址（一般 {'.'.join(ip.split('.')[:3])}.1）
  DNS 1：{ip}
  DNS 2：留空

设置完打开那个应用商店，右边"实时请求"会一条条跳出来。
绿色的行就是它来要 APK —— 那一刻它拿到的已经是你的包。

看不懂某些行？

  DNS 行 = 它在问"这个域名在哪"，电脑统一回答"在我这"
  HTTP 行 = 它来取东西
  「没找到」= 它要的路径这台假服务器上没有（正常，先观察）

如果全是「没找到」

说明它先要一个应用列表，拿到列表才会去下载。把「实时请求」里
那几条被请求的路径发给我，我照着补一个假列表进去。

两个开关怎么用（商店还能打开、只是版本老）

  ☑ 转发到真实服务器
      目录、图片、详情页照常从原服务器取，只有 .apk 走我们这边。
      不勾的话，商店会以为所有接口都挂了，列表都刷不出来。

  ☑ 自动改写 MD5 / 大小
      很多商店下载完会核对 MD5 和文件大小，对不上就提示"安装包损坏"。
      勾上后，转发回来的 JSON 里那串 32 位 MD5 和 size 会换成你 APK 的。
      窗口里出现「转发+改写3处」，说明确实改到了。

  · 商店列表刷不出来 → 先把「转发」勾上
  · 下载完提示校验失败 → 说明校验字段没被命中，把那次响应发我

说明

HTTPS 怎么办

  商店要是走 HTTPS，光改 DNS 会握手失败（证书对不上）。
  默认已经帮你在 443 端口挂了自签证书：

  1. 保持勾选「同时接管 HTTPS」
  2. 手机浏览器打开 http://本机IP:8898/，下载 ca.crt
  3. 设置 → 安全 → 从存储设备安装 → 选 ca.crt
  4. 再打开商店

  安卓 6 及以下：装完立刻生效。

  安卓 7 及以上：系统只对 targetSdkVersion >= 24 的 App 拒绝用户证书。
  这对你反而是好消息——山寨机上的老商店大多是 targetSdk 22/23 编译的，
  装完证书照样能被解出来。看到「换成你的APK」就说明成了。

  只有 targetSdk >= 24 时才会看到红色的「TLS失败」：
    · 先确认证书真的装上了（浏览器打开 https://本机IP:8898 不报错）
    · 还是不行就是这条 App 拒绝用户证书，未 root 无解
    · 有 root 可以用 `AppStoreScan.exe cert` 把证书做成系统证书

说明

  · 端口 53 / 443 需要管理员权限
  · 用完记得把手机 WiFi 改回 DHCP，否则会一直连不上网
"""
        self.help_text.insert("1.0", text)
        self.help_text.configure(state="disabled")

    # ------------------------------------------------------------ 配置持久化
    def _load_config(self):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg = json.load(f)
        except (OSError, json.JSONDecodeError):
            return
        self.apk_var.set(cfg.get("apk", ""))
        self.only_var.set(cfg.get("only", ""))
        self.upstream_var.set(cfg.get("upstream", ""))
        self.dns_port.set(cfg.get("dns_port", "53"))
        self.http_port.set(cfg.get("http_port", "80"))
        if "passthrough" in cfg:
            self.passthrough_var.set(bool(cfg["passthrough"]))
        if "rewrite" in cfg:
            self.rewrite_var.set(bool(cfg["rewrite"]))
        if "https" in cfg:
            self.https_var.set(bool(cfg["https"]))
        if "inject" in cfg:
            self.inject_var.set(bool(cfg["inject"]))
        if self.apk_var.get():
            self._show_apk_info()

    def _v(self, key, value):
        self._config = getattr(self, "_config", {})
        self._config[key] = value

    def _save_config(self):
        cfg = {
            "apk": self.apk_var.get(),
            "only": self.only_var.get(),
            "upstream": self.upstream_var.get(),
            "dns_port": self.dns_port.get(),
            "http_port": self.http_port.get(),
            "passthrough": bool(self.passthrough_var.get()),
            "rewrite": bool(self.rewrite_var.get()),
            "https": bool(self.https_var.get()),
            "inject": bool(self.inject_var.get()),
        }
        try:
            os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except OSError:
            pass


def run_gui():
    hide_console()
    root = tk.Tk()
    App(root)
    root.mainloop()
    return 0
