"""网络自检：本机信息、局域网设备、上游 DNS、端口占用。"""

from __future__ import annotations

import ipaddress
import re
import socket
import subprocess
import threading
import time

# 常见应用商店的域名特征
STORE_SIGNATURES = [
    ("小米应用商店", ("mi.com", "xiaomi", "miui")),
    ("华为应用市场", ("hicloud", "huawei", "appgallery", "dbankcloud")),
    ("OPPO 软件商店", ("oppomobile", "heytap", "oppo")),
    ("vivo 应用商店", ("vivo", "vv.vivo")),
    ("腾讯应用宝", ("myapp", "qq.com", "gtimg", "tencent")),
    ("360 手机助手", ("360.cn", "qihoo", "qhimg")),
    ("百度手机助手", ("baidu", "bdimg")),
    ("豌豆荚", ("wandoujia",)),
    ("Google Play", ("google", "gstatic", "android.com")),
    ("APKPure", ("apkpure",)),
    ("酷安", ("coolapk",)),
]

DNS_CANDIDATES = ["223.5.5.5", "119.29.29.29", "114.114.114.114", "1.1.1.1", "8.8.8.8"]


def run(cmd, timeout=6):
    """跑一条命令，返回解码后的输出（兼容中文系统的 GBK）。"""
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    for enc in ("utf-8", "gbk", "latin-1"):
        try:
            return p.stdout.decode(enc)
        except UnicodeDecodeError:
            continue
    return p.stdout.decode("utf-8", "replace")


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"


def gateway():
    out = run(["ipconfig"])
    for line in out.splitlines():
        if "默认网关" in line or "Default Gateway" in line:
            m = re.search(r"(\d{1,3}(?:\.\d{1,3}){3})", line)
            if m:
                return m.group(1)
    return ""


def arp_table():
    """解析 arp -a，返回 {ip: mac}。"""
    table = {}
    out = run(["arp", "-a"])
    for line in out.splitlines():
        m = re.search(r"(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F-]{17})", line)
        if m:
            table[m.group(1)] = m.group(2).lower()
    return table


def ping(ip, timeout_ms=250):
    r = subprocess.run(["ping", "-n", "1", "-w", str(timeout_ms), ip],
                       capture_output=True)
    return r.returncode == 0


def scan_lan(network=None, limit=254, workers=48):
    """并发 ping 扫一遍网段，返回 [{ip, mac, vendor}]。"""
    network = network or local_ip()
    try:
        base = ipaddress.ip_network(network + "/24", strict=False)
    except ValueError:
        return []

    hosts = [str(h) for h in base.hosts()][:limit]
    alive = []
    lock = threading.Lock()

    def probe(ip):
        if ping(ip):
            with lock:
                alive.append(ip)

    threads = []
    for ip in hosts:
        t = threading.Thread(target=probe, args=(ip,), daemon=True)
        t.start()
        threads.append(t)
        if len(threads) >= workers:
            for x in threads:
                x.join()
            threads = []
    for x in threads:
        x.join()

    arp = arp_table()
    devices = []
    for ip in sorted(alive, key=lambda x: tuple(int(p) for p in x.split("."))):
        mac = arp.get(ip, "")
        devices.append({"ip": ip, "mac": mac, "vendor": mac_vendor(mac)})
    return devices


def _load_oui():
    """内置一小批常见厂商前缀，够用来判断"是不是手机"。"""
    return {
        "f0:18:98": "苹果", "ac:bc:32": "苹果", "d8:1d:72": "苹果",
        "64:09:80": "小米", "8c:be:be": "小米", "f8:a4:5f": "小米",
        "34:12:98": "华为", "00:e0:fc": "华为", "48:db:50": "华为",
        "2c:5d:93": "OPPO", "3c:1e:04": "vivo", "bc:44:86": "vivo",
        "00:12:fb": "三星", "5c:0a:5b": "三星",
        "1c:bd:b9": "D-Link", "00:1d:0f": "TP-Link",
    }


OUI = _load_oui()


def mac_vendor(mac):
    if not mac:
        return ""
    key = mac.replace("-", ":")[:8].lower()
    return OUI.get(key, "")


def check_dns(servers=None, timeout=2.0):
    """对每个候选 DNS 发一次 A 查询，返回 [{server, ok, ms}]。"""
    servers = servers or DNS_CANDIDATES
    results = []

    def probe(server):
        pkt = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00"
        for part in "www.baidu.com".split("."):
            pkt += bytes([len(part)]) + part.encode()
        pkt += b"\x00\x00\x01\x00\x01"
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        start = time.time()
        try:
            s.sendto(pkt, (server, 53))
            data, _ = s.recvfrom(1024)
            ms = int((time.time() - start) * 1000)
            ok = len(data) > 12 and data[3] & 0x0F == 0
        except OSError:
            ok, ms = False, None
        finally:
            s.close()
        results.append({"server": server, "ok": ok, "ms": ms})

    threads = [threading.Thread(target=probe, args=(s,), daemon=True) for s in servers]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    results.sort(key=lambda r: (not r["ok"], r["ms"] if r["ms"] is not None else 9999))
    return results


def check_port(port, udp=False):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if udp else socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def identify_store(domain):
    """根据域名猜是哪家的商店。"""
    d = (domain or "").lower()
    for name, keys in STORE_SIGNATURES:
        if any(k in d for k in keys):
            return name
    return ""
