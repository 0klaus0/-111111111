"""HTTP 客户端：带重试、限速、代理和编码识别。

只依赖 Python 标准库，方便在没有 pip 的电脑上直接运行。
"""

from __future__ import annotations

import gzip
import json
import random
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


class HttpError(RuntimeError):
    """请求在重试之后仍然失败。"""

    def __init__(self, msg, url="", status=None):
        super().__init__(msg)
        self.url = url
        self.status = status


class Response:
    def __init__(self, url, status, headers, content):
        self.url = url
        self.status = status
        self.headers = {k.lower(): v for k, v in headers.items()}
        self.content = content

    @property
    def content_type(self):
        return self.headers.get("content-type", "")

    def text(self):
        return decode_bytes(self.content, self.headers.get("content-type", ""))

    def json(self):
        return json.loads(self.text())


_CHARSET_RE = re.compile(rb"""charset\s*=\s*["']?\s*([A-Za-z0-9_\-]+)""", re.I)


def decode_bytes(raw: bytes, content_type: str = "") -> str:
    """按 header → BOM → meta → utf-8 → gb18030 的顺序猜编码。"""
    candidates = []
    m = _CHARSET_RE.search(content_type.encode("latin-1", "ignore"))
    if m:
        candidates.append(m.group(1).decode("ascii", "ignore"))
    head = raw[:4096]
    m = re.search(rb"""<meta[^>]+charset\s*=\s*["']?([A-Za-z0-9_\-]+)""", head, re.I)
    if m:
        candidates.append(m.group(1).decode("ascii", "ignore"))
    if raw.startswith(b"\xef\xbb\xbf"):
        candidates.insert(0, "utf-8-sig")
    candidates += ["utf-8", "gb18030", "latin-1"]

    for enc in candidates:
        enc = enc.strip().lower()
        if enc in ("gb2312", "gbk"):
            enc = "gb18030"
        try:
            return raw.decode(enc)
        except (LookupError, UnicodeDecodeError):
            continue
    return raw.decode("utf-8", "replace")


class HttpClient:
    def __init__(self, proxy=None, timeout=25, retries=3, delay=0.6,
                 insecure=False, user_agent=DEFAULT_UA):
        self.timeout = timeout
        self.retries = max(0, retries)
        self.delay = max(0.0, delay)
        self.user_agent = user_agent
        self._last_request = 0.0

        handlers = []
        if proxy:
            handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
        if insecure:
            ctx = ssl._create_unverified_context()
        else:
            ctx = ssl.create_default_context()
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
        self._opener = urllib.request.build_opener(*handlers)

    # -- 节流 -------------------------------------------------------------
    def _throttle(self):
        if self.delay <= 0:
            return
        wait = self._last_request + self.delay - time.monotonic()
        if wait > 0:
            time.sleep(wait)
        self._last_request = time.monotonic()

    # -- 请求 -------------------------------------------------------------
    def get(self, url, params=None, headers=None, accept="*/*"):
        if params:
            sep = "&" if urllib.parse.urlparse(url).query else "?"
            url = url + sep + urllib.parse.urlencode(params, doseq=True)

        hdrs = {
            "User-Agent": self.user_agent,
            "Accept": accept,
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "close",
        }
        if headers:
            hdrs.update(headers)

        last_err = None
        for attempt in range(self.retries + 1):
            self._throttle()
            try:
                req = urllib.request.Request(url, headers=hdrs)
                with self._opener.open(req, timeout=self.timeout) as resp:
                    body = resp.read()
                    body = _maybe_decompress(body, resp.headers.get("Content-Encoding", ""))
                    return Response(resp.geturl(), resp.status, dict(resp.headers), body)
            except urllib.error.HTTPError as e:
                body = b""
                try:
                    body = e.read()
                except Exception:
                    pass
                last_err = HttpError(f"HTTP {e.code} {e.reason}", url, e.code)
                # 4xx（除 429）重试没有意义
                if e.code < 500 and e.code != 429 and e.code != 403:
                    raise last_err
                retry_after = _retry_after(e.headers)
                self._backoff(attempt, retry_after)
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                last_err = HttpError(f"网络错误: {e}", url)
                self._backoff(attempt, None)
        raise last_err or HttpError("未知错误", url)

    def _backoff(self, attempt, retry_after):
        if attempt >= self.retries:
            return
        base = retry_after if retry_after else min(30.0, 1.5 ** attempt)
        time.sleep(base + random.uniform(0, 0.4))


def _retry_after(headers):
    try:
        val = headers.get("Retry-After")
        return min(60.0, float(val)) if val else None
    except (TypeError, ValueError):
        return None


def _maybe_decompress(body: bytes, encoding: str) -> bytes:
    encoding = (encoding or "").lower()
    if "gzip" in encoding:
        try:
            return gzip.decompress(body)
        except OSError:
            return body
    if "deflate" in encoding:
        try:
            return zlib.decompress(body)
        except zlib.error:
            try:
                return zlib.decompress(body, -zlib.MAX_WBITS)
            except zlib.error:
                return body
    return body
