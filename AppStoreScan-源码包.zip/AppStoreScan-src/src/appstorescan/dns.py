"""DNS 劫持 + 假下载站 + 转发改写。

三种工作方式：
1. 直接替换：任意 .apk 请求返回本地 APK（商店不校验时最简单）
2. 转发：其它请求原样转发给真实服务器（目录、图片都正常）
3. 改写：转发回来的 JSON 里，把 MD5 / 大小改成你那个 APK 的，避免校验不过

明文 HTTP 场景下不需要证书。
"""

from __future__ import annotations

import gzip
import hashlib
import http.client
import ipaddress
import json
import os
import re
import socket
import ssl
import struct
import threading
import time
import zlib
from fnmatch import fnmatch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

QTYPE = {1: "A", 28: "AAAA", 5: "CNAME", 65: "HTTPS", 16: "TXT", 12: "PTR"}
HOP_HEADERS = {"connection", "keep-alive", "proxy-connection", "transfer-encoding", "content-length"}


# --------------------------------------------------------------------------
# DNS
# --------------------------------------------------------------------------
class DnsServer:
    def __init__(self, answer_ip, port=53, upstream=None, only=None,
                 log_path=None, verbose=True, ttl=60, on_event=None,
                 bind_host="0.0.0.0", auto_discover=False, observe=False):
        self.answer_ip = answer_ip
        self.port = port
        self.upstream = upstream
        self.only = [p.lower() for p in (only or [])]
        self.log_path = log_path
        self.verbose = verbose
        self.ttl = ttl
        self.on_event = on_event
        self.bind_host = bind_host
        self.auto_discover = auto_discover
        self.observe = observe
        self._stop = threading.Event()
        self._sock = None
        self._lock = threading.Lock()
        if log_path:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)

    def run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((self.bind_host, self.port))
        sock.settimeout(0.5)
        self._sock = sock
        mode = "全部域名" if not self.only else "匹配 " + ", ".join(self.only)
        print(f"[DNS] 监听 {self.bind_host}:{self.port}，劫持范围：{mode}，统一解析到 {self.answer_ip}", flush=True)
        while not self._stop.is_set():
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle, args=(sock, data, addr), daemon=True).start()

    def stop(self):
        self._stop.set()
        try:
            if self._sock:
                self._sock.close()
        except OSError:
            pass

    def _handle(self, sock, data, addr):
        try:
            parsed = parse_question(data)
        except Exception:
            return
        if not parsed:
            return
        qid, flags, qname, qtype, qclass, question_raw = parsed

        if not self.observe and (self._match(qname) or self._discover(qname)):
            resp = build_answer(qid, flags, question_raw, qname, qtype, qclass,
                                self.answer_ip, self.ttl)
            try:
                sock.sendto(resp, addr)
            except OSError:
                return
            self._log(addr, qname, qtype, "劫持", self.answer_ip)
            return

        if self.upstream:
            resp = self._forward(data)
            if resp:
                try:
                    sock.sendto(resp, addr)
                except OSError:
                    return
            self._log(addr, qname, qtype, "放行", self.upstream)

    def _discover(self, qname):
        """热点模式下自动认出商店域名：命中厂商特征就永久接管这个主域。"""
        if not self.auto_discover:
            return False
        try:
            from .netcheck import identify_store
        except Exception:
            return False
        if not identify_store(qname):
            return False
        parts = qname.lower().rstrip(".").split(".")
        if len(parts) < 2:
            return False
        pattern = "*" + ".".join(parts[-2:])
        if pattern in self.only:
            return True
        self.only.append(pattern)
        if self.verbose:
            print(f"[DNS] 自动识别商店域名，接管 {pattern}", flush=True)
        if self.on_event:
            try:
                self.on_event({"kind": "discover", "name": qname, "pattern": pattern})
            except Exception:
                pass
        return True

    def _match(self, qname):
        if not self.only:
            return True
        name = qname.lower().rstrip(".")
        return any(fnmatch(name, pat) or name == pat for pat in self.only)

    def _forward(self, data):
        try:
            up = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            up.settimeout(4)
            up.sendto(data, (self.upstream, 53))
            resp, _ = up.recvfrom(4096)
            up.close()
            return resp
        except OSError:
            return None

    def _log(self, addr, qname, qtype, action, answer):
        entry = {"kind": "dns", "ts": time.time(), "time": time.strftime("%H:%M:%S"),
                 "client": addr[0], "name": qname, "qtype": QTYPE.get(qtype, str(qtype)),
                 "action": action, "answer": answer}
        if self.verbose:
            print(f"[DNS] {addr[0]:<15} {qname:<45} -> {action}", flush=True)
        if self.on_event:
            try:
                self.on_event(entry)
            except Exception:
                pass
        if not self.log_path:
            return
        with self._lock:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def parse_question(data):
    if len(data) < 12:
        return None
    qid, flags, qdcount = struct.unpack("!HHH", data[:6])
    if qdcount < 1:
        return None
    offset = 12
    labels = []
    while offset < len(data):
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0:
            offset += 2
            break
        labels.append(data[offset + 1: offset + 1 + length].decode("latin-1"))
        offset += 1 + length
    qtype, qclass = struct.unpack("!HH", data[offset: offset + 4])
    return qid, flags, ".".join(labels), qtype, qclass, data[12: offset + 4]


def build_answer(qid, flags, question_raw, qname, qtype, qclass, ip, ttl=60):
    resp_flags = 0x8000 | (flags & 0x0100) | 0x0080
    if qtype == 1 and ip:
        addr = ipaddress.ip_address(ip).packed
        answer = b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, ttl, len(addr)) + addr
        header = struct.pack("!HHHHHH", qid, resp_flags, 1, 1, 0, 0)
        return header + question_raw + answer
    header = struct.pack("!HHHHHH", qid, resp_flags, 1, 0, 0, 0)
    return header + question_raw


def resolve_real_ip(host, upstream, timeout=3.0):
    """绕过本机劫持，直接向上游 DNS 问真实 IP。"""
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass

    pkt = struct.pack("!HHHHHH", 0xBEEF, 0x0100, 1, 0, 0, 0)
    for part in host.split("."):
        pkt += bytes([len(part)]) + part.encode("latin-1")
    pkt += b"\x00" + struct.pack("!HH", 1, 1)

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(pkt, (upstream, 53))
        data, _ = s.recvfrom(2048)
    finally:
        s.close()

    ancount = struct.unpack("!H", data[6:8])[0]
    if ancount == 0:
        return None
    return ".".join(str(b) for b in data[-4:])


# --------------------------------------------------------------------------
# HTTP 假下载站 / 转发
# --------------------------------------------------------------------------
class ServeConfig:
    def __init__(self, apk=None, root=None, fallback=None, log_path=None,
                 fallback_type="application/json; charset=utf-8",
                 verbose=True, on_event=None):
        self.apk = apk
        self.root = os.path.abspath(root) if root else None
        self.fallback = fallback
        self.fallback_type = fallback_type
        self.log_path = log_path
        self.verbose = verbose
        self.on_event = on_event

        # 转发与改写
        self.passthrough = False
        self.upstream_dns = "223.5.5.5"
        self.rewrite = True
        self.apk_md5 = ""
        self.apk_size = 0
        self.apk_bytes = b""
        self.version_name = ""
        self.version_code = None
        self.resolve_map = {}          # 测试用：host -> (ip, port)
        self.inject = None             # 要注入商店列表的应用条目
        self.catalog_dir = None        # 把目录响应存一份，便于照着改条目
        self.no_cache = True            # 强制客户端不吃缓存，便于"刷新列表"
        self.refresh_token = 0          # 每点一次刷新 +1，写进响应头
        self.apps = []                  # 要广播的应用（可多个）
        self.apk_map = {}               # 包名(小写) -> AppItem
        self.default_pkg = None         # 路径里认不出包名时给哪个
        self.ip = ""                    # 热点 IP（下载直连地址 / 默认 TLS 证书）
        self.last_cipher = ""           # 最近一次 sdkInit 返回的会话密钥材料
        self.last_plain = ""            # sdkInit 的 plainText（=设备号 x-device）
        self.manual_plain = ""          # 手动填写的设备号（优先于自动捕获）
        self.manual_cipher = ""         # 手动填写的 sdkInit cipher（优先于自动捕获）
        self._enc_cache = None          # 本地 DES 加密缓存
        self.enc_state = {}             # 加密进度：{package, done, total, ts, error, mode}
        self._pw_thread = None          # 预加密线程
        self._pw_guard = threading.Lock()

    @property
    def eff_plain(self):
        """生效设备号：手动填写优先，否则用最近捕获的。"""
        return self.manual_plain or self.last_plain

    @property
    def eff_cipher(self):
        """生效 cipher：手动填写优先，否则用最近捕获的。"""
        return self.manual_cipher or self.last_cipher

    def enc_cache(self):
        if self._enc_cache is None:
            from .storecrypto import EncCache
            base = os.path.dirname(self.catalog_dir or ".") or "."
            self._enc_cache = EncCache(os.path.join(base, "enc_cache"))
        return self._enc_cache

    # ---------------- 加密进度 / 预加密 ----------------
    def enc_progress(self, package, done, total, error=""):
        """把当前加密进度写进共享状态，界面 150ms 轮询一次即可。
        命令行/热点模式（progress_echo=True）同时限速打印到 stdout，
        StoreCast 的日志窗口 tail 这个输出就能看到实时进度。"""
        now = time.time()
        self.enc_state = {"package": package, "done": done, "total": total,
                          "ts": now, "error": error}
        if not getattr(self, "progress_echo", False) or not total:
            return
        last = getattr(self, "_pecho_ts", 0.0)
        finished = done >= total
        if not error and not finished and now - last < 1.0:
            return
        self._pecho_ts = now
        if error:
            print(f"[加密] {package} 失败：{error}", flush=True)
        elif finished:
            print(f"[加密] {package} 完成 100%（{total / 1048576:.1f} MB），车机可直接下载", flush=True)
        else:
            pct = done * 100.0 / total
            print(f"[加密] {package} {pct:.0f}%  {done / 1048576:.1f}/{total / 1048576:.1f} MB", flush=True)

    def prewarm(self):
        """拿到 sdkInit 后，后台先把所有待广播 APK 加密好；
        这样车机点下载时几乎立刻开始传数据，不用对着 0% 干等。"""
        mode = self.store_mode()
        if not mode.startswith("des-"):
            return
        if not self.eff_cipher or not self.eff_plain or not self.apps:
            return
        with self._pw_guard:
            if self._pw_thread is not None and self._pw_thread.is_alive():
                return
            self._pw_thread = threading.Thread(target=self._pw_run, args=(mode[4:],), daemon=True)
            self._pw_thread.start()

    def _pw_run(self, variant):
        cipher, plain = self.eff_cipher, self.eff_plain
        try:
            for item in list(self.apps):
                # 中途会话变了（换了车/手动改了值）就放弃，下次再预加密
                if (self.eff_cipher, self.eff_plain) != (cipher, plain):
                    return
                try:
                    self.enc_cache().get(
                        item, cipher, plain, variant,
                        progress=lambda d, t, p=item.package: self.enc_progress(p, d, t))
                except Exception as e:
                    print(f"[预加密失败] {item.package} {e}", flush=True)
                    self.enc_progress(item.package, 0, item.size, f"加密失败：{e}")
                    return
            # 保持最后的 100% 状态，让界面能显示「密文已就绪」再自行收起
        finally:
            with self._pw_guard:
                self._pw_thread = None

    def store_mode(self):
        """读 detail_variant.txt：null/omit/empty 或 des-<派生方式>。
        依次找：APK目录上级(工程根/exe旁) → data目录 → 当前目录。"""
        cands = []
        if self.apk:
            cands.append(os.path.join(os.path.dirname(os.path.abspath(self.apk)), "detail_variant.txt"))
        if self.catalog_dir:
            cands.append(os.path.join(os.path.dirname(self.catalog_dir), "detail_variant.txt"))
        cands.append(os.path.join(os.getcwd(), "detail_variant.txt"))
        for vf in cands:
            try:
                if os.path.exists(vf):
                    return open(vf, encoding="utf-8").read().strip().lower() or "null"
            except Exception:
                pass
        return "des-p8"   # 默认本地 DES 加密（设备号前8字节派生）；可用文件覆盖

    def load_apk(self):
        """apk 可以是单个文件，也可以是装着一堆 APK 的目录（多包广播）。"""
        from .library import ApkError, inspect_apk, scan_dir

        self.apps = []
        self.apk_map = {}
        self.default_pkg = None
        if not self.apk:
            return self.apk_bytes
        if not os.path.exists(self.apk):
            return self.apk_bytes

        if os.path.isdir(self.apk):
            items, errors = scan_dir(self.apk)
            self.apps = items
            for e in errors:
                print(f"[APK] 跳过 {e}", flush=True)
        else:
            try:
                self.apps = [inspect_apk(self.apk)]
            except ApkError as e:
                print(f"[APK] 解析失败：{e}", flush=True)
                self.apps = []

        for item in self.apps:
            self.apk_map[item.package.lower()] = item
        if self.apps:
            first = self.apps[0]
            self.default_pkg = first.package
            self.apk_md5 = first.md5
            self.apk_size = first.size
            self.version_name = first.version_name
            self.version_code = first.version_code
            # 单包时保持老行为：内存里留一份，任何 .apk 请求都能给
            if not os.path.isdir(self.apk):
                with open(self.apk, "rb") as f:
                    self.apk_bytes = f.read()
        return self.apk_bytes

    def entries(self, server_ip, http_port):
        """给每个应用生成一条上架条目。"""
        return [a.entry(server_ip, http_port) for a in self.apps]

    def match_apk(self, path):
        """按 URL 里的包名找对应的 APK；找不到就用默认那个。"""
        if not self.apk_map:
            return None
        name = unquote(path).rstrip("/").rsplit("/", 1)[-1].lower()
        if name.endswith(".apk"):
            name = name[:-4]
        if name in self.apk_map:
            return self.apk_map[name]
        lowered = path.lower()
        for pkg, item in self.apk_map.items():
            if pkg in lowered:
                return item
        return self.apk_map.get((self.default_pkg or "").lower())


class StoreHTTPHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    server_version = "AppStoreHTTP/1.0"

    def log_message(self, fmt, *args):
        pass

    def do_HEAD(self):
        self._handle(head=True)

    def do_GET(self):
        self._handle(head=False)

    def do_POST(self):
        self._handle(head=False, body=self._read_body())

    # -- 核心 -------------------------------------------------------------
    def _handle(self, head=False, body=b""):
        cfg = self.server.cfg
        parsed = urlparse(self.path)
        path = unquote(parsed.path) or "/"
        query = parsed.query
        full_path = path + ("?" + query if query else "")
        host = self.headers.get("Host", "")
        ua = self.headers.get("User-Agent", "")
        scheme = "https" if isinstance(self.connection, ssl.SSLSocket) else "http"

        if path.lower().endswith(".apk") and (cfg.apk_map or cfg.apk_bytes):
            self._serve_apk(path, head, host, full_path, ua, scheme, body)
            return

        if cfg.passthrough:
            fake = self._fake_store(host, path, body)
            if fake is not None:
                fdata, ftype, faction = fake
                self._send(fdata, ftype, head, status=200)
                self._log(host, full_path, ua, faction, len(fdata or b""), body, scheme)
                return
            self._passthrough(host, full_path, head, body, ua, scheme)
            return

        action, data, ctype = self._static(path)
        status = 404 if action == "没找到" else 200
        self._send(data, ctype, head, status=status)
        self._log(host, full_path, ua, action, len(data or b""), body, scheme)

    def _fake_store(self, host, path, body):
        """商店 API 的本地接管：只针对我们自己广播的包，其它请求照常转发。

        真服务器不认识我们的包，downloadDetail / getSoftDetail 会返回错误，
        车机就报“下载失败”。这里直接给出本地 APK 地址，车机就能装上。
        """
        cfg = self.server.cfg
        apps = getattr(cfg, "apps", None) or []
        if not apps:
            return None
        api = "/23mmhi/appstore/agent/sota/api/"
        cmt = "/23mmhi/appstore/api/comment/"
        if not (path.startswith(api) or path.startswith(cmt)):
            return None
        try:
            req = json.loads(body) if body else {}
        except Exception:
            req = {}
        if not isinstance(req, dict):
            req = {}
        by_pkg = {a.package.lower(): a for a in apps}
        by_id = {}
        from .inject import _stable_id
        for a in apps:
            try:
                by_id[str(100000 + (int(a.md5[:6], 16) if a.md5 else 0) % 800000)] = a
            except ValueError:
                pass
            by_id[str(_stable_id(a.package))] = a
        pkg = str(req.get("packageName") or "").strip().lower()
        soft_id = str(req.get("softId") or req.get("appId") or "").strip().lower()
        app = by_pkg.get(pkg) or by_pkg.get(soft_id) or by_id.get(soft_id)
        name = path.rsplit("/", 1)[-1].rstrip("/")
        if name not in ("downloadDetail", "getSoftDetail", "comment/list", "hasCommented",
                        "putComment", "report", "downloadUrl"):
            return None
        if app is None:
            return None

        def reply(data=None, code=200, msg="成功"):
            return {"code": code, "msg": msg, "message": msg, "data": data}

        def out(obj, action):
            return (json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                    "application/json;charset=UTF-8", action)

        item = {
            "id": next((k for k, v in by_id.items() if v is app), app.package),
            "name": app.label or app.package,
            "packageName": app.package,
            "description": "本地广播应用",
            "iconPath": "",
            "softVersion": app.version_code,
            "version": app.version_code,
            "versionNo": app.version_code,
            "versionName": app.version_name,
            "size": str(app.size),
            "salableMark": 2,
            "currentPrice": None,
            "originalPrice": None,
            "payUrl": None,
            "thirdPartyMark": 0,
        }

        if name == "downloadDetail":
            if str(req.get("versionNo")) != str(app.version_code) or str(req.get("type") or "1") != "1":
                return out(reply(None, 409, "版本或类型不匹配，请刷新目录"), "本地:版本不匹配")
            # 实机验证成功：DES 加密 + 热点 IP 直连下发，车机可解密并安装。
            server_ip = getattr(cfg, "ip", "") or host
            detail = {
                "forceUpgrade": 0,
                "packageName": app.package,
                "versionNo": app.version_code,
                "versionName": app.version_name,
                "description": "本地广播应用",
                "type": 1,
                "category": "local",
                "size": app.size,
                "filePath": f"https://{server_ip}/__local_apk/{app.package}.apk?store_lab=1",
                "md5": app.md5,
            }
            # 变体开关：detail_variant.txt = null/omit/empty 或 des-<派生方式>
            variant = cfg.store_mode()
            if variant.startswith("des-"):
                # 本地 DES 加密：复用真实 sdkInit cipher 当 encryptKey/encryptPos，
                # size/md5 仍报明文值（与真服务器一致）。加密在 _serve_apk 里做。
                cipher = cfg.eff_cipher
                detail["encryptKey"] = cipher or None
                detail["encryptPos"] = cipher or None
                return out(reply(detail),
                           f"本地:下载详情 {app.package} DES/{variant[4:]} cipher={'有' if cipher else '无'}")
            if variant == "omit":
                pass  # 完全不带 encryptKey/encryptPos
            elif variant == "empty":
                detail["encryptKey"] = ""
                detail["encryptPos"] = ""
            else:
                detail["encryptKey"] = None
                detail["encryptPos"] = None
            return out(reply(detail), f"本地:下载详情 {app.package} 变体={variant}")

        if name == "getSoftDetail":
            detail = dict(item)
            detail.update({"imagePath": "", "imagePathList": [], "developer": "本地应用",
                           "provider": "本地应用", "briefDesc": "本地应用", "updateDesc": "",
                           "score": "", "type": "1", "recordNumber": "", "oemMark": "0"})
            return out(reply(detail), f"本地:详情 {app.package}")

        if name == "comment/list":
            return out(reply({"list": []}), "本地:评论空")
        if name == "hasCommented":
            return out(reply({"done": 0}), "本地:未评论")
        if name == "putComment":
            return out(reply(None, 403, "本地应用不支持评论"), "本地:禁止评论")
        if name == "report":
            st = req.get("status")
            rm = str(req.get("remark") or "")[:60]
            return out(reply(), f"本地:安装上报 status={st} {rm}")
        return None

    def _serve_apk(self, path, head, host, full_path, ua, scheme, body):
        cfg = self.server.cfg
        item = cfg.match_apk(path)
        if item is None:
            data = cfg.apk_bytes
            self._send(data, "application/vnd.android.package-archive", head)
            self._log(host, full_path, ua, "换成你的APK", len(data), body, scheme)
            return
        mode = cfg.store_mode()
        if mode.startswith("des-"):
            # 与 1.6.0 成功版一致：还没拿到 sdkInit（设备号+cipher）时**照样发明文**，
            # 并打日志提示。绝不 503 拒绝——拒绝会让车机商店直接报"下载失败/无网络"。
            if not cfg.eff_cipher or not cfg.eff_plain:
                print(f"[加密] 暂无 sdkInit cipher，先发明文 {item.package}", flush=True)
                self._log(host, full_path, ua, "无sdkInit·明文下发", item.size, body, scheme)
                self._stream_path(item.path, item.size, item.package, head, host,
                                  full_path, ua, scheme, body, tag=f"明文下发 {item.package}")
                return
            try:
                enc_path = cfg.enc_cache().get(
                    item, cfg.eff_cipher, cfg.eff_plain, mode[4:],
                    progress=lambda d, t: cfg.enc_progress(item.package, d, t))
            except Exception as e:
                print(f"[加密失败] {item.package} {e}", flush=True)
                cfg.enc_progress(item.package, 0, item.size, str(e))
                enc_path = None
            if enc_path:
                esize = os.path.getsize(enc_path)
                self._stream_path(enc_path, esize, item.package, head, host,
                                  full_path, ua, scheme, body, tag=f"DES下发 {item.package}")
                return
            # 加密本身出错时也退回明文（同 1.6.0：宁可发出去，也不给车机一个 500）
            self._log(host, full_path, ua, "加密失败·明文兜底", item.size, body, scheme)
            self._stream_path(item.path, item.size, item.package, head, host,
                              full_path, ua, scheme, body, tag=f"明文兜底 {item.package}")
            return
        self._stream_path(item.path, item.size, item.package, head, host,
                          full_path, ua, scheme, body, tag=f"下发 {item.package}")

    def _stream_path(self, filepath, size, package, head, host, full_path, ua, scheme, body, tag="下发"):
        """按 Range 分块下发文件（明文或密文）——几百 MB 必须支持断点续传。"""
        cfg = self.server.cfg
        start, end, partial = 0, size - 1, False
        rng = self.headers.get("Range", "")
        m = re.match(r"bytes=(\d*)-(\d*)", rng.strip()) if rng else None
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else size - 1
            else:
                start = max(0, size - int(m.group(2)))
            start = min(start, size - 1)
            end = min(end, size - 1)
            partial = True
        length = max(0, end - start + 1)

        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", "application/vnd.android.package-archive")
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        if getattr(cfg, "no_cache", True):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
        self.send_header("X-AppStore-Apk", package)
        self.end_headers()

        if head or length <= 0:
            self._log(host, full_path, ua, tag, 0, body, scheme)
            return

        sent = 0
        try:
            with open(filepath, "rb") as f:
                f.seek(start)
                remain = length
                while remain > 0:
                    chunk = f.read(min(262144, remain))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remain -= len(chunk)
                    sent += len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        self._log(host, full_path, ua, tag, sent, body, scheme)

    def _passthrough(self, host, full_path, head, body, ua, scheme="http"):
        cfg = self.server.cfg
        target = cfg.resolve_map.get(host)
        if target:
            ip, port = target[0], target[1]
            scheme = target[2] if len(target) > 2 else scheme
        else:
            ip = resolve_real_ip(host, cfg.upstream_dns)
            port = 443 if scheme == "https" else 80
        if not ip:
            self._send(b"cannot resolve", "text/plain", head, status=502)
            self._log(host, full_path, ua, "解析失败", 0, body, scheme)
            return

        headers = {}
        for k, v in self.headers.items():
            if k.lower() in HOP_HEADERS or k.lower() == "host":
                continue
            headers[k] = v
        headers["Host"] = host.split(":")[0]

        # 记录车机商店请求的完整头，便于在电脑上复刻请求
        if "appstore/agent/sota" in full_path:
            try:
                hd = " | ".join(f"{k}:{v}" for k, v in self.headers.items())
                print(f"[车机头] {full_path.split('?')[0]} :: {hd}", flush=True)
            except Exception:
                pass
        # 捕获 sdkInit 的 plainText（设备号），本地 DES 派生密钥要用
        if full_path.split("?")[0].endswith("sdkInit"):
            try:
                cfg.last_plain = self.headers.get("x-device") or self.headers.get("x-cid") or ""
                if body:
                    pb = json.loads(body)
                    if pb.get("plainText"):
                        cfg.last_plain = pb["plainText"]
                print(f"[会话] plainText={cfg.last_plain}", flush=True)
            except Exception:
                pass

        try:
            if scheme == "https":
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                conn = http.client.HTTPSConnection(ip, port, timeout=15, context=ctx)
            else:
                conn = http.client.HTTPConnection(ip, port, timeout=12)
            conn.request(self.command, full_path, body=body or None, headers=headers)
            resp = conn.getresponse()
            data = resp.read()
            status = resp.status
            rheaders = resp.getheaders()
            conn.close()
            # 调试用：把上游返回的头几行打出来，方便判断到底成功没有
            try:
                hdump = " | ".join(f"{k}:{v}" for k, v in rheaders)
                hx = data[:12].hex()
                preview = data[:300].decode("utf-8", "replace").replace("\r", " ").replace("\n", " ")
                print(f"[上游] {host}{full_path} {status} [{hdump}] hex={hx} {preview}", flush=True)
            except Exception:
                pass
        except Exception as e:
            self._send(b"upstream error", "text/plain", head, status=502)
            self._log(host, full_path, ua, f"转发失败 {e}", 0, body, scheme)
            return

        action = "转发"
        hmap = dict((k.lower(), v) for k, v in rheaders)
        ctype = hmap.get("content-type", "application/octet-stream")
        enc = (hmap.get("content-encoding") or "").lower()
        decoded = False
        if data and enc:
            try:
                if "gzip" in enc:
                    data = gzip.decompress(data)
                    decoded = True
                elif "deflate" in enc:
                    try:
                        data = zlib.decompress(data)
                    except zlib.error:
                        data = zlib.decompress(data, -zlib.MAX_WBITS)
                    decoded = True
            except Exception as e:
                print(f"[解压失败] {host}{full_path} {enc} {e}", flush=True)
                decoded = False
        if "json" in ctype and data:
            data2, note = self._process_json(data, cfg, host, full_path)
            if note:
                action = "转发+" + note
            if data2 != data:
                data = data2
                decoded = True
            # 车机点真实应用时，电脑顺便把服务器那份（加密）APK 也下载下来
            if full_path.split("?")[0].endswith("downloadDetail"):
                try:
                    obj = json.loads(data)
                    d = obj.get("data") or {}
                    pkg = (d.get("packageName") or "").lower()
                    if d.get("filePath") and pkg and pkg not in cfg.apk_map:
                        threading.Thread(target=self._grab_server_apk,
                                         args=(cfg, d), daemon=True).start()
                except Exception:
                    pass

        self._send(data, ctype, head, status=status)
        self._log(host, full_path, ua, action, len(data), body, scheme)

    def _grab_server_apk(self, cfg, d):
        """把真实服务器下发的（加密）APK 下载一份到电脑，连同密钥信息存好。"""
        try:
            url = d["filePath"]
            u = urlparse(url)
            host = u.hostname
            port = u.port or (443 if u.scheme == "https" else 80)
            ip = resolve_real_ip(host, cfg.upstream_dns)
            if not ip:
                print(f"[服务器包] 解析失败 {host}", flush=True)
                return
            path_q = u.path + ("?" + u.query if u.query else "")
            if u.scheme == "https":
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                conn = http.client.HTTPSConnection(ip, port, timeout=30, context=ctx)
            else:
                conn = http.client.HTTPConnection(ip, port, timeout=30)
            conn.request("GET", path_q, headers={"Host": host, "User-Agent": "okhttp/4.11.0"})
            resp = conn.getresponse()
            blob = resp.read()
            conn.close()
            out_dir = os.path.join(os.path.dirname(cfg.catalog_dir or "."), "server_apks")
            os.makedirs(out_dir, exist_ok=True)
            pkg = d.get("packageName", "app")
            ver = d.get("versionNo", "")
            base = os.path.join(out_dir, f"{pkg}_{ver}")
            with open(base + ".apk", "wb") as f:
                f.write(blob)
            with open(base + ".json", "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
            print(f"[服务器包] 已下载 {pkg} {len(blob)} 字节 -> {base}.apk", flush=True)
        except Exception as e:
            print(f"[服务器包] 下载失败 {e}", flush=True)

    def _process_json(self, data, cfg, host, path):
        """先存样本，再注入自己的条目，最后改写 MD5/大小。"""
        notes = []
        obj = None
        try:
            obj = json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            obj = None

        if cfg.catalog_dir and obj is not None:
            # 顺手记下 sdkInit 的会话密钥材料，后面做本地加密要用
            try:
                if "sdkinit" in path.lower():
                    c = (obj.get("data") or {}).get("cipher")
                    if c:
                        cfg.last_cipher = c
                        print(f"[会话] 捕获 sdkInit cipher ({len(c)}字符) plain={cfg.last_plain}", flush=True)
                        # 拿到会话就立刻后台加密，免得下载时干等
                        cfg.prewarm()
            except Exception:
                pass
            try:
                os.makedirs(cfg.catalog_dir, exist_ok=True)
                stamp = time.strftime("%H%M%S")
                safe = re.sub(r"[^\w.-]", "_", f"{host}{path}")[:80]
                with open(os.path.join(cfg.catalog_dir, f"{stamp}_{safe}.json"), "w",
                          encoding="utf-8") as f:
                    json.dump(obj, f, ensure_ascii=False, indent=2)
            except OSError:
                pass

        injected = False
        if cfg.inject and obj is not None:
            from .inject import inject_entries
            entries = cfg.inject if isinstance(cfg.inject, list) else [cfg.inject]
            obj, ok, msg = inject_entries(obj, entries)
            if ok:
                data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                notes.append(msg)
                injected = True

        # 只在真的注入了条目时才改写 MD5/大小/版本，避免把 sdkInit 之类的
        # 控制响应改坏（老版本因为把 "code":200 改成版本号导致商店无限重刷）
        skip_rewrite = injected or ("sdkinit" in path.lower()) or ("uploadkey" in path.lower())
        if cfg.rewrite and injected and not skip_rewrite:
            data, n = rewrite_json(data, cfg)
            if n:
                notes.append(f"改写{n}处")

        return data, "+".join(notes)

    def _static(self, path):
        cfg = self.server.cfg
        if cfg.root:
            rel = path.lstrip("/") or "index.html"
            target = os.path.abspath(os.path.join(cfg.root, rel))
            if target.startswith(cfg.root) and os.path.isfile(target):
                with open(target, "rb") as f:
                    return "静态文件", f.read(), guess_type(target)
        if cfg.fallback and os.path.exists(cfg.fallback):
            with open(cfg.fallback, "rb") as f:
                return "兜底文件", f.read(), cfg.fallback_type
        return "没找到", b"not found", "text/plain; charset=utf-8"

    def _send(self, data, ctype, head, status=200):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data or b"")))
        cfg = getattr(self.server, "cfg", None)
        if cfg is not None and getattr(cfg, "no_cache", True):
            # 让商店客户端每次都重新拉取，而不是用本地缓存
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.send_header("X-AppStoreScan-Refresh",
                             str(getattr(cfg, "refresh_token", 0)))
        self.end_headers()
        if not head:
            try:
                self.wfile.write(data or b"")
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _read_body(self):
        length = self.headers.get("Content-Length")
        try:
            need = int(length) if length else 0
        except ValueError:
            return b""
        return self.rfile.read(need) if need > 0 else b""

    def _log(self, host, path, ua, action, size, body=b"", scheme="http"):
        cfg = self.server.cfg
        entry = {"kind": "http", "ts": time.time(), "time": time.strftime("%H:%M:%S"),
                 "client": self.client_address[0], "host": host, "path": path,
                 "ua": ua, "action": action, "size": size, "scheme": scheme,
                 "body": body[:1000].decode("utf-8", "replace") if body else ""}
        if cfg.verbose:
            print(f"[{scheme.upper()}] {self.client_address[0]:<15} {host:<26} {path:<34} {action}",
                  flush=True)
        if cfg.on_event:
            try:
                cfg.on_event(entry)
            except Exception:
                pass
        if not cfg.log_path:
            return
        with self.server.log_lock:
            with open(cfg.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")


# --------------------------------------------------------------------------
# 响应改写
# --------------------------------------------------------------------------
MD5_RE = re.compile(r"\b[0-9a-fA-F]{32}\b")
SIZE_KEYS = ("size", "fileSize", "file_size", "apkSize", "apk_size", "length", "bytes", "totalSize")
VERSION_NAME_KEYS = ("versionName", "version_name", "version")
VERSION_CODE_KEYS = ("versionCode", "version_code")


def rewrite_json(raw, cfg):
    """把响应里的 MD5、文件大小、版本号换成我们 APK 的。返回 (新内容, 改写处数)。"""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw, 0

    count = 0
    if cfg.apk_md5:
        text, n = MD5_RE.subn(cfg.apk_md5, text)
        count += n

    if cfg.apk_size:
        for key in SIZE_KEYS:
            pattern = re.compile(r'("%s"\s*:\s*)(\d{4,})' % re.escape(key))
            text, n = pattern.subn(lambda m: m.group(1) + str(cfg.apk_size), text)
            count += n

    if cfg.version_name:
        for key in VERSION_NAME_KEYS:
            pattern = re.compile(r'("%s"\s*:\s*")([^"]{1,30})(")' % re.escape(key))
            text, n = pattern.subn(lambda m: m.group(1) + cfg.version_name + m.group(3), text)
            count += n

    if cfg.version_code:
        for key in VERSION_CODE_KEYS:
            pattern = re.compile(r'("%s"\s*:\s*)(\d{2,})' % re.escape(key))
            text, n = pattern.subn(lambda m: m.group(1) + str(cfg.version_code), text)
            count += n

    return (text.encode("utf-8"), count) if count else (raw, 0)


class SniContext:
    """按 SNI 动态挑证书：同一个 443 端口可以伪装任意域名。"""

    def __init__(self, ca, default_host="localhost"):
        self.ca = ca
        self.last_sni = None
        self._cache = {}
        self._lock = threading.Lock()
        self.base = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        # 直连 IP 下载时没有 SNI，默认证书必须覆盖热点 IP
        default_cert, default_key = ca.leaf_for(default_host)
        self.base.load_cert_chain(default_cert, default_key)
        self.base.sni_callback = self._on_sni

    def context_for(self, host):
        with self._lock:
            if host in self._cache:
                return self._cache[host]
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            cert, key = self.ca.leaf_for(host)
            ctx.load_cert_chain(cert, key)
            self._cache[host] = ctx
            return ctx

    def _on_sni(self, sslobj, server_name, _ctx):
        self.last_sni = server_name
        if server_name:
            try:
                sslobj.context = self.context_for(server_name)
            except Exception:
                pass
        return None


class _TLSHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr, handler, sni):
        self.sni = sni
        super().__init__(addr, handler)

    def get_request(self):
        sock, addr = super().get_request()
        try:
            return self.sni.base.wrap_socket(sock, server_side=True), addr
        except (ssl.SSLError, OSError) as e:
            try:
                sock.close()
            except OSError:
                pass
            cfg = getattr(self, "cfg", None)
            if cfg is not None and cfg.on_event:
                try:
                    cfg.on_event({
                        "kind": "tls_fail", "ts": time.time(),
                        "time": time.strftime("%H:%M:%S"),
                        "client": addr[0], "host": getattr(self.sni, "last_sni", "") or "",
                        "error": str(e)[:150],
                    })
                except Exception:
                    pass
            raise


class FakeStore:
    def __init__(self, cfg, port=80, host="0.0.0.0", ca=None):
        self.cfg = cfg
        self.port = port
        self.host = host
        self.ca = ca
        self._srv = None

    def run(self):
        if self.ca is not None:
            default_host = getattr(self.cfg, "ip", "") or "localhost"
            srv = _TLSHTTPServer((self.host, self.port), StoreHTTPHandler,
                                 SniContext(self.ca, default_host))
            print(f"[HTTPS] 监听 0.0.0.0:{self.port}（自签证书，手机需装 CA）", flush=True)
        else:
            srv = ThreadingHTTPServer((self.host, self.port), StoreHTTPHandler)
            print(f"[HTTP] 监听 0.0.0.0:{self.port}", flush=True)
        srv.daemon_threads = True
        srv.cfg = self.cfg
        srv.log_lock = threading.Lock()
        self._srv = srv
        try:
            srv.serve_forever(poll_interval=0.3)
        except Exception:
            pass

    def stop(self):
        if self._srv:
            try:
                self._srv.shutdown()
                self._srv.server_close()
            except Exception:
                pass


def guess_type(path):
    ext = os.path.splitext(path)[1].lower()
    return {
        ".json": "application/json; charset=utf-8",
        ".xml": "application/xml; charset=utf-8",
        ".txt": "text/plain; charset=utf-8",
        ".html": "text/html; charset=utf-8",
        ".apk": "application/vnd.android.package-archive",
        ".png": "image/png",
        ".jpg": "image/jpeg",
    }.get(ext, "application/octet-stream")
