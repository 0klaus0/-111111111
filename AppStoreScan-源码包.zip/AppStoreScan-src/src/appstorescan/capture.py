"""抓包代理：让手机的商店流量经过电脑，把每条请求/响应记下来。

用法：手机 WiFi 里把「代理」设成 电脑IP:8899，然后打开商店随便点几下，
所有请求就会写进 data/capture/*.jsonl。

HTTPS 需要手机信任本工具的 CA（老安卓 7.0 以下装了就生效）。
"""

from __future__ import annotations

import base64
import json
import os
import socket
import ssl
import threading
import time
from datetime import datetime, timedelta, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

MAX_HEADER = 64 * 1024
READ_CHUNK = 64 * 1024


# --------------------------------------------------------------------------
# 证书
# --------------------------------------------------------------------------
class CertificateAuthority:
    def __init__(self, directory):
        self.dir = directory
        self.leaf_dir = os.path.join(directory, "leaf")
        os.makedirs(self.leaf_dir, exist_ok=True)
        self.cert_path = os.path.join(directory, "ca.crt")
        self.key_path = os.path.join(directory, "ca.key")
        self._lock = threading.Lock()
        self._cache = {}
        self._load_or_create()

    @property
    def common_name(self):
        return "AppStoreScan Capture CA"

    def _load_or_create(self):
        if os.path.exists(self.cert_path) and os.path.exists(self.key_path):
            with open(self.cert_path, "rb") as f:
                self.cert = x509.load_pem_x509_certificate(f.read())
            with open(self.key_path, "rb") as f:
                self.key = serialization.load_pem_private_key(f.read(), password=None)
            return

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, self.common_name),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "AppStoreScan"),
        ])
        now = datetime.now(timezone.utc)
        cert = (
            x509.CertificateBuilder()
            .subject_name(name)
            .issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(days=1))
            .not_valid_after(now + timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True, content_commitment=False,
                    key_encipherment=False, data_encipherment=False,
                    key_agreement=False, key_cert_sign=True, crl_sign=True,
                    encipher_only=False, decipher_only=False,
                ),
                critical=True,
            )
            .sign(key, hashes.SHA256())
        )
        with open(self.cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        with open(self.key_path, "wb") as f:
            f.write(key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.TraditionalOpenSSL,
                serialization.NoEncryption(),
            ))
        self.cert, self.key = cert, key

    def leaf_for(self, host):
        """按主机名签一张临时证书，缓存到磁盘（ssl 只接受文件路径）。"""
        safe = "".join(c if c.isalnum() or c in ".-_" else "_" for c in host)
        with self._lock:
            if host in self._cache:
                return self._cache[host]

            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            now = datetime.now(timezone.utc)
            try:
                import ipaddress
                san = x509.SubjectAlternativeName(
                    [x509.IPAddress(ipaddress.ip_address(host))]
                )
            except ValueError:
                san = x509.SubjectAlternativeName([x509.DNSName(host)])

            cert = (
                x509.CertificateBuilder()
                .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host)]))
                .issuer_name(self.cert.subject)
                .public_key(key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now - timedelta(days=1))
                .not_valid_after(now + timedelta(days=825))
                .add_extension(san, critical=False)
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                .add_extension(
                    x509.ExtendedKeyUsage([x509.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
                )
                .sign(self.key, hashes.SHA256())
            )

            cert_file = os.path.join(self.leaf_dir, f"{safe}.crt")
            key_file = os.path.join(self.leaf_dir, f"{safe}.key")
            with open(cert_file, "wb") as f:
                f.write(cert.public_bytes(serialization.Encoding.PEM))
            with open(key_file, "wb") as f:
                f.write(key.private_bytes(
                    serialization.Encoding.PEM,
                    serialization.PrivateFormat.TraditionalOpenSSL,
                    serialization.NoEncryption(),
                ))
            self._cache[host] = (cert_file, key_file)
            return self._cache[host]


# --------------------------------------------------------------------------
# 代理
# --------------------------------------------------------------------------
class CaptureProxy:
    def __init__(self, ca, log_dir, host="0.0.0.0", port=8899,
                 max_body=512 * 1024, timeout=20, verbose=True, mitm=True):
        self.ca = ca
        self.log_dir = log_dir
        self.host = host
        self.port = port
        self.max_body = max_body
        self.timeout = timeout
        self.verbose = verbose
        self.mitm = mitm
        os.makedirs(log_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.log_path = os.path.join(log_dir, f"capture-{stamp}.jsonl")
        self.catalog_path = os.path.join(log_dir, f"catalog-{stamp}.jsonl")
        self._log_lock = threading.Lock()
        self._count = 0

    # -- 生命周期 ---------------------------------------------------------
    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.host, self.port))
        srv.listen(200)
        print(f"[代理已启动] 监听 {self.host}:{self.port}", flush=True)
        print(f"[日志] {self.log_path}")
        print(f"[CA]   {self.ca.cert_path}")
        print("现在把手机的 WiFi 代理设成 本机IP:%d，然后打开商店。" % self.port)
        print("按 Ctrl+C 停止。\n")
        try:
            while True:
                conn, addr = srv.accept()
                threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()
        except KeyboardInterrupt:
            print(f"\n已停止，共记录 {self._count} 条请求。")
        finally:
            srv.close()

    # -- 连接处理 ---------------------------------------------------------
    def _handle(self, conn, addr):
        conn.settimeout(self.timeout)
        try:
            start, headers, rest = self._read_head(conn)
            if not start:
                return
            method, target, _version = start.split(" ", 2)

            if method.upper() == "CONNECT":
                self._handle_connect(conn, target, addr)
            else:
                self._handle_http(conn, method, target, headers, rest, addr)
        except (socket.timeout, ConnectionError, ssl.SSLError, OSError):
            pass
        except Exception as e:  # 抓包工具不该因为单条请求挂掉
            if self.verbose:
                print(f"[跳过] {addr[0]} {e!r}")
        finally:
            try:
                conn.close()
            except OSError:
                pass

    def _handle_connect(self, conn, target, addr):
        host, _, port_s = target.partition(":")
        port = int(port_s or 443)
        if not self.mitm:
            conn.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\n")
            return
        conn.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")

        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        cert_file, key_file = self.ca.leaf_for(host)
        ctx.load_cert_chain(cert_file, key_file)
        try:
            tls = ctx.wrap_socket(conn, server_side=True)
        except (ssl.SSLError, OSError) as e:
            self._log({
                "ts": time.time(), "client": addr[0], "scheme": "https", "host": host,
                "port": port, "event": "tls-failed",
                "note": "手机不信任本工具证书，或该 App 做了证书校验",
                "error": str(e)[:200],
            })
            return

        tls.settimeout(self.timeout)
        start, headers, rest = self._read_head(tls)
        if not start:
            return
        method, target2, _ = start.split(" ", 2)
        self._forward(tls, "https", host, port, method, target2, headers, rest, addr)

    def _handle_http(self, conn, method, target, headers, rest, addr):
        # 代理请求行可能是绝对地址：GET http://host/path HTTP/1.1
        if target.lower().startswith("http://"):
            rest_url = target[7:]
            host_port, _, path = rest_url.partition("/")
            path = "/" + path
            host, _, port_s = host_port.partition(":")
            port = int(port_s or 80)
        else:
            host = headers.get("host", "")
            host, _, port_s = host.partition(":")
            port = int(port_s or 80)
            path = target
        self._forward(conn, "http", host, port, method, path, headers, rest, addr)

    # -- 转发 + 记录 ------------------------------------------------------
    def _forward(self, client, scheme, host, port, method, path, headers, rest, addr):
        body = self._read_body(client, headers, rest)
        upstream = socket.create_connection((host, port), timeout=self.timeout)
        if scheme == "https":
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            upstream = ctx.wrap_socket(upstream, server_hostname=host)
        upstream.settimeout(self.timeout)

        lines = [f"{method} {path} HTTP/1.1"]
        skip = {"proxy-connection", "connection", "keep-alive"}
        for k, v in headers.items():
            if k.lower() in skip:
                continue
            lines.append(f"{k}: {v}")
        lines.append("Connection: close")
        upstream.sendall(("\r\n".join(lines) + "\r\n\r\n").encode("latin-1") + body)

        start, resp_headers, _rest = self._read_head(upstream)
        if not start:
            client.sendall(b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n")
            try:
                upstream.close()
            except OSError:
                pass
            return

        # 头原样回给客户端，body 逐字节透传（chunked 也照搬）
        out_headers = [start]
        for k, v in resp_headers.items():
            if k.lower() in ("connection", "keep-alive", "proxy-connection"):
                continue
            out_headers.append(f"{k}: {v}")
        out_headers.append("Connection: close")
        client.sendall(("\r\n".join(out_headers) + "\r\n\r\n").encode("latin-1"))

        captured = bytearray()
        total = 0
        if _rest:                      # 响应头和 body 在同一个 TCP 包里时，别把它丢了
            total += len(_rest)
            captured.extend(_rest[: self.max_body])
            client.sendall(_rest)
        try:
            while True:
                chunk = upstream.recv(READ_CHUNK)
                if not chunk:
                    break
                total += len(chunk)
                if len(captured) < self.max_body:
                    captured.extend(chunk[: self.max_body - len(captured)])
                client.sendall(chunk)
        except (socket.timeout, OSError):
            pass
        finally:
            try:
                upstream.close()
            except OSError:
                pass

        self._record(addr, scheme, host, port, method, path, headers, body,
                     start, resp_headers, bytes(captured), total)

    # -- 记录 -------------------------------------------------------------
    def _record(self, addr, scheme, host, port, method, path, req_headers,
                req_body, status, resp_headers, resp_body, total):
        entry = {
            "ts": time.time(),
            "time": time.strftime("%H:%M:%S"),
            "client": addr[0],
            "scheme": scheme,
            "host": host,
            "port": port,
            "method": method,
            "path": path,
            "req_headers": req_headers,
            "req_body": _body_text(req_body, 4000),
            "status": status,
            "resp_headers": resp_headers,
            "resp_len": total,
            "resp_body": _body_text(resp_body, 20000),
        }
        with self._log_lock:
            self._count += 1
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            if _looks_like_catalog(resp_body, resp_headers):
                with open(self.catalog_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        if self.verbose:
            print(f"[{self._count}] {method} {scheme}://{host}{path} -> {status} ({total} B)")

    # -- 低层读写 ---------------------------------------------------------
    @staticmethod
    def _read_head(sock):
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = sock.recv(4096)
            if not chunk:
                return "", {}, b""
            buf += chunk
            if len(buf) > MAX_HEADER:
                break
        head, _, rest = buf.partition(b"\r\n\r\n")
        lines = head.split(b"\r\n")
        start = lines[0].decode("latin-1")
        headers = {}
        for line in lines[1:]:
            if b":" in line:
                k, v = line.split(b":", 1)
                headers[k.decode("latin-1").strip().lower()] = v.decode("latin-1").strip()
        return start, headers, rest

    @staticmethod
    def _read_body(sock, headers, initial):
        length = headers.get("content-length")
        if not length:
            return initial
        try:
            need = int(length) - len(initial)
        except ValueError:
            return initial
        data = bytearray(initial)
        while need > 0:
            chunk = sock.recv(min(READ_CHUNK, need))
            if not chunk:
                break
            data.extend(chunk)
            need -= len(chunk)
        return bytes(data)


# --------------------------------------------------------------------------
# 辅助
# --------------------------------------------------------------------------
def _body_text(raw, limit):
    if not raw:
        return ""
    head = raw[:limit]
    try:
        return head.decode("utf-8")
    except UnicodeDecodeError:
        return "base64:" + base64.b64encode(head).decode("ascii")


def _looks_like_catalog(raw, headers):
    if not raw:
        return False
    ctype = (headers.get("content-type") or "").lower()
    if "json" not in ctype and not raw.lstrip().startswith(b"{"):
        return False
    sample = raw[:20000].decode("utf-8", "ignore").lower()
    keys = ("packagename", "package_name", "apkurl", "apk_url", "\"apk\"",
            "applist", "app_list", "bundleid", "versioncode")
    return any(k in sample for k in keys)


def summarize(log_path):
    """把抓到的东西按接口汇总，方便一眼看出商店用了哪些接口。"""
    groups = {}
    with open(log_path, encoding="utf-8") as f:
        for line in f:
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            key = (e.get("scheme"), e.get("host"), e.get("port"), e.get("method"), e.get("path"))
            g = groups.setdefault(key, {"n": 0, "sizes": [], "status": set(), "sample": ""})
            g["n"] += 1
            g["sizes"].append(e.get("resp_len") or 0)
            g["status"].add(str(e.get("status")))
            if not g["sample"] and e.get("resp_body"):
                g["sample"] = e["resp_body"][:300].replace("\n", " ")
    return groups


# --------------------------------------------------------------------------
# 证书分发：手机浏览器打开 http://电脑IP:8898 就能下载 ca.crt
# --------------------------------------------------------------------------
def start_cert_server(ca, port, host="0.0.0.0"):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith("/ca.crt"):
                with open(ca.cert_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/x-x509-ca-cert")
                self.send_header("Content-Disposition", 'attachment; filename="ca.crt"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            body = (
                "<html><meta charset='utf-8'><body style='font-family:sans-serif;padding:24px'>"
                "<h3>AppStoreScan 抓包证书</h3>"
                "<p>1. 点下面的链接下载证书</p>"
                "<p><a href='/ca.crt'>下载 ca.crt</a></p>"
                "<p>2. 设置 → 安全 → 从存储设备安装 → 选择 ca.crt</p>"
                "<p>3. 装好后把 WiFi 代理设为 <b>本机IP:8899</b>，再打开应用商店</p>"
                "</body></html>"
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    srv = ThreadingHTTPServer((host, port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
