"""华为 / 腾讯应用商店的已知特征，用于一键模式预置劫持范围。"""

from __future__ import annotations

PROFILES = {
    "huawei": {
        "label": "华为应用市场",
        "domains": [
            "*.hicloud.com",
            "*.dbankcloud.com",
            "*.dbankcdn.com",
            "*.appgallery.huawei.com",
            "*.huawei.com",
        ],
        "note": "接口多为 HTTPS，证书不装会握手失败",
    },
    "tencent": {
        "label": "腾讯应用宝",
        "domains": [
            "*.myapp.com",
            "*.sj.qq.com",
            "*.dd.qq.com",
            "*.gtimg.cn",
            "*.imgcache.qq.com",
        ],
        "note": "下载多走 dd.qq.com，明文 HTTP 较多",
    },
}

# 一键替换默认同时覆盖两家
DEFAULT_DOMAINS = list(dict.fromkeys(
    PROFILES["huawei"]["domains"] + PROFILES["tencent"]["domains"]
))

DEFAULT_ONLY = ",".join(DEFAULT_DOMAINS)


def label_for(domain):
    d = (domain or "").lower()
    for key, p in PROFILES.items():
        if any(d.endswith(x.lstrip("*")) for x in p["domains"]):
            return p["label"]
    return ""
