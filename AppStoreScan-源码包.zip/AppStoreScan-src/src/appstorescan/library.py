"""多 APK 发布库：一个目录里的 APK 全部变成可广播的应用。

做三件事：
1. 解析 APK 里的 AndroidManifest.xml（二进制 XML），拿到包名、版本、SDK 要求；
2. 算出文件大小和 MD5（商店校验用）；
3. 生成可以直接塞进商店列表的上架条目，并维护 包名 -> 文件 的路由表。
"""
from __future__ import annotations

import hashlib
import os
import re
import struct
import zipfile

RES_STRING_POOL = 0x0001
RES_XML = 0x0003
RES_XML_RESOURCE_MAP = 0x0180
RES_XML_START_ELEMENT = 0x0102

ANDROID_NS = "http://schemas.android.com/apk/res/android"
ATTR_VERSION_CODE = 0x0101021B
ATTR_VERSION_NAME = 0x0101021C
ATTR_MIN_SDK = 0x0101020C
ATTR_TARGET_SDK = 0x01010270

UTF8_FLAG = 0x00000100


class ApkError(RuntimeError):
    pass


def _read_string_pool(data, off):
    """返回 (字符串列表, 本 chunk 总长度)。UTF-8 / UTF-16 都支持。"""
    header_size = struct.unpack_from("<H", data, off + 2)[0]
    total = struct.unpack_from("<I", data, off + 4)[0]
    string_count, _style_count, flags, strings_start, _styles_start = struct.unpack_from(
        "<IIIII", data, off + 8)
    utf8 = bool(flags & UTF8_FLAG)
    strings = []
    for i in range(string_count):
        rel = struct.unpack_from("<I", data, off + header_size + i * 4)[0]
        p = off + strings_start + rel
        if utf8:
            n = data[p]
            p += 2 if (n & 0x80) else 1          # 字符数，跳过
            ln = data[p]
            if ln & 0x80:
                ln = ((ln & 0x7F) << 8) | data[p + 1]
                p += 2
            else:
                p += 1
            strings.append(data[p:p + ln].decode("utf-8", "replace"))
        else:
            ln = struct.unpack_from("<H", data, p)[0]
            p += 2
            if ln & 0x8000:
                ln = ((ln & 0x7FFF) << 16) | struct.unpack_from("<H", data, p)[0]
                p += 2
            strings.append(data[p:p + ln * 2].decode("utf-16-le", "replace"))
    return strings, total


def parse_manifest(xml_bytes):
    """解析二进制 AndroidManifest.xml，返回字典。失败抛 ApkError。"""
    if len(xml_bytes) < 8:
        raise ApkError("manifest 太短")
    rtype, rheader, rsize = struct.unpack_from("<HHI", xml_bytes, 0)
    if rtype != RES_XML:
        raise ApkError("不是二进制 XML（可能是明文 manifest）")

    off = rheader
    strings: list[str] = []
    res_ids: list[int] = []
    result = {"package": "", "versionName": "", "versionCode": None,
              "minSdk": None, "targetSdk": None}

    while off + 8 <= len(xml_bytes) and off < rsize:
        ctype, cheader, csize = struct.unpack_from("<HHI", xml_bytes, off)
        if csize <= 0:
            break

        if ctype == RES_STRING_POOL:
            strings, _ = _read_string_pool(xml_bytes, off)
        elif ctype == RES_XML_RESOURCE_MAP:
            n = (csize - cheader) // 4
            res_ids = list(struct.unpack_from("<%dI" % n, xml_bytes, off + cheader))
        elif ctype == RES_XML_START_ELEMENT:
            ext = off + cheader
            _ns_idx, name_idx = struct.unpack_from("<II", xml_bytes, ext)
            el_name = strings[name_idx] if name_idx < len(strings) else ""
            attr_start = struct.unpack_from("<H", xml_bytes, ext + 8)[0]
            attr_size = struct.unpack_from("<H", xml_bytes, ext + 10)[0]
            attr_count = struct.unpack_from("<H", xml_bytes, ext + 12)[0]

            if el_name == "manifest":
                aoff = ext + attr_start
                for _i in range(attr_count):
                    ns_idx, aname_idx, raw_idx = struct.unpack_from("<III", xml_bytes, aoff)
                    v_size, _res0, v_type, v_data = struct.unpack_from("<HBBI", xml_bytes, aoff + 12)
                    name = strings[aname_idx] if aname_idx < len(strings) else ""
                    ns = strings[ns_idx] if ns_idx < len(strings) else ""
                    res_id = res_ids[aname_idx] if aname_idx < len(res_ids) else 0

                    if v_type == 0x03:                     # 字符串型
                        str_val = strings[v_data] if v_data < len(strings) else ""
                    elif raw_idx < len(strings) and strings[raw_idx]:
                        str_val = strings[raw_idx]
                    else:
                        str_val = ""
                    if v_type in (0x10, 0x11):             # int / hex
                        int_val = v_data if v_data < 0x80000000 else None
                    else:
                        int_val = None

                    if not ns and name == "package":
                        result["package"] = str_val
                    elif res_id == ATTR_VERSION_CODE or (ns == ANDROID_NS and name == "versionCode"):
                        if int_val is not None:
                            result["versionCode"] = int_val
                    elif res_id == ATTR_VERSION_NAME or (ns == ANDROID_NS and name == "versionName"):
                        if str_val:
                            result["versionName"] = str_val
                    elif res_id == ATTR_MIN_SDK or (ns == ANDROID_NS and name == "minSdkVersion"):
                        if int_val is not None:
                            result["minSdk"] = int_val
                    elif res_id == ATTR_TARGET_SDK or (ns == ANDROID_NS and name == "targetSdkVersion"):
                        if int_val is not None:
                            result["targetSdk"] = int_val
                    aoff += attr_size or 20
                if result["package"]:
                    break
        off += csize

    if not result["package"]:
        raise ApkError("没解析出包名")
    return result


class AppItem:
    """一个待广播的应用。"""

    def __init__(self, path, package, version_name, version_code, size, md5,
                 min_sdk=None, target_sdk=None, label=""):
        self.path = path
        self.package = package
        self.version_name = version_name
        self.version_code = version_code
        self.size = size
        self.md5 = md5
        self.min_sdk = min_sdk
        self.target_sdk = target_sdk
        self.label = label

    @property
    def filename(self):
        return os.path.basename(self.path)

    def entry(self, server_ip, http_port, name=None):
        """生成商店列表条目（键名走 inject.py 的别名映射，克隆时会自动对齐）。"""
        # 商店列表条目的字段必须和真服务器一致：id 是数字字符串，
        # softVersion 是整型版本号，size 是字符串；否则车机点开详情会串号。
        sid = str(100000 + (int(self.md5[:6], 16) if self.md5 else 0) % 800000)
        return {
            "id": sid,
            "name": name or self.label or self.package,
            "description": "本地广播应用",
            "iconPath": "",
            "softVersion": self.version_code or 1,
            "size": str(self.size),
            "originalPrice": None,
            "currentPrice": None,
            "salableMark": 2,
            "packageName": self.package,
            "payUrl": None,
            "versionName": self.version_name or "1.0",
            "md5": self.md5,
            "downloadUrl": f"http://{server_ip}:{http_port}/dl/{self.package}.apk",
        }

    def describe(self):
        return (f"{self.package:<36} {self.version_name or '-':<10} "
                f"{self.size / 1048576:6.1f}MB  SDK {self.min_sdk or '-'}→{self.target_sdk or '-'}")

    def as_dict(self):
        return {"package": self.package, "versionName": self.version_name,
                "versionCode": self.version_code, "size": self.size, "md5": self.md5,
                "minSdk": self.min_sdk, "targetSdk": self.target_sdk,
                "file": self.path, "label": self.label}


def _label_from_filename(path):
    """从文件名猜一个像样的应用名：Auto_9.5.0.600013_release_signed -> Auto。"""
    stem = os.path.splitext(os.path.basename(path))[0]
    stem = re.sub(r"[_\-\s]*[vV]?\d+(\.\d+)+.*$", "", stem)
    stem = re.sub(r"[_\-\s]+", " ", stem).strip()
    return stem or os.path.splitext(os.path.basename(path))[0]


def inspect_apk(path) -> AppItem:
    """读一个 APK 的包名/版本/大小/MD5。不是合法 APK 时抛 ApkError。"""
    if not os.path.isfile(path):
        raise ApkError(f"文件不存在：{path}")
    try:
        with zipfile.ZipFile(path) as z:
            try:
                xml = z.read("AndroidManifest.xml")
            except KeyError:
                raise ApkError("压缩包里没有 AndroidManifest.xml，不是 APK")
    except zipfile.BadZipFile:
        raise ApkError("不是有效的 APK（zip 损坏）")

    info = parse_manifest(xml)
    return AppItem(path, info["package"], info["versionName"], info["versionCode"],
                   os.path.getsize(path), _md5_of(path),
                   info["minSdk"], info["targetSdk"], _label_from_filename(path))


def _md5_of(path, chunk=4 * 1024 * 1024):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def scan_dir(folder) -> tuple[list[AppItem], list[str]]:
    """扫描目录下所有 .apk，返回 (应用列表, 失败说明)。同包名只保留版本号更大的。"""
    found: dict[str, AppItem] = {}
    errors: list[str] = []
    if not os.path.isdir(folder):
        return [], [f"目录不存在：{folder}"]
    for name in sorted(os.listdir(folder)):
        if not name.lower().endswith(".apk"):
            continue
        path = os.path.join(folder, name)
        try:
            item = inspect_apk(path)
        except ApkError as e:
            errors.append(f"{name}：{e}")
            continue
        old = found.get(item.package)
        if old is None or (item.version_code or 0) > (old.version_code or 0):
            found[item.package] = item
        else:
            errors.append(f"{name}：包名 {item.package} 已有更高版本，跳过")
    return list(found.values()), errors
